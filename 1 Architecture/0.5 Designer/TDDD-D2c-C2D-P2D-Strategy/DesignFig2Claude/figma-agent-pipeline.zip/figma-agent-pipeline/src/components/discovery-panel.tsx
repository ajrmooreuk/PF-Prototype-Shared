/**
 * Example: Discovery Panel Component
 * 
 * This component demonstrates:
 * 1. Built with design system tokens (from Figma)
 * 2. Uses Shadcn/ui components (aligned to Figma components)
 * 3. UI interaction triggers agent workflow
 * 4. Agent response rendered through design-system components
 */

'use client';

import React, { useState } from 'react';
import { useAgentTrigger, useWorkflowState } from '@/lib/ui-agent-bridge';

// Shadcn imports - these are styled with your Figma tokens
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Search, Globe, Users, TrendingUp } from 'lucide-react';

// ============================================================================
// TYPES (aligned with Schema.org)
// ============================================================================

interface DiscoveryResult {
  brandProfile: {
    name: string;
    domain: string;
    description: string;
    industry: string;
    aiVisibilityScore: number;
  };
  competitorProfiles: Array<{
    name: string;
    domain: string;
    score: number;
  }>;
  opportunities: Array<{
    type: string;
    description: string;
    priority: 'high' | 'medium' | 'low';
  }>;
}

// ============================================================================
// COMPONENT
// ============================================================================

export function DiscoveryPanel() {
  // Form state
  const [brandUrl, setBrandUrl] = useState('');
  const [competitors, setCompetitors] = useState<string[]>(['']);
  const [scanDepth, setScanDepth] = useState<'quick' | 'standard' | 'deep'>('standard');
  
  // Agent trigger hook - connects this UI to the P1-discovery-profiling workflow
  const { trigger } = useAgentTrigger('trigger-discovery-scan');
  
  // Workflow state monitoring
  const { state: workflowState, cancel } = useWorkflowState('P1-discovery-profiling');
  
  // Local result state
  const [result, setResult] = useState<DiscoveryResult | null>(null);

  const handleStartScan = async () => {
    try {
      // This triggers the agent workflow defined in architecture-overview.ts
      const response = await trigger({
        brandUrl,
        competitors: competitors.filter(c => c.trim() !== ''),
        scanDepth
      });
      
      setResult(response as DiscoveryResult);
    } catch (error) {
      console.error('Discovery scan failed:', error);
    }
  };

  const addCompetitor = () => {
    setCompetitors([...competitors, '']);
  };

  const updateCompetitor = (index: number, value: string) => {
    const updated = [...competitors];
    updated[index] = value;
    setCompetitors(updated);
  };

  const isRunning = workflowState?.status === 'running';

  return (
    <div className="space-y-6">
      {/* 
        Card component uses design tokens:
        - Background: var(--semantic-color-surface)
        - Border: var(--semantic-border-radius-lg)
        - Shadow: var(--semantic-shadow-card)
      */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Brand Discovery
          </CardTitle>
          <CardDescription>
            Analyze your brand's AI visibility and competitive landscape
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Brand URL Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Brand Website</label>
            <Input
              placeholder="https://yourbrand.com"
              value={brandUrl}
              onChange={(e) => setBrandUrl(e.target.value)}
              disabled={isRunning}
            />
          </div>

          {/* Competitors */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Competitors
            </label>
            {competitors.map((comp, index) => (
              <Input
                key={index}
                placeholder={`Competitor ${index + 1} URL`}
                value={comp}
                onChange={(e) => updateCompetitor(index, e.target.value)}
                disabled={isRunning}
              />
            ))}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={addCompetitor}
              disabled={isRunning}
            >
              + Add Competitor
            </Button>
          </div>

          {/* Scan Depth */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Scan Depth</label>
            <Select 
              value={scanDepth} 
              onValueChange={(v) => setScanDepth(v as typeof scanDepth)}
              disabled={isRunning}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="quick">Quick (2-3 min)</SelectItem>
                <SelectItem value="standard">Standard (5-10 min)</SelectItem>
                <SelectItem value="deep">Deep (15-20 min)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Progress indicator when running */}
          {isRunning && workflowState && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {workflowState.currentStep || 'Initializing...'}
                </span>
                <span>{Math.round(workflowState.progress)}%</span>
              </div>
              <Progress value={workflowState.progress} />
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button 
              onClick={handleStartScan}
              disabled={!brandUrl || isRunning}
              className="flex-1"
            >
              {isRunning ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Start Discovery Scan
                </>
              )}
            </Button>
            
            {isRunning && (
              <Button variant="outline" onClick={cancel}>
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Results - rendered through design-system components */}
      {result && <DiscoveryResults data={result} />}
      
      {/* Error state */}
      {workflowState?.status === 'error' && (
        <Alert variant="destructive">
          <AlertDescription>
            {workflowState.error?.message || 'An error occurred during the scan'}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}

// ============================================================================
// RESULTS COMPONENT
// Agent output rendered through design-system components
// ============================================================================

function DiscoveryResults({ data }: { data: DiscoveryResult }) {
  return (
    <div className="space-y-4">
      {/* Brand Profile Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>{data.brandProfile.name}</span>
            <Badge variant={getScoreBadgeVariant(data.brandProfile.aiVisibilityScore)}>
              AI Score: {data.brandProfile.aiVisibilityScore}/100
            </Badge>
          </CardTitle>
          <CardDescription>{data.brandProfile.domain}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {data.brandProfile.description}
          </p>
          <Badge variant="outline" className="mt-2">
            {data.brandProfile.industry}
          </Badge>
        </CardContent>
      </Card>

      {/* Competitor Comparison */}
      {data.competitorProfiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Competitive Landscape
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.competitorProfiles.map((comp, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                >
                  <div>
                    <p className="font-medium">{comp.name}</p>
                    <p className="text-sm text-muted-foreground">{comp.domain}</p>
                  </div>
                  <Badge variant={getScoreBadgeVariant(comp.score)}>
                    {comp.score}/100
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Opportunities */}
      {data.opportunities.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Opportunities Identified
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.opportunities.map((opp, index) => (
                <div 
                  key={index}
                  className="p-3 rounded-lg border"
                >
                  <div className="flex items-center justify-between mb-1">
                    <Badge variant="outline">{opp.type}</Badge>
                    <Badge variant={getPriorityVariant(opp.priority)}>
                      {opp.priority}
                    </Badge>
                  </div>
                  <p className="text-sm">{opp.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============================================================================
// HELPERS
// ============================================================================

function getScoreBadgeVariant(score: number): 'default' | 'secondary' | 'destructive' {
  if (score >= 70) return 'default';
  if (score >= 40) return 'secondary';
  return 'destructive';
}

function getPriorityVariant(priority: string): 'default' | 'secondary' | 'outline' {
  switch (priority) {
    case 'high': return 'default';
    case 'medium': return 'secondary';
    default: return 'outline';
  }
}

export default DiscoveryPanel;
