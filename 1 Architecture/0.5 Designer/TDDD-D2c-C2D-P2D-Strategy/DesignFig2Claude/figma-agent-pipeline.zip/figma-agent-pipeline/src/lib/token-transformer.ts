/**
 * Design Token Transformer
 * Converts W3C DTCG format tokens to CSS, Tailwind, and TypeScript outputs
 * 
 * @schema https://schema.org/SoftwareSourceCode
 */

import type { DesignTokenSet, TokenGroup, DesignToken, ColorValue } from './figma-api';
import * as fs from 'fs/promises';
import * as path from 'path';

// ============================================================================
// OUTPUT CONFIGURATIONS
// ============================================================================

interface TransformConfig {
  outputDir: string;
  cssFilename: string;
  tailwindFilename: string;
  typesFilename: string;
  schemaFilename: string;
  prefix?: string;
  includeBrands?: boolean;
}

const DEFAULT_CONFIG: TransformConfig = {
  outputDir: './config/tokens',
  cssFilename: 'variables.css',
  tailwindFilename: 'tailwind.tokens.ts',
  typesFilename: 'tokens.d.ts',
  schemaFilename: 'tokens.schema.json',
  prefix: '',
  includeBrands: true
};

// ============================================================================
// CSS TRANSFORMER
// ============================================================================

export class CSSTransformer {
  private config: TransformConfig;

  constructor(config: Partial<TransformConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Generate CSS custom properties from tokens
   */
  generateCSS(tokens: DesignTokenSet): string {
    const lines: string[] = [
      '/**',
      ' * Design Tokens - Auto-generated from Figma',
      ` * Source: ${tokens.$metadata.source}`,
      ` * Extracted: ${tokens.$metadata.extractedAt}`,
      ` * Version: ${tokens.$metadata.version}`,
      ' * DO NOT EDIT MANUALLY',
      ' */',
      '',
      ':root {'
    ];

    // Add primitive tokens
    lines.push('  /* ========== Primitives ========== */');
    lines.push(...this.tokenGroupToCSS(tokens.primitives, 'primitive'));

    // Add semantic tokens
    lines.push('');
    lines.push('  /* ========== Semantic ========== */');
    lines.push(...this.tokenGroupToCSS(tokens.semantic, 'semantic'));

    // Add component tokens
    lines.push('');
    lines.push('  /* ========== Component ========== */');
    lines.push(...this.tokenGroupToCSS(tokens.component, 'component'));

    lines.push('}');

    // Add brand-specific tokens as data attributes
    if (this.config.includeBrands && Object.keys(tokens.brand).length > 0) {
      lines.push('');
      lines.push('/* ========== Brand Overrides ========== */');
      
      for (const [brandId, brandTokens] of Object.entries(tokens.brand)) {
        lines.push('');
        lines.push(`[data-brand="${brandId}"] {`);
        lines.push(...this.tokenGroupToCSS(brandTokens, ''));
        lines.push('}');
      }
    }

    // Add utility classes
    lines.push('');
    lines.push('/* ========== Utility Classes ========== */');
    lines.push(...this.generateUtilityClasses(tokens));

    return lines.join('\n');
  }

  private tokenGroupToCSS(group: TokenGroup, prefix: string): string[] {
    const lines: string[] = [];
    
    for (const [category, categoryTokens] of Object.entries(group)) {
      for (const [tokenName, token] of Object.entries(categoryTokens)) {
        const varName = this.formatCSSVarName(prefix, category, tokenName);
        const value = this.formatCSSValue(token);
        lines.push(`  --${varName}: ${value};`);
      }
    }
    
    return lines;
  }

  private formatCSSVarName(...parts: string[]): string {
    return parts
      .filter(Boolean)
      .join('-')
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-');
  }

  private formatCSSValue(token: DesignToken): string {
    const value = token.$value;

    if (token.$type === 'color' && typeof value === 'object') {
      const color = value as ColorValue;
      if (color.a !== undefined && color.a < 1) {
        return `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a})`;
      }
      return `rgb(${color.r}, ${color.g}, ${color.b})`;
    }

    if (token.$type === 'dimension' && typeof value === 'number') {
      // Assume pixels for dimensions, convert to rem for scalability
      return `${value / 16}rem`;
    }

    if (typeof value === 'string' && value.startsWith('{')) {
      // Variable alias - convert to CSS var reference
      const aliasId = value.slice(1, -1);
      return `var(--${this.formatCSSVarName(aliasId)})`;
    }

    return String(value);
  }

  private generateUtilityClasses(tokens: DesignTokenSet): string[] {
    const lines: string[] = [];
    
    // Color utilities
    if (tokens.semantic.color) {
      for (const tokenName of Object.keys(tokens.semantic.color)) {
        const varName = this.formatCSSVarName('semantic', 'color', tokenName);
        lines.push(`.bg-${tokenName} { background-color: var(--${varName}); }`);
        lines.push(`.text-${tokenName} { color: var(--${varName}); }`);
        lines.push(`.border-${tokenName} { border-color: var(--${varName}); }`);
      }
    }

    // Spacing utilities
    if (tokens.semantic.spacing) {
      for (const tokenName of Object.keys(tokens.semantic.spacing)) {
        const varName = this.formatCSSVarName('semantic', 'spacing', tokenName);
        lines.push(`.p-${tokenName} { padding: var(--${varName}); }`);
        lines.push(`.m-${tokenName} { margin: var(--${varName}); }`);
        lines.push(`.gap-${tokenName} { gap: var(--${varName}); }`);
      }
    }

    return lines;
  }
}

// ============================================================================
// TAILWIND TRANSFORMER
// ============================================================================

export class TailwindTransformer {
  private config: TransformConfig;

  constructor(config: Partial<TransformConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Generate Tailwind theme extension from tokens
   */
  generateTailwindConfig(tokens: DesignTokenSet): string {
    const theme = this.buildTailwindTheme(tokens);
    
    return `/**
 * Tailwind Theme Extension - Auto-generated from Figma
 * Source: ${tokens.$metadata.source}
 * Extracted: ${tokens.$metadata.extractedAt}
 * Version: ${tokens.$metadata.version}
 * DO NOT EDIT MANUALLY
 */

import type { Config } from 'tailwindcss';

export const figmaTokens = ${JSON.stringify(theme, null, 2)} as const;

export const tailwindExtension: Partial<Config['theme']> = {
  extend: figmaTokens
};

export default figmaTokens;
`;
  }

  private buildTailwindTheme(tokens: DesignTokenSet): Record<string, unknown> {
    const theme: Record<string, unknown> = {
      colors: this.extractColors(tokens),
      spacing: this.extractSpacing(tokens),
      fontSize: this.extractTypography(tokens),
      borderRadius: this.extractBorderRadius(tokens),
      boxShadow: this.extractShadows(tokens),
    };

    return theme;
  }

  private extractColors(tokens: DesignTokenSet): Record<string, string | Record<string, string>> {
    const colors: Record<string, string | Record<string, string>> = {};
    
    const processColorTokens = (group: TokenGroup, prefix: string = '') => {
      if (!group.color) return;
      
      for (const [name, token] of Object.entries(group.color)) {
        const varName = prefix ? `${prefix}-color-${name}` : `color-${name}`;
        colors[name] = `var(--${varName.replace(/[^a-z0-9-]/gi, '-').toLowerCase()})`;
      }
    };

    processColorTokens(tokens.primitives, 'primitive');
    processColorTokens(tokens.semantic, 'semantic');

    return colors;
  }

  private extractSpacing(tokens: DesignTokenSet): Record<string, string> {
    const spacing: Record<string, string> = {};
    
    const processSpacingTokens = (group: TokenGroup, prefix: string) => {
      if (!group.spacing) return;
      
      for (const [name, token] of Object.entries(group.spacing)) {
        const varName = `${prefix}-spacing-${name}`.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
        spacing[name] = `var(--${varName})`;
      }
    };

    processSpacingTokens(tokens.primitives, 'primitive');
    processSpacingTokens(tokens.semantic, 'semantic');

    return spacing;
  }

  private extractTypography(tokens: DesignTokenSet): Record<string, [string, { lineHeight: string }]> {
    const fontSize: Record<string, [string, { lineHeight: string }]> = {};
    
    const processTypography = (group: TokenGroup, prefix: string) => {
      if (!group.typography) return;
      
      for (const [name, token] of Object.entries(group.typography)) {
        if (typeof token.$value === 'number') {
          const varName = `${prefix}-typography-${name}`.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
          fontSize[name] = [`var(--${varName})`, { lineHeight: '1.5' }];
        }
      }
    };

    processTypography(tokens.primitives, 'primitive');
    processTypography(tokens.semantic, 'semantic');

    return fontSize;
  }

  private extractBorderRadius(tokens: DesignTokenSet): Record<string, string> {
    const borderRadius: Record<string, string> = {};
    
    const processBorderTokens = (group: TokenGroup, prefix: string) => {
      if (!group.border) return;
      
      for (const [name, token] of Object.entries(group.border)) {
        if (name.includes('radius')) {
          const varName = `${prefix}-border-${name}`.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
          borderRadius[name.replace('radius-', '')] = `var(--${varName})`;
        }
      }
    };

    processBorderTokens(tokens.primitives, 'primitive');
    processBorderTokens(tokens.semantic, 'semantic');

    return borderRadius;
  }

  private extractShadows(tokens: DesignTokenSet): Record<string, string> {
    const boxShadow: Record<string, string> = {};
    
    const processShadowTokens = (group: TokenGroup, prefix: string) => {
      if (!group.shadow) return;
      
      for (const [name, token] of Object.entries(group.shadow)) {
        const varName = `${prefix}-shadow-${name}`.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
        boxShadow[name] = `var(--${varName})`;
      }
    };

    processShadowTokens(tokens.primitives, 'primitive');
    processShadowTokens(tokens.semantic, 'semantic');

    return boxShadow;
  }
}

// ============================================================================
// TYPESCRIPT TRANSFORMER
// ============================================================================

export class TypeScriptTransformer {
  private config: TransformConfig;

  constructor(config: Partial<TransformConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Generate TypeScript type definitions for tokens
   */
  generateTypes(tokens: DesignTokenSet): string {
    const primitiveKeys = this.extractTokenKeys(tokens.primitives);
    const semanticKeys = this.extractTokenKeys(tokens.semantic);
    const componentKeys = this.extractTokenKeys(tokens.component);
    const brandIds = Object.keys(tokens.brand);

    return `/**
 * Design Token Type Definitions - Auto-generated from Figma
 * Source: ${tokens.$metadata.source}
 * Extracted: ${tokens.$metadata.extractedAt}
 * Version: ${tokens.$metadata.version}
 * DO NOT EDIT MANUALLY
 */

// Token Categories
export type TokenCategory = 'color' | 'spacing' | 'typography' | 'border' | 'shadow' | 'sizing' | 'motion' | 'misc';

// Primitive Token Keys
${this.generateTokenKeysType('PrimitiveTokenKey', primitiveKeys)}

// Semantic Token Keys
${this.generateTokenKeysType('SemanticTokenKey', semanticKeys)}

// Component Token Keys
${this.generateTokenKeysType('ComponentTokenKey', componentKeys)}

// Brand IDs
export type BrandId = ${brandIds.length > 0 ? brandIds.map(b => `'${b}'`).join(' | ') : 'string'};

// Token Value Types
export interface ColorValue {
  r: number;
  g: number;
  b: number;
  a: number;
}

export type TokenValue = string | number | ColorValue;

// Design Token Interface
export interface DesignToken {
  $value: TokenValue;
  $type: 'color' | 'dimension' | 'fontFamily' | 'fontWeight' | 'duration' | 'number' | 'shadow' | 'border';
  $description?: string;
  $extensions?: {
    'com.figma': {
      variableId: string;
      collectionId: string;
      scopes: string[];
      codeSyntax?: Record<string, string>;
    };
    'org.schema': {
      '@type': string;
      propertyID: string;
    };
  };
}

// Token Getter Functions
export type GetPrimitiveToken = (key: PrimitiveTokenKey) => DesignToken;
export type GetSemanticToken = (key: SemanticTokenKey) => DesignToken;
export type GetComponentToken = (key: ComponentTokenKey) => DesignToken;
export type GetBrandToken = (brandId: BrandId, key: SemanticTokenKey) => DesignToken;

// CSS Variable Helper
export type CSSVarName<T extends string> = \`--\${T}\`;
export type CSSVar<T extends string> = \`var(\${CSSVarName<T>})\`;

// Token Set Interface
export interface DesignTokenSet {
  $schema: string;
  $metadata: {
    source: string;
    fileKey: string;
    extractedAt: string;
    version: string;
  };
  primitives: Record<TokenCategory, Record<string, DesignToken>>;
  semantic: Record<TokenCategory, Record<string, DesignToken>>;
  component: Record<TokenCategory, Record<string, DesignToken>>;
  brand: Record<BrandId, Record<TokenCategory, Record<string, DesignToken>>>;
}
`;
  }

  private extractTokenKeys(group: TokenGroup): string[] {
    const keys: string[] = [];
    
    for (const [category, tokens] of Object.entries(group)) {
      for (const tokenName of Object.keys(tokens)) {
        keys.push(`${category}/${tokenName}`);
      }
    }
    
    return keys;
  }

  private generateTokenKeysType(typeName: string, keys: string[]): string {
    if (keys.length === 0) {
      return `export type ${typeName} = string;`;
    }
    
    const keyUnion = keys.map(k => `  | '${k}'`).join('\n');
    return `export type ${typeName} =\n${keyUnion};`;
  }
}

// ============================================================================
// SCHEMA.ORG TRANSFORMER
// ============================================================================

export class SchemaOrgTransformer {
  /**
   * Generate Schema.org compliant JSON-LD for design tokens
   */
  generateSchemaOrg(tokens: DesignTokenSet): object {
    return {
      '@context': {
        '@vocab': 'https://schema.org/',
        'design': 'https://design-tokens.github.io/community-group/',
        'figma': 'https://figma.com/ns/'
      },
      '@type': 'DefinedTermSet',
      '@id': `figma:design-system/${tokens.$metadata.fileKey}`,
      'name': 'Design Token System',
      'description': 'Figma design system tokens exported for production use',
      'dateCreated': tokens.$metadata.extractedAt,
      'version': tokens.$metadata.version,
      'provider': {
        '@type': 'Organization',
        'name': 'Figma',
        'url': 'https://figma.com'
      },
      'hasDefinedTerm': [
        ...this.mapTokensToSchemaOrg(tokens.primitives, 'Primitive'),
        ...this.mapTokensToSchemaOrg(tokens.semantic, 'Semantic'),
        ...this.mapTokensToSchemaOrg(tokens.component, 'Component'),
        ...Object.entries(tokens.brand).flatMap(([brandId, brandTokens]) =>
          this.mapTokensToSchemaOrg(brandTokens, `Brand:${brandId}`)
        )
      ]
    };
  }

  private mapTokensToSchemaOrg(group: TokenGroup, prefix: string): object[] {
    const terms: object[] = [];
    
    for (const [category, tokens] of Object.entries(group)) {
      for (const [name, token] of Object.entries(tokens)) {
        terms.push({
          '@type': 'DefinedTerm',
          '@id': `figma:token/${prefix}/${category}/${name}`,
          'name': name,
          'inDefinedTermSet': `figma:design-system`,
          'termCode': `${prefix.toLowerCase()}-${category}-${name}`,
          'description': token.$description || `${prefix} ${category} token`,
          'additionalProperty': [
            {
              '@type': 'PropertyValue',
              'propertyID': 'tokenValue',
              'value': this.stringifyValue(token.$value)
            },
            {
              '@type': 'PropertyValue',
              'propertyID': 'tokenType',
              'value': token.$type
            }
          ]
        });
      }
    }
    
    return terms;
  }

  private stringifyValue(value: unknown): string {
    if (typeof value === 'object' && value !== null) {
      const color = value as ColorValue;
      return `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a})`;
    }
    return String(value);
  }
}

// ============================================================================
// MAIN TRANSFORMER ORCHESTRATOR
// ============================================================================

export class TokenTransformer {
  private config: TransformConfig;
  private cssTransformer: CSSTransformer;
  private tailwindTransformer: TailwindTransformer;
  private typescriptTransformer: TypeScriptTransformer;
  private schemaOrgTransformer: SchemaOrgTransformer;

  constructor(config: Partial<TransformConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.cssTransformer = new CSSTransformer(this.config);
    this.tailwindTransformer = new TailwindTransformer(this.config);
    this.typescriptTransformer = new TypeScriptTransformer(this.config);
    this.schemaOrgTransformer = new SchemaOrgTransformer();
  }

  /**
   * Transform tokens and write all output files
   */
  async transform(tokens: DesignTokenSet): Promise<{
    css: string;
    tailwind: string;
    types: string;
    schema: object;
    json: DesignTokenSet;
  }> {
    const css = this.cssTransformer.generateCSS(tokens);
    const tailwind = this.tailwindTransformer.generateTailwindConfig(tokens);
    const types = this.typescriptTransformer.generateTypes(tokens);
    const schema = this.schemaOrgTransformer.generateSchemaOrg(tokens);

    return { css, tailwind, types, schema, json: tokens };
  }

  /**
   * Write all outputs to disk
   */
  async writeOutputs(tokens: DesignTokenSet): Promise<void> {
    const outputs = await this.transform(tokens);
    
    // Ensure output directory exists
    await fs.mkdir(this.config.outputDir, { recursive: true });

    // Write CSS
    await fs.writeFile(
      path.join(this.config.outputDir, this.config.cssFilename),
      outputs.css,
      'utf-8'
    );

    // Write Tailwind config
    await fs.writeFile(
      path.join(this.config.outputDir, this.config.tailwindFilename),
      outputs.tailwind,
      'utf-8'
    );

    // Write TypeScript definitions
    await fs.writeFile(
      path.join(this.config.outputDir, this.config.typesFilename),
      outputs.types,
      'utf-8'
    );

    // Write Schema.org JSON
    await fs.writeFile(
      path.join(this.config.outputDir, this.config.schemaFilename),
      JSON.stringify(outputs.schema, null, 2),
      'utf-8'
    );

    // Write raw tokens JSON
    await fs.writeFile(
      path.join(this.config.outputDir, 'tokens.json'),
      JSON.stringify(outputs.json, null, 2),
      'utf-8'
    );

    console.log(`✅ Token outputs written to ${this.config.outputDir}`);
  }
}

// ============================================================================
// FACTORY FUNCTION
// ============================================================================

export function createTokenTransformer(
  config: Partial<TransformConfig> = {}
): TokenTransformer {
  return new TokenTransformer(config);
}
