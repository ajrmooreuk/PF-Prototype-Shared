/**
 * Figma → Production UI → Agent Orchestration Pipeline
 * 
 * ARCHITECTURE OVERVIEW:
 * 
 * 1. FIGMA (Design Source)
 *    └── Human designers create UI/UX
 *    └── Define tokens, components, interactions
 *    └── Single source of truth for visual design
 * 
 * 2. DESIGN SYSTEM PIPELINE
 *    └── Extract tokens via Figma API (no plugins)
 *    └── Transform to CSS/Tailwind/TypeScript
 *    └── Generate Shadcn-compatible components
 * 
 * 3. PRODUCTION UI (Next.js + React + Shadcn)
 *    └── Built with extracted design system
 *    └── Maintains 100% fidelity to Figma designs
 *    └── Provides interaction points that TRIGGER agents
 * 
 * 4. AGENT ORCHESTRATION (Claude SDK)
 *    └── UI interactions trigger agent workflows
 *    └── Agents process data, make decisions, return results
 *    └── Results rendered back through design-system UI
 * 
 * KEY PRINCIPLE: Design is done in Figma by humans.
 * Agents are triggered BY the UI, they don't create the UI.
 * The design system ensures all outputs maintain visual consistency.
 */

// ============================================================================
// LAYER 1: DESIGN SYSTEM EXTRACTION
// ============================================================================

export interface DesignSystemConfig {
  figma: {
    accessToken: string;
    fileKey: string;
    // Optional: specific pages/frames to extract
    targetNodes?: string[];
  };
  output: {
    tokensDir: string;
    componentsDir: string;
    typesDir: string;
  };
  brands?: {
    // Multi-tenant brand configurations
    [brandId: string]: {
      figmaModeId: string;
      name: string;
    };
  };
}

// ============================================================================
// LAYER 2: UI COMPONENT STRUCTURE
// Maps Figma components to React/Shadcn implementations
// ============================================================================

export interface UIComponentMapping {
  // Figma component key → React component path
  figmaKey: string;
  reactPath: string;
  
  // Props extracted from Figma component properties
  props: ComponentProp[];
  
  // Design tokens bound to this component
  tokenBindings: {
    [propName: string]: string; // prop → token path
  };
  
  // Variants from Figma
  variants: {
    [variantName: string]: {
      figmaVariant: string;
      cssClass?: string;
      tokenOverrides?: Record<string, string>;
    };
  };
}

export interface ComponentProp {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'enum' | 'slot';
  required: boolean;
  defaultValue?: unknown;
  enumValues?: string[];
  description?: string;
}

// ============================================================================
// LAYER 3: AGENT TRIGGER SYSTEM
// UI interactions that spawn agent workflows
// ============================================================================

export type AgentTriggerType = 
  | 'button_click'
  | 'form_submit'
  | 'file_upload'
  | 'selection_change'
  | 'navigation'
  | 'timer'
  | 'webhook'
  | 'realtime_event';

export interface AgentTrigger {
  id: string;
  type: AgentTriggerType;
  
  // Which UI element triggers this
  sourceComponent: string;
  sourceAction: string;
  
  // Which agent workflow to invoke
  workflowId: string;
  
  // Data to pass from UI to agent
  payloadSchema: {
    type: 'object';
    properties: Record<string, unknown>;
    required?: string[];
  };
  
  // How to handle the response
  responseHandler: {
    // Update UI state
    updateState?: string[];
    // Navigate somewhere
    navigate?: string;
    // Show notification
    notify?: { type: 'success' | 'error' | 'info'; message: string };
    // Render in specific component
    renderIn?: string;
  };
}

// ============================================================================
// LAYER 4: AGENT WORKFLOW DEFINITIONS
// P1-P16 Process Framework Integration
// ============================================================================

export interface AgentWorkflow {
  id: string;
  name: string;
  description: string;
  
  // Process phase (P1-P16)
  phase: `P${number}`;
  
  // Agent(s) involved
  agents: AgentDefinition[];
  
  // Input schema (what UI sends)
  inputSchema: object;
  
  // Output schema (what UI receives)
  outputSchema: object;
  
  // Steps in the workflow
  steps: WorkflowStep[];
  
  // Error handling
  errorHandler?: {
    retryCount: number;
    fallbackWorkflow?: string;
  };
}

export interface AgentDefinition {
  id: string;
  name: string;
  role: string;
  model: string;
  systemPrompt: string;
  tools: string[];
  
  // Design system context (for any UI generation)
  designContext?: {
    availableComponents: string[];
    tokenCategories: string[];
    brandId?: string;
  };
}

export interface WorkflowStep {
  id: string;
  type: 'agent_call' | 'tool_call' | 'condition' | 'parallel' | 'loop';
  agentId?: string;
  toolName?: string;
  input: Record<string, unknown>;
  output: string; // Variable name to store result
  next?: string | { [condition: string]: string };
}

// ============================================================================
// EXAMPLE: BAIV Platform Workflow Triggers
// ============================================================================

export const BAIV_WORKFLOW_TRIGGERS: AgentTrigger[] = [
  {
    id: 'trigger-discovery-scan',
    type: 'button_click',
    sourceComponent: 'molecules/discovery-panel',
    sourceAction: 'onStartScan',
    workflowId: 'P1-discovery-profiling',
    payloadSchema: {
      type: 'object',
      properties: {
        brandUrl: { type: 'string', format: 'uri' },
        competitors: { type: 'array', items: { type: 'string' } },
        scanDepth: { type: 'string', enum: ['quick', 'standard', 'deep'] }
      },
      required: ['brandUrl']
    },
    responseHandler: {
      updateState: ['discoveryResults', 'scanStatus'],
      notify: { type: 'success', message: 'Discovery scan complete' },
      renderIn: 'organisms/results-dashboard'
    }
  },
  {
    id: 'trigger-audit-report',
    type: 'form_submit',
    sourceComponent: 'organisms/audit-form',
    sourceAction: 'onSubmit',
    workflowId: 'P4-audit-analysis',
    payloadSchema: {
      type: 'object',
      properties: {
        brandId: { type: 'string' },
        auditType: { type: 'string', enum: ['full', 'content', 'technical', 'visibility'] },
        includeCompetitors: { type: 'boolean' }
      },
      required: ['brandId', 'auditType']
    },
    responseHandler: {
      updateState: ['auditReport', 'scores'],
      renderIn: 'templates/audit-report-view'
    }
  },
  {
    id: 'trigger-content-ideation',
    type: 'selection_change',
    sourceComponent: 'molecules/gap-selector',
    sourceAction: 'onGapSelected',
    workflowId: 'P7-ideation',
    payloadSchema: {
      type: 'object',
      properties: {
        gapId: { type: 'string' },
        gapType: { type: 'string' },
        context: { type: 'object' }
      },
      required: ['gapId']
    },
    responseHandler: {
      updateState: ['ideationSuggestions'],
      renderIn: 'organisms/ideation-panel'
    }
  }
];

// ============================================================================
// EXAMPLE: P1-P7 Core Workflow Definitions
// ============================================================================

export const CORE_WORKFLOWS: AgentWorkflow[] = [
  {
    id: 'P1-discovery-profiling',
    name: 'Discovery & Profiling',
    description: 'Initial brand discovery, Reddit scraping, competitor research',
    phase: 'P1',
    agents: [
      {
        id: 'discovery-agent',
        name: 'Discovery Agent',
        role: 'Research and profile brands and competitors',
        model: 'claude-sonnet-4-20250514',
        systemPrompt: `You are a brand discovery specialist. Analyze websites, 
          social presence, and market positioning. Extract key brand attributes,
          messaging, and competitive landscape.`,
        tools: ['web_scrape', 'reddit_search', 'serp_analysis', 'brand_extract']
      }
    ],
    inputSchema: {
      type: 'object',
      properties: {
        brandUrl: { type: 'string' },
        competitors: { type: 'array' },
        scanDepth: { type: 'string' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        brandProfile: { type: 'object' },
        competitorProfiles: { type: 'array' },
        marketPosition: { type: 'object' },
        opportunities: { type: 'array' }
      }
    },
    steps: [
      {
        id: 'scrape-brand',
        type: 'tool_call',
        toolName: 'web_scrape',
        input: { url: '{{input.brandUrl}}', depth: '{{input.scanDepth}}' },
        output: 'brandData'
      },
      {
        id: 'analyze-brand',
        type: 'agent_call',
        agentId: 'discovery-agent',
        input: { 
          task: 'analyze_brand',
          data: '{{brandData}}'
        },
        output: 'brandProfile'
      },
      {
        id: 'scrape-competitors',
        type: 'parallel',
        input: { urls: '{{input.competitors}}' },
        output: 'competitorData'
      },
      {
        id: 'competitive-analysis',
        type: 'agent_call',
        agentId: 'discovery-agent',
        input: {
          task: 'competitive_analysis',
          brand: '{{brandProfile}}',
          competitors: '{{competitorData}}'
        },
        output: 'analysis'
      }
    ]
  },
  {
    id: 'P2-capture',
    name: 'Content Capture',
    description: 'PAA detection, content inventory, SERP analysis',
    phase: 'P2',
    agents: [
      {
        id: 'capture-agent',
        name: 'Capture Agent',
        role: 'Capture and inventory existing content and search presence',
        model: 'claude-sonnet-4-20250514',
        systemPrompt: `You are a content capture specialist. Identify People Also Ask
          questions, inventory existing content, and analyze SERP presence.`,
        tools: ['paa_scrape', 'content_crawl', 'serp_api', 'schema_extract']
      }
    ],
    inputSchema: {
      type: 'object',
      properties: {
        brandId: { type: 'string' },
        keywords: { type: 'array' },
        contentUrls: { type: 'array' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        paaQuestions: { type: 'array' },
        contentInventory: { type: 'array' },
        serpPresence: { type: 'object' }
      }
    },
    steps: []
  },
  {
    id: 'P4-audit-analysis',
    name: 'Audit & Scoring',
    description: 'Brand scoring algorithms, visibility audit, technical analysis',
    phase: 'P4',
    agents: [
      {
        id: 'audit-agent',
        name: 'Audit Agent',
        role: 'Comprehensive brand and content auditing',
        model: 'claude-sonnet-4-20250514',
        systemPrompt: `You are a brand audit specialist. Score brands on AI visibility,
          content quality, technical SEO, and schema implementation.`,
        tools: ['lighthouse_audit', 'schema_validator', 'ai_visibility_score', 'content_analyzer']
      }
    ],
    inputSchema: {
      type: 'object',
      properties: {
        brandId: { type: 'string' },
        auditType: { type: 'string' },
        includeCompetitors: { type: 'boolean' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        overallScore: { type: 'number' },
        categoryScores: { type: 'object' },
        issues: { type: 'array' },
        recommendations: { type: 'array' }
      }
    },
    steps: []
  },
  {
    id: 'P7-ideation',
    name: 'Content Ideation',
    description: 'AI-driven content ideation based on gaps and opportunities',
    phase: 'P7',
    agents: [
      {
        id: 'ideation-agent',
        name: 'Ideation Agent',
        role: 'Generate content ideas to fill gaps and capture opportunities',
        model: 'claude-sonnet-4-20250514',
        systemPrompt: `You are a content strategist. Generate actionable content ideas
          based on identified gaps, competitor analysis, and AI visibility opportunities.`,
        tools: ['keyword_research', 'topic_cluster', 'content_brief_gen']
      }
    ],
    inputSchema: {
      type: 'object',
      properties: {
        gapId: { type: 'string' },
        gapType: { type: 'string' },
        context: { type: 'object' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        ideas: { type: 'array' },
        priorityScore: { type: 'number' },
        estimatedImpact: { type: 'object' }
      }
    },
    steps: []
  }
];

export default {
  BAIV_WORKFLOW_TRIGGERS,
  CORE_WORKFLOWS
};
