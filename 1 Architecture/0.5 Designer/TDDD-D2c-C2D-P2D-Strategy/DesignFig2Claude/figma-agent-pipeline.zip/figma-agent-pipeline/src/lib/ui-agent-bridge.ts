/**
 * UI-to-Agent Bridge
 * React hooks and context for triggering agent workflows from UI interactions
 * 
 * The UI is built with the design system (Figma tokens/components).
 * User interactions in the UI TRIGGER agent workflows.
 * Agent responses are rendered back through design-system components.
 */

import React, { createContext, useContext, useCallback, useReducer, useRef } from 'react';
import type { AgentTrigger, AgentWorkflow, WorkflowStep } from './architecture-overview';

// ============================================================================
// TYPES
// ============================================================================

export interface WorkflowState {
  status: 'idle' | 'running' | 'success' | 'error';
  currentStep?: string;
  progress: number;
  result?: unknown;
  error?: Error;
  startedAt?: Date;
  completedAt?: Date;
}

export interface AgentContextValue {
  // Trigger a workflow from UI
  triggerWorkflow: (triggerId: string, payload: Record<string, unknown>) => Promise<unknown>;
  
  // Get workflow state
  getWorkflowState: (workflowId: string) => WorkflowState | undefined;
  
  // Cancel running workflow
  cancelWorkflow: (workflowId: string) => void;
  
  // All active workflows
  activeWorkflows: Map<string, WorkflowState>;
  
  // Design system context (tokens available to agents)
  designContext: DesignContextForAgents;
}

export interface DesignContextForAgents {
  // Current brand (for multi-tenant)
  activeBrand: string;
  
  // Available tokens (subset relevant to agents)
  tokens: {
    colors: Record<string, string>;
    spacing: Record<string, string>;
    typography: Record<string, string>;
  };
  
  // Component library reference
  availableComponents: string[];
}

// ============================================================================
// WORKFLOW EXECUTOR
// ============================================================================

export class WorkflowExecutor {
  private workflows: Map<string, AgentWorkflow>;
  private triggers: Map<string, AgentTrigger>;
  private abortControllers: Map<string, AbortController>;

  constructor(
    workflows: AgentWorkflow[],
    triggers: AgentTrigger[]
  ) {
    this.workflows = new Map(workflows.map(w => [w.id, w]));
    this.triggers = new Map(triggers.map(t => [t.id, t]));
    this.abortControllers = new Map();
  }

  async execute(
    triggerId: string,
    payload: Record<string, unknown>,
    onProgress?: (step: string, progress: number) => void
  ): Promise<unknown> {
    const trigger = this.triggers.get(triggerId);
    if (!trigger) {
      throw new Error(`Unknown trigger: ${triggerId}`);
    }

    const workflow = this.workflows.get(trigger.workflowId);
    if (!workflow) {
      throw new Error(`Unknown workflow: ${trigger.workflowId}`);
    }

    // Validate payload against schema
    this.validatePayload(payload, trigger.payloadSchema);

    // Create abort controller for cancellation
    const abortController = new AbortController();
    this.abortControllers.set(workflow.id, abortController);

    try {
      const context: ExecutionContext = {
        input: payload,
        variables: {},
        signal: abortController.signal
      };

      // Execute workflow steps
      for (let i = 0; i < workflow.steps.length; i++) {
        const step = workflow.steps[i];
        
        if (abortController.signal.aborted) {
          throw new Error('Workflow cancelled');
        }

        onProgress?.(step.id, (i / workflow.steps.length) * 100);
        
        const result = await this.executeStep(step, context, workflow);
        context.variables[step.output] = result;
      }

      onProgress?.('complete', 100);
      return this.buildOutput(context.variables, workflow.outputSchema);

    } finally {
      this.abortControllers.delete(workflow.id);
    }
  }

  cancel(workflowId: string): void {
    const controller = this.abortControllers.get(workflowId);
    if (controller) {
      controller.abort();
    }
  }

  private validatePayload(
    payload: Record<string, unknown>,
    schema: AgentTrigger['payloadSchema']
  ): void {
    // Basic validation - in production use zod or ajv
    const required = schema.required || [];
    for (const field of required) {
      if (!(field in payload)) {
        throw new Error(`Missing required field: ${field}`);
      }
    }
  }

  private async executeStep(
    step: WorkflowStep,
    context: ExecutionContext,
    workflow: AgentWorkflow
  ): Promise<unknown> {
    // Resolve template variables in input
    const resolvedInput = this.resolveTemplates(step.input, context);

    switch (step.type) {
      case 'agent_call':
        return this.executeAgentCall(step, resolvedInput, workflow, context.signal);
      
      case 'tool_call':
        return this.executeToolCall(step, resolvedInput, context.signal);
      
      case 'parallel':
        return this.executeParallel(step, resolvedInput, context.signal);
      
      case 'condition':
        return this.evaluateCondition(step, context);
      
      case 'loop':
        return this.executeLoop(step, resolvedInput, workflow, context);
      
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }

  private async executeAgentCall(
    step: WorkflowStep,
    input: Record<string, unknown>,
    workflow: AgentWorkflow,
    signal: AbortSignal
  ): Promise<unknown> {
    const agent = workflow.agents.find(a => a.id === step.agentId);
    if (!agent) {
      throw new Error(`Unknown agent: ${step.agentId}`);
    }

    // Call Claude API
    const response = await fetch('/api/agent/invoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agentId: agent.id,
        model: agent.model,
        systemPrompt: agent.systemPrompt,
        tools: agent.tools,
        input,
        designContext: agent.designContext
      }),
      signal
    });

    if (!response.ok) {
      throw new Error(`Agent call failed: ${response.statusText}`);
    }

    return response.json();
  }

  private async executeToolCall(
    step: WorkflowStep,
    input: Record<string, unknown>,
    signal: AbortSignal
  ): Promise<unknown> {
    const response = await fetch('/api/tools/invoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tool: step.toolName,
        input
      }),
      signal
    });

    if (!response.ok) {
      throw new Error(`Tool call failed: ${response.statusText}`);
    }

    return response.json();
  }

  private async executeParallel(
    step: WorkflowStep,
    input: Record<string, unknown>,
    signal: AbortSignal
  ): Promise<unknown[]> {
    const items = input.urls as string[] || input.items as unknown[];
    
    const promises = items.map(item =>
      this.executeToolCall(
        { ...step, type: 'tool_call', toolName: 'web_scrape' },
        { url: item },
        signal
      )
    );

    return Promise.all(promises);
  }

  private evaluateCondition(
    step: WorkflowStep,
    context: ExecutionContext
  ): string {
    // Simple condition evaluation
    const conditions = step.next as { [condition: string]: string };
    
    for (const [condition, nextStep] of Object.entries(conditions)) {
      if (condition === 'default') continue;
      
      // Evaluate condition against context
      const result = this.evaluateExpression(condition, context);
      if (result) {
        return nextStep;
      }
    }

    return conditions.default || '';
  }

  private async executeLoop(
    step: WorkflowStep,
    input: Record<string, unknown>,
    workflow: AgentWorkflow,
    context: ExecutionContext
  ): Promise<unknown[]> {
    const items = input.items as unknown[];
    const results: unknown[] = [];

    for (const item of items) {
      if (context.signal.aborted) break;
      
      const iterContext = {
        ...context,
        variables: { ...context.variables, item }
      };
      
      // Execute nested steps if defined
      results.push(item);
    }

    return results;
  }

  private resolveTemplates(
    input: Record<string, unknown>,
    context: ExecutionContext
  ): Record<string, unknown> {
    const resolved: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(input)) {
      if (typeof value === 'string' && value.startsWith('{{') && value.endsWith('}}')) {
        const path = value.slice(2, -2).trim();
        resolved[key] = this.getValueByPath(context, path);
      } else if (typeof value === 'object' && value !== null) {
        resolved[key] = this.resolveTemplates(value as Record<string, unknown>, context);
      } else {
        resolved[key] = value;
      }
    }

    return resolved;
  }

  private getValueByPath(context: ExecutionContext, path: string): unknown {
    const parts = path.split('.');
    let current: unknown = context;

    for (const part of parts) {
      if (current === null || current === undefined) return undefined;
      current = (current as Record<string, unknown>)[part];
    }

    return current;
  }

  private evaluateExpression(expression: string, context: ExecutionContext): boolean {
    // Simple expression evaluation - in production use a proper expression parser
    try {
      const fn = new Function('ctx', `with(ctx) { return ${expression}; }`);
      return fn({ ...context.input, ...context.variables });
    } catch {
      return false;
    }
  }

  private buildOutput(
    variables: Record<string, unknown>,
    schema: object
  ): unknown {
    // Map variables to output schema
    return variables;
  }
}

interface ExecutionContext {
  input: Record<string, unknown>;
  variables: Record<string, unknown>;
  signal: AbortSignal;
}

// ============================================================================
// REACT CONTEXT & HOOKS
// ============================================================================

const AgentContext = createContext<AgentContextValue | null>(null);

interface AgentProviderProps {
  children: React.ReactNode;
  workflows: AgentWorkflow[];
  triggers: AgentTrigger[];
  designContext: DesignContextForAgents;
}

type WorkflowAction =
  | { type: 'START'; workflowId: string }
  | { type: 'PROGRESS'; workflowId: string; step: string; progress: number }
  | { type: 'SUCCESS'; workflowId: string; result: unknown }
  | { type: 'ERROR'; workflowId: string; error: Error }
  | { type: 'CANCEL'; workflowId: string };

function workflowReducer(
  state: Map<string, WorkflowState>,
  action: WorkflowAction
): Map<string, WorkflowState> {
  const newState = new Map(state);

  switch (action.type) {
    case 'START':
      newState.set(action.workflowId, {
        status: 'running',
        progress: 0,
        startedAt: new Date()
      });
      break;

    case 'PROGRESS':
      const current = newState.get(action.workflowId);
      if (current) {
        newState.set(action.workflowId, {
          ...current,
          currentStep: action.step,
          progress: action.progress
        });
      }
      break;

    case 'SUCCESS':
      newState.set(action.workflowId, {
        status: 'success',
        progress: 100,
        result: action.result,
        completedAt: new Date()
      });
      break;

    case 'ERROR':
      newState.set(action.workflowId, {
        status: 'error',
        progress: 0,
        error: action.error,
        completedAt: new Date()
      });
      break;

    case 'CANCEL':
      newState.delete(action.workflowId);
      break;
  }

  return newState;
}

export function AgentProvider({
  children,
  workflows,
  triggers,
  designContext
}: AgentProviderProps) {
  const [activeWorkflows, dispatch] = useReducer(
    workflowReducer,
    new Map<string, WorkflowState>()
  );

  const executorRef = useRef<WorkflowExecutor>();
  if (!executorRef.current) {
    executorRef.current = new WorkflowExecutor(workflows, triggers);
  }

  const triggerWorkflow = useCallback(
    async (triggerId: string, payload: Record<string, unknown>) => {
      const trigger = triggers.find(t => t.id === triggerId);
      if (!trigger) {
        throw new Error(`Unknown trigger: ${triggerId}`);
      }

      dispatch({ type: 'START', workflowId: trigger.workflowId });

      try {
        const result = await executorRef.current!.execute(
          triggerId,
          payload,
          (step, progress) => {
            dispatch({
              type: 'PROGRESS',
              workflowId: trigger.workflowId,
              step,
              progress
            });
          }
        );

        dispatch({ type: 'SUCCESS', workflowId: trigger.workflowId, result });
        return result;
      } catch (error) {
        dispatch({
          type: 'ERROR',
          workflowId: trigger.workflowId,
          error: error as Error
        });
        throw error;
      }
    },
    [triggers]
  );

  const cancelWorkflow = useCallback((workflowId: string) => {
    executorRef.current?.cancel(workflowId);
    dispatch({ type: 'CANCEL', workflowId });
  }, []);

  const getWorkflowState = useCallback(
    (workflowId: string) => activeWorkflows.get(workflowId),
    [activeWorkflows]
  );

  const value: AgentContextValue = {
    triggerWorkflow,
    getWorkflowState,
    cancelWorkflow,
    activeWorkflows,
    designContext
  };

  return (
    <AgentContext.Provider value={value}>
      {children}
    </AgentContext.Provider>
  );
}

// ============================================================================
// HOOKS FOR UI COMPONENTS
// ============================================================================

/**
 * Hook to trigger agent workflows from UI components
 */
export function useAgentTrigger(triggerId: string) {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useAgentTrigger must be used within AgentProvider');
  }

  const trigger = useCallback(
    (payload: Record<string, unknown>) => context.triggerWorkflow(triggerId, payload),
    [context, triggerId]
  );

  return { trigger };
}

/**
 * Hook to monitor workflow state
 */
export function useWorkflowState(workflowId: string) {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useWorkflowState must be used within AgentProvider');
  }

  return {
    state: context.getWorkflowState(workflowId),
    cancel: () => context.cancelWorkflow(workflowId)
  };
}

/**
 * Hook to get design context for conditional rendering
 */
export function useDesignContext() {
  const context = useContext(AgentContext);
  if (!context) {
    throw new Error('useDesignContext must be used within AgentProvider');
  }

  return context.designContext;
}

/**
 * Higher-order component to connect UI component to agent trigger
 */
export function withAgentTrigger<P extends object>(
  Component: React.ComponentType<P & { onTrigger: (payload: Record<string, unknown>) => Promise<unknown> }>,
  triggerId: string
) {
  return function WithAgentTrigger(props: P) {
    const { trigger } = useAgentTrigger(triggerId);
    return <Component {...props} onTrigger={trigger} />;
  };
}

export { AgentContext };
