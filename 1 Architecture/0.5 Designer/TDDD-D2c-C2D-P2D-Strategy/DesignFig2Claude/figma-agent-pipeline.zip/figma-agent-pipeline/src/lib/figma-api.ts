/**
 * Figma REST API Client
 * Direct token extraction without third-party plugins
 * 
 * @schema https://schema.org/SoftwareApplication
 */

import { z } from 'zod';

// ============================================================================
// TYPE DEFINITIONS (Schema.org aligned)
// ============================================================================

export const FigmaVariableSchema = z.object({
  id: z.string(),
  name: z.string(),
  key: z.string(),
  variableCollectionId: z.string(),
  resolvedType: z.enum(['BOOLEAN', 'FLOAT', 'STRING', 'COLOR']),
  valuesByMode: z.record(z.string(), z.unknown()),
  description: z.string().optional(),
  hiddenFromPublishing: z.boolean().optional(),
  scopes: z.array(z.string()).optional(),
  codeSyntax: z.record(z.string(), z.string()).optional()
});

export const FigmaVariableCollectionSchema = z.object({
  id: z.string(),
  name: z.string(),
  key: z.string(),
  modes: z.array(z.object({
    modeId: z.string(),
    name: z.string()
  })),
  defaultModeId: z.string(),
  remote: z.boolean(),
  hiddenFromPublishing: z.boolean()
});

export const FigmaColorSchema = z.object({
  r: z.number(),
  g: z.number(),
  b: z.number(),
  a: z.number().optional()
});

export const FigmaStyleSchema = z.object({
  key: z.string(),
  name: z.string(),
  styleType: z.enum(['FILL', 'TEXT', 'EFFECT', 'GRID']),
  description: z.string().optional()
});

export const FigmaComponentSchema = z.object({
  key: z.string(),
  name: z.string(),
  description: z.string().optional(),
  componentSetId: z.string().optional(),
  documentationLinks: z.array(z.object({
    uri: z.string()
  })).optional()
});

export type FigmaVariable = z.infer<typeof FigmaVariableSchema>;
export type FigmaVariableCollection = z.infer<typeof FigmaVariableCollectionSchema>;
export type FigmaColor = z.infer<typeof FigmaColorSchema>;
export type FigmaStyle = z.infer<typeof FigmaStyleSchema>;
export type FigmaComponent = z.infer<typeof FigmaComponentSchema>;

// ============================================================================
// API RESPONSE TYPES
// ============================================================================

interface FigmaVariablesResponse {
  status: number;
  error: boolean;
  meta: {
    variables: Record<string, FigmaVariable>;
    variableCollections: Record<string, FigmaVariableCollection>;
  };
}

interface FigmaStylesResponse {
  status: number;
  error: boolean;
  meta: {
    styles: Record<string, FigmaStyle>;
  };
}

interface FigmaComponentsResponse {
  status: number;
  error: boolean;
  meta: {
    components: Record<string, FigmaComponent>;
  };
}

interface FigmaFileResponse {
  document: {
    children: FigmaNode[];
  };
  components: Record<string, FigmaComponent>;
  styles: Record<string, FigmaStyle>;
  name: string;
  lastModified: string;
  version: string;
}

interface FigmaNode {
  id: string;
  name: string;
  type: string;
  children?: FigmaNode[];
  fills?: FigmaFill[];
  strokes?: FigmaStroke[];
  effects?: FigmaEffect[];
  style?: FigmaTextStyle;
  boundVariables?: Record<string, FigmaVariableBinding>;
}

interface FigmaFill {
  type: string;
  color?: FigmaColor;
  boundVariables?: Record<string, FigmaVariableBinding>;
}

interface FigmaStroke {
  type: string;
  color?: FigmaColor;
}

interface FigmaEffect {
  type: string;
  color?: FigmaColor;
  offset?: { x: number; y: number };
  radius?: number;
}

interface FigmaTextStyle {
  fontFamily: string;
  fontWeight: number;
  fontSize: number;
  lineHeightPx: number;
  letterSpacing: number;
}

interface FigmaVariableBinding {
  type: 'VARIABLE_ALIAS';
  id: string;
}

// ============================================================================
// FIGMA API CLIENT
// ============================================================================

export class FigmaAPIClient {
  private readonly baseUrl = 'https://api.figma.com/v1';
  private readonly accessToken: string;
  private readonly fileKey: string;

  constructor(config: { accessToken: string; fileKey: string }) {
    this.accessToken = config.accessToken;
    this.fileKey = config.fileKey;
  }

  private async request<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'X-Figma-Token': this.accessToken
      }
    });

    if (!response.ok) {
      throw new Error(`Figma API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  /**
   * Fetch all local variables and collections
   * This is the primary method for design token extraction
   */
  async getVariables(): Promise<{
    variables: FigmaVariable[];
    collections: FigmaVariableCollection[];
  }> {
    const response = await this.request<FigmaVariablesResponse>(
      `/files/${this.fileKey}/variables/local`
    );

    return {
      variables: Object.values(response.meta.variables),
      collections: Object.values(response.meta.variableCollections)
    };
  }

  /**
   * Fetch published styles (colors, typography, effects)
   */
  async getStyles(): Promise<FigmaStyle[]> {
    const response = await this.request<FigmaStylesResponse>(
      `/files/${this.fileKey}/styles`
    );

    return Object.values(response.meta.styles);
  }

  /**
   * Fetch component metadata
   */
  async getComponents(): Promise<FigmaComponent[]> {
    const response = await this.request<FigmaComponentsResponse>(
      `/files/${this.fileKey}/components`
    );

    return Object.values(response.meta.components);
  }

  /**
   * Fetch full file structure (for component properties and bindings)
   */
  async getFile(): Promise<FigmaFileResponse> {
    return this.request<FigmaFileResponse>(`/files/${this.fileKey}`);
  }

  /**
   * Fetch specific nodes by ID
   */
  async getNodes(nodeIds: string[]): Promise<Record<string, FigmaNode>> {
    const ids = nodeIds.join(',');
    const response = await this.request<{ nodes: Record<string, { document: FigmaNode }> }>(
      `/files/${this.fileKey}/nodes?ids=${ids}`
    );

    return Object.fromEntries(
      Object.entries(response.nodes).map(([id, data]) => [id, data.document])
    );
  }
}

// ============================================================================
// EXTRACTED DATA STRUCTURES (W3C Design Token Community Group format)
// ============================================================================

export interface DesignTokenSet {
  $schema: string;
  $metadata: {
    source: 'figma';
    fileKey: string;
    extractedAt: string;
    version: string;
  };
  primitives: TokenGroup;
  semantic: TokenGroup;
  component: TokenGroup;
  brand: BrandTokenGroup;
}

export interface TokenGroup {
  [category: string]: {
    [token: string]: DesignToken;
  };
}

export interface BrandTokenGroup {
  [brandId: string]: TokenGroup;
}

export interface DesignToken {
  $value: string | number | ColorValue;
  $type: 'color' | 'dimension' | 'fontFamily' | 'fontWeight' | 'duration' | 'number' | 'shadow' | 'border';
  $description?: string;
  $extensions?: {
    'com.figma': {
      variableId: string;
      collectionId: string;
      scopes: string[];
      codeSyntax?: Record<string, string>;
    };
    'org.schema': {
      '@type': string;
      propertyID: string;
    };
  };
}

export interface ColorValue {
  r: number;
  g: number;
  b: number;
  a: number;
}

// ============================================================================
// TOKEN EXTRACTION ENGINE
// ============================================================================

export class FigmaTokenExtractor {
  private client: FigmaAPIClient;

  constructor(client: FigmaAPIClient) {
    this.client = client;
  }

  /**
   * Extract all design tokens from Figma file
   */
  async extractTokens(): Promise<DesignTokenSet> {
    const { variables, collections } = await this.client.getVariables();
    const file = await this.client.getFile();

    // Map collections by ID for quick lookup
    const collectionMap = new Map(collections.map(c => [c.id, c]));

    // Categorize variables by collection name
    const tokenSet: DesignTokenSet = {
      $schema: 'https://design-tokens.github.io/community-group/format/',
      $metadata: {
        source: 'figma',
        fileKey: process.env.FIGMA_FILE_KEY || '',
        extractedAt: new Date().toISOString(),
        version: file.version
      },
      primitives: {},
      semantic: {},
      component: {},
      brand: {}
    };

    for (const variable of variables) {
      const collection = collectionMap.get(variable.variableCollectionId);
      if (!collection) continue;

      const token = this.convertVariableToToken(variable, collection);
      const category = this.categorizeToken(variable.name);
      const collectionName = collection.name.toLowerCase();

      if (collectionName === 'primitives' || collectionName === 'primitive') {
        this.assignToken(tokenSet.primitives, category, variable.name, token);
      } else if (collectionName === 'semantic') {
        this.assignToken(tokenSet.semantic, category, variable.name, token);
      } else if (collectionName === 'component' || collectionName === 'components') {
        this.assignToken(tokenSet.component, category, variable.name, token);
      } else if (collectionName === 'brand' || collectionName === 'brands') {
        // Handle multi-mode brand tokens
        for (const mode of collection.modes) {
          const brandId = mode.name.toLowerCase().replace(/\s+/g, '-');
          if (!tokenSet.brand[brandId]) {
            tokenSet.brand[brandId] = {};
          }
          
          const modeValue = variable.valuesByMode[mode.modeId];
          const brandToken = {
            ...token,
            $value: this.convertValue(modeValue, variable.resolvedType)
          };
          
          this.assignToken(tokenSet.brand[brandId], category, variable.name, brandToken);
        }
      }
    }

    return tokenSet;
  }

  private convertVariableToToken(
    variable: FigmaVariable,
    collection: FigmaVariableCollection
  ): DesignToken {
    const defaultModeValue = variable.valuesByMode[collection.defaultModeId];
    
    return {
      $value: this.convertValue(defaultModeValue, variable.resolvedType),
      $type: this.mapResolvedType(variable.resolvedType),
      $description: variable.description,
      $extensions: {
        'com.figma': {
          variableId: variable.id,
          collectionId: variable.variableCollectionId,
          scopes: variable.scopes || [],
          codeSyntax: variable.codeSyntax
        },
        'org.schema': {
          '@type': 'PropertyValue',
          propertyID: `figma:${variable.key}`
        }
      }
    };
  }

  private convertValue(
    value: unknown,
    type: FigmaVariable['resolvedType']
  ): string | number | ColorValue {
    if (type === 'COLOR' && typeof value === 'object' && value !== null) {
      const color = value as FigmaColor;
      return {
        r: Math.round(color.r * 255),
        g: Math.round(color.g * 255),
        b: Math.round(color.b * 255),
        a: color.a ?? 1
      };
    }

    if (type === 'FLOAT' && typeof value === 'number') {
      return value;
    }

    if (type === 'STRING' && typeof value === 'string') {
      return value;
    }

    if (type === 'BOOLEAN') {
      return value ? 1 : 0;
    }

    // Handle variable aliases
    if (typeof value === 'object' && value !== null && 'type' in value) {
      const alias = value as { type: string; id: string };
      if (alias.type === 'VARIABLE_ALIAS') {
        return `{${alias.id}}`;
      }
    }

    return String(value);
  }

  private mapResolvedType(type: FigmaVariable['resolvedType']): DesignToken['$type'] {
    const typeMap: Record<string, DesignToken['$type']> = {
      COLOR: 'color',
      FLOAT: 'dimension',
      STRING: 'fontFamily',
      BOOLEAN: 'number'
    };
    return typeMap[type] || 'number';
  }

  private categorizeToken(name: string): string {
    const lowerName = name.toLowerCase();
    
    if (lowerName.includes('color') || lowerName.includes('fill') || lowerName.includes('bg') || lowerName.includes('background')) {
      return 'color';
    }
    if (lowerName.includes('spacing') || lowerName.includes('gap') || lowerName.includes('margin') || lowerName.includes('padding')) {
      return 'spacing';
    }
    if (lowerName.includes('font') || lowerName.includes('text') || lowerName.includes('typography')) {
      return 'typography';
    }
    if (lowerName.includes('radius') || lowerName.includes('corner') || lowerName.includes('border')) {
      return 'border';
    }
    if (lowerName.includes('shadow') || lowerName.includes('elevation')) {
      return 'shadow';
    }
    if (lowerName.includes('size') || lowerName.includes('width') || lowerName.includes('height')) {
      return 'sizing';
    }
    if (lowerName.includes('duration') || lowerName.includes('timing') || lowerName.includes('animation')) {
      return 'motion';
    }
    
    return 'misc';
  }

  private assignToken(
    group: TokenGroup,
    category: string,
    name: string,
    token: DesignToken
  ): void {
    if (!group[category]) {
      group[category] = {};
    }
    
    // Convert Figma naming convention (e.g., "color/primary/500") to flat key
    const tokenKey = name.replace(/\//g, '-').toLowerCase();
    group[category][tokenKey] = token;
  }
}

// ============================================================================
// FACTORY FUNCTION
// ============================================================================

export function createFigmaClient(): FigmaAPIClient {
  const accessToken = process.env.FIGMA_ACCESS_TOKEN;
  const fileKey = process.env.FIGMA_FILE_KEY;

  if (!accessToken || !fileKey) {
    throw new Error(
      'Missing required environment variables: FIGMA_ACCESS_TOKEN and FIGMA_FILE_KEY'
    );
  }

  return new FigmaAPIClient({ accessToken, fileKey });
}

export function createTokenExtractor(): FigmaTokenExtractor {
  return new FigmaTokenExtractor(createFigmaClient());
}
