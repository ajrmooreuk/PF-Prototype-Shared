/**
 * Design System Agent
 * Claude Agent SDK integration for design-aware component generation
 * 
 * @schema https://schema.org/SoftwareAgent
 */

import Anthropic from '@anthropic-ai/sdk';
import type { DesignTokenSet, TokenGroup, DesignToken } from '../lib/figma-api';

// ============================================================================
// AGENT CONFIGURATION
// ============================================================================

export interface DesignAgentConfig {
  apiKey: string;
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

const DEFAULT_CONFIG: Required<Omit<DesignAgentConfig, 'apiKey'>> = {
  model: 'claude-sonnet-4-20250514',
  maxTokens: 4096,
  temperature: 0.3
};

// ============================================================================
// DESIGN CONTEXT BUILDER
// ============================================================================

export interface DesignContext {
  tokens: DesignTokenSet;
  activeBrand?: string;
  componentSpecs?: ComponentSpec[];
  constraints?: DesignConstraint[];
}

export interface ComponentSpec {
  name: string;
  category: 'atom' | 'molecule' | 'organism' | 'template';
  variants: string[];
  props: PropSpec[];
  figmaNodeId?: string;
}

export interface PropSpec {
  name: string;
  type: string;
  required: boolean;
  defaultValue?: unknown;
  tokenBinding?: string;
}

export interface DesignConstraint {
  type: 'color' | 'spacing' | 'typography' | 'accessibility';
  rule: string;
  severity: 'error' | 'warning' | 'info';
}

export class DesignContextBuilder {
  private tokens: DesignTokenSet | null = null;
  private activeBrand: string | null = null;
  private componentSpecs: ComponentSpec[] = [];
  private constraints: DesignConstraint[] = [];

  /**
   * Load design tokens into context
   */
  withTokens(tokens: DesignTokenSet): this {
    this.tokens = tokens;
    return this;
  }

  /**
   * Set active brand for multi-tenant scenarios
   */
  withBrand(brandId: string): this {
    this.activeBrand = brandId;
    return this;
  }

  /**
   * Add component specifications
   */
  withComponents(specs: ComponentSpec[]): this {
    this.componentSpecs = specs;
    return this;
  }

  /**
   * Add design constraints
   */
  withConstraints(constraints: DesignConstraint[]): this {
    this.constraints = constraints;
    return this;
  }

  /**
   * Build the complete context
   */
  build(): DesignContext {
    if (!this.tokens) {
      throw new Error('Design tokens are required');
    }

    return {
      tokens: this.tokens,
      activeBrand: this.activeBrand ?? undefined,
      componentSpecs: this.componentSpecs.length > 0 ? this.componentSpecs : undefined,
      constraints: this.constraints.length > 0 ? this.constraints : undefined
    };
  }

  /**
   * Generate system prompt with design context
   */
  buildSystemPrompt(): string {
    if (!this.tokens) {
      throw new Error('Design tokens are required');
    }

    const sections: string[] = [
      '# Design System Context',
      '',
      'You are a design-aware AI assistant with deep knowledge of the design system.',
      'All generated components MUST adhere to the design tokens and constraints provided.',
      '',
      '## Design Tokens',
      '',
      this.formatTokensForPrompt(),
      ''
    ];

    if (this.activeBrand) {
      sections.push(
        '## Active Brand',
        '',
        `Current brand context: **${this.activeBrand}**`,
        'Use brand-specific token overrides when available.',
        ''
      );
    }

    if (this.componentSpecs.length > 0) {
      sections.push(
        '## Component Specifications',
        '',
        this.formatComponentSpecsForPrompt(),
        ''
      );
    }

    if (this.constraints.length > 0) {
      sections.push(
        '## Design Constraints',
        '',
        this.formatConstraintsForPrompt(),
        ''
      );
    }

    sections.push(
      '## Code Generation Rules',
      '',
      '1. Always use CSS custom properties (var(--token-name)) for design values',
      '2. Never hardcode colors, spacing, or typography values',
      '3. Ensure accessibility compliance (WCAG 2.1 AA minimum)',
      '4. Use semantic HTML elements appropriately',
      '5. Include TypeScript types for all components',
      '6. Follow atomic design methodology for component organization',
      ''
    );

    return sections.join('\n');
  }

  private formatTokensForPrompt(): string {
    if (!this.tokens) return '';

    const lines: string[] = [
      '### Available Tokens',
      '',
      '#### Primitives'
    ];

    lines.push(this.formatTokenGroupCompact(this.tokens.primitives));
    
    lines.push('', '#### Semantic');
    lines.push(this.formatTokenGroupCompact(this.tokens.semantic));

    if (this.activeBrand && this.tokens.brand[this.activeBrand]) {
      lines.push('', `#### Brand: ${this.activeBrand}`);
      lines.push(this.formatTokenGroupCompact(this.tokens.brand[this.activeBrand]));
    }

    return lines.join('\n');
  }

  private formatTokenGroupCompact(group: TokenGroup): string {
    const lines: string[] = [];
    
    for (const [category, tokens] of Object.entries(group)) {
      const tokenNames = Object.keys(tokens).slice(0, 10);
      const hasMore = Object.keys(tokens).length > 10;
      
      lines.push(`- **${category}**: ${tokenNames.join(', ')}${hasMore ? ', ...' : ''}`);
    }
    
    return lines.join('\n');
  }

  private formatComponentSpecsForPrompt(): string {
    return this.componentSpecs
      .map(spec => {
        const variantList = spec.variants.length > 0 
          ? `(variants: ${spec.variants.join(', ')})` 
          : '';
        return `- **${spec.name}** [${spec.category}] ${variantList}`;
      })
      .join('\n');
  }

  private formatConstraintsForPrompt(): string {
    return this.constraints
      .map(c => `- [${c.severity.toUpperCase()}] ${c.type}: ${c.rule}`)
      .join('\n');
  }
}

// ============================================================================
// TOOL DEFINITIONS
// ============================================================================

export const DESIGN_SYSTEM_TOOLS: Anthropic.Tool[] = [
  {
    name: 'get_design_tokens',
    description: 'Retrieve design tokens by category. Returns token names, values, and CSS variable names.',
    input_schema: {
      type: 'object' as const,
      properties: {
        category: {
          type: 'string',
          enum: ['color', 'spacing', 'typography', 'border', 'shadow', 'sizing', 'motion', 'all'],
          description: 'Token category to retrieve'
        },
        collection: {
          type: 'string',
          enum: ['primitives', 'semantic', 'component', 'brand'],
          description: 'Token collection (default: semantic)'
        },
        brandId: {
          type: 'string',
          description: 'Brand ID for brand-specific tokens (only when collection is "brand")'
        }
      },
      required: ['category']
    }
  },
  {
    name: 'get_component_spec',
    description: 'Retrieve component specification including props, variants, and token bindings.',
    input_schema: {
      type: 'object' as const,
      properties: {
        componentName: {
          type: 'string',
          description: 'Name of the component to retrieve'
        }
      },
      required: ['componentName']
    }
  },
  {
    name: 'validate_component',
    description: 'Validate generated component code against design system rules.',
    input_schema: {
      type: 'object' as const,
      properties: {
        code: {
          type: 'string',
          description: 'Component code to validate'
        },
        componentType: {
          type: 'string',
          enum: ['react', 'vue', 'svelte', 'html'],
          description: 'Framework type of the component'
        }
      },
      required: ['code', 'componentType']
    }
  },
  {
    name: 'generate_component',
    description: 'Generate a new component based on design specifications.',
    input_schema: {
      type: 'object' as const,
      properties: {
        name: {
          type: 'string',
          description: 'Component name'
        },
        category: {
          type: 'string',
          enum: ['atom', 'molecule', 'organism', 'template'],
          description: 'Atomic design category'
        },
        description: {
          type: 'string',
          description: 'Component purpose and functionality'
        },
        props: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              type: { type: 'string' },
              required: { type: 'boolean' },
              defaultValue: { type: 'string' }
            }
          },
          description: 'Component props specification'
        },
        variants: {
          type: 'array',
          items: { type: 'string' },
          description: 'Component variants (e.g., primary, secondary, outline)'
        }
      },
      required: ['name', 'category', 'description']
    }
  },
  {
    name: 'switch_brand_mode',
    description: 'Switch the active brand for multi-tenant token resolution.',
    input_schema: {
      type: 'object' as const,
      properties: {
        brandId: {
          type: 'string',
          description: 'Brand identifier to switch to'
        }
      },
      required: ['brandId']
    }
  }
];

// ============================================================================
// DESIGN SYSTEM AGENT
// ============================================================================

export class DesignSystemAgent {
  private client: Anthropic;
  private config: Required<Omit<DesignAgentConfig, 'apiKey'>>;
  private context: DesignContext | null = null;
  private contextBuilder: DesignContextBuilder;

  constructor(config: DesignAgentConfig) {
    this.client = new Anthropic({ apiKey: config.apiKey });
    this.config = {
      model: config.model ?? DEFAULT_CONFIG.model,
      maxTokens: config.maxTokens ?? DEFAULT_CONFIG.maxTokens,
      temperature: config.temperature ?? DEFAULT_CONFIG.temperature
    };
    this.contextBuilder = new DesignContextBuilder();
  }

  /**
   * Initialize agent with design context
   */
  initialize(tokens: DesignTokenSet, options: {
    brandId?: string;
    components?: ComponentSpec[];
    constraints?: DesignConstraint[];
  } = {}): void {
    this.contextBuilder.withTokens(tokens);
    
    if (options.brandId) {
      this.contextBuilder.withBrand(options.brandId);
    }
    if (options.components) {
      this.contextBuilder.withComponents(options.components);
    }
    if (options.constraints) {
      this.contextBuilder.withConstraints(options.constraints);
    }

    this.context = this.contextBuilder.build();
  }

  /**
   * Process a design-related request
   */
  async process(userMessage: string): Promise<AgentResponse> {
    if (!this.context) {
      throw new Error('Agent not initialized. Call initialize() first.');
    }

    const systemPrompt = this.contextBuilder.buildSystemPrompt();
    
    const messages: Anthropic.MessageParam[] = [
      { role: 'user', content: userMessage }
    ];

    const response = await this.client.messages.create({
      model: this.config.model,
      max_tokens: this.config.maxTokens,
      temperature: this.config.temperature,
      system: systemPrompt,
      tools: DESIGN_SYSTEM_TOOLS,
      messages
    });

    return this.processResponse(response, messages);
  }

  private async processResponse(
    response: Anthropic.Message,
    messages: Anthropic.MessageParam[]
  ): Promise<AgentResponse> {
    const result: AgentResponse = {
      content: '',
      toolCalls: [],
      generatedCode: null
    };

    // Process response content
    for (const block of response.content) {
      if (block.type === 'text') {
        result.content += block.text;
      } else if (block.type === 'tool_use') {
        const toolResult = await this.executeToolCall(block);
        result.toolCalls.push({
          name: block.name,
          input: block.input as Record<string, unknown>,
          result: toolResult
        });

        // Continue conversation with tool result
        if (response.stop_reason === 'tool_use') {
          const updatedMessages: Anthropic.MessageParam[] = [
            ...messages,
            { role: 'assistant', content: response.content },
            {
              role: 'user',
              content: [
                {
                  type: 'tool_result',
                  tool_use_id: block.id,
                  content: JSON.stringify(toolResult)
                }
              ]
            }
          ];

          const continuedResponse = await this.client.messages.create({
            model: this.config.model,
            max_tokens: this.config.maxTokens,
            temperature: this.config.temperature,
            system: this.contextBuilder.buildSystemPrompt(),
            tools: DESIGN_SYSTEM_TOOLS,
            messages: updatedMessages
          });

          const continuedResult = await this.processResponse(
            continuedResponse,
            updatedMessages
          );
          
          result.content += continuedResult.content;
          result.toolCalls.push(...continuedResult.toolCalls);
          result.generatedCode = continuedResult.generatedCode ?? result.generatedCode;
        }
      }
    }

    // Extract generated code if present
    const codeMatch = result.content.match(/```(?:tsx?|jsx?|html)\n([\s\S]*?)```/);
    if (codeMatch) {
      result.generatedCode = codeMatch[1].trim();
    }

    return result;
  }

  private async executeToolCall(
    toolCall: Anthropic.ToolUseBlock
  ): Promise<unknown> {
    if (!this.context) {
      throw new Error('Agent context not initialized');
    }

    const input = toolCall.input as Record<string, unknown>;

    switch (toolCall.name) {
      case 'get_design_tokens':
        return this.handleGetDesignTokens(input);
      
      case 'get_component_spec':
        return this.handleGetComponentSpec(input);
      
      case 'validate_component':
        return this.handleValidateComponent(input);
      
      case 'generate_component':
        return this.handleGenerateComponent(input);
      
      case 'switch_brand_mode':
        return this.handleSwitchBrandMode(input);
      
      default:
        return { error: `Unknown tool: ${toolCall.name}` };
    }
  }

  private handleGetDesignTokens(input: Record<string, unknown>): object {
    if (!this.context) return { error: 'Context not initialized' };

    const category = input.category as string;
    const collection = (input.collection as string) ?? 'semantic';
    const brandId = input.brandId as string | undefined;

    let tokenGroup: TokenGroup;

    if (collection === 'brand' && brandId) {
      tokenGroup = this.context.tokens.brand[brandId] ?? {};
    } else {
      tokenGroup = this.context.tokens[collection as keyof Pick<DesignTokenSet, 'primitives' | 'semantic' | 'component'>] ?? {};
    }

    if (category === 'all') {
      return {
        tokens: tokenGroup,
        cssVariables: this.generateCSSVariableMap(tokenGroup)
      };
    }

    const categoryTokens = tokenGroup[category] ?? {};
    return {
      category,
      tokens: categoryTokens,
      cssVariables: this.generateCSSVariableMap({ [category]: categoryTokens })
    };
  }

  private handleGetComponentSpec(input: Record<string, unknown>): object {
    if (!this.context?.componentSpecs) {
      return { error: 'No component specs available' };
    }

    const componentName = input.componentName as string;
    const spec = this.context.componentSpecs.find(
      s => s.name.toLowerCase() === componentName.toLowerCase()
    );

    if (!spec) {
      return { 
        error: `Component "${componentName}" not found`,
        available: this.context.componentSpecs.map(s => s.name)
      };
    }

    return { spec };
  }

  private handleValidateComponent(input: Record<string, unknown>): object {
    const code = input.code as string;
    const violations: string[] = [];

    // Check for hardcoded colors
    const colorPatterns = [
      /#[0-9a-fA-F]{3,8}/g,
      /rgb\([^)]+\)/g,
      /rgba\([^)]+\)/g,
      /hsl\([^)]+\)/g
    ];

    for (const pattern of colorPatterns) {
      const matches = code.match(pattern);
      if (matches) {
        violations.push(`Hardcoded color values found: ${matches.slice(0, 3).join(', ')}`);
      }
    }

    // Check for hardcoded spacing
    const spacingPattern = /\d+px|\d+rem|\d+em/g;
    const spacingMatches = code.match(spacingPattern);
    if (spacingMatches && spacingMatches.length > 5) {
      violations.push('Multiple hardcoded spacing values found. Consider using design tokens.');
    }

    // Check for var() usage
    const varUsage = (code.match(/var\(--/g) || []).length;
    if (varUsage < 3 && code.length > 500) {
      violations.push('Limited CSS variable usage. Ensure design tokens are being used.');
    }

    return {
      valid: violations.length === 0,
      violations,
      suggestions: violations.length > 0 
        ? ['Replace hardcoded values with CSS variables from the design system']
        : []
    };
  }

  private handleGenerateComponent(input: Record<string, unknown>): object {
    // This returns specifications for the LLM to generate the actual code
    return {
      status: 'ready',
      specifications: {
        name: input.name,
        category: input.category,
        description: input.description,
        props: input.props ?? [],
        variants: input.variants ?? [],
        tokenContext: this.context?.activeBrand 
          ? `Use brand "${this.context.activeBrand}" tokens`
          : 'Use semantic tokens'
      }
    };
  }

  private handleSwitchBrandMode(input: Record<string, unknown>): object {
    if (!this.context) return { error: 'Context not initialized' };

    const brandId = input.brandId as string;
    
    if (!this.context.tokens.brand[brandId]) {
      return {
        error: `Brand "${brandId}" not found`,
        available: Object.keys(this.context.tokens.brand)
      };
    }

    this.contextBuilder.withBrand(brandId);
    this.context = this.contextBuilder.build();

    return {
      success: true,
      activeBrand: brandId,
      message: `Switched to brand "${brandId}". Token overrides are now active.`
    };
  }

  private generateCSSVariableMap(group: TokenGroup): Record<string, string> {
    const vars: Record<string, string> = {};
    
    for (const [category, tokens] of Object.entries(group)) {
      for (const tokenName of Object.keys(tokens)) {
        const varName = `--${category}-${tokenName}`.toLowerCase().replace(/[^a-z0-9-]/g, '-');
        vars[tokenName] = `var(${varName})`;
      }
    }
    
    return vars;
  }
}

// ============================================================================
// RESPONSE TYPES
// ============================================================================

export interface AgentResponse {
  content: string;
  toolCalls: ToolCallResult[];
  generatedCode: string | null;
}

export interface ToolCallResult {
  name: string;
  input: Record<string, unknown>;
  result: unknown;
}

// ============================================================================
// FACTORY FUNCTION
// ============================================================================

export function createDesignSystemAgent(
  config?: Partial<DesignAgentConfig>
): DesignSystemAgent {
  const apiKey = config?.apiKey ?? process.env.ANTHROPIC_API_KEY;
  
  if (!apiKey) {
    throw new Error('ANTHROPIC_API_KEY environment variable or apiKey config required');
  }

  return new DesignSystemAgent({ ...config, apiKey });
}
