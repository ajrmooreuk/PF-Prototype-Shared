const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, Header, Footer, 
        AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType, PageNumber, 
        LevelFormat, PageBreak, ExternalHyperlink } = require('docx');
const fs = require('fs');

// Design system brand colors for document
const COLORS = {
  primary: "2563EB",      // Blue 600
  secondary: "7C3AED",    // Violet 600
  accent: "059669",       // Emerald 600
  heading: "1E293B",      // Slate 800
  body: "334155",         // Slate 700
  muted: "64748B",        // Slate 500
  border: "E2E8F0"        // Slate 200
};

const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: COLORS.border };
const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal",
        run: { size: 48, bold: true, color: COLORS.heading, font: "Arial" },
        paragraph: { spacing: { before: 0, after: 200 }, alignment: AlignmentType.LEFT } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: COLORS.primary, font: "Arial" },
        paragraph: { spacing: { before: 400, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: COLORS.heading, font: "Arial" },
        paragraph: { spacing: { before: 300, after: 150 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, color: COLORS.secondary, font: "Arial" },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 2 } },
      { id: "CodeBlock", name: "Code Block", basedOn: "Normal",
        run: { size: 18, font: "Courier New", color: COLORS.body },
        paragraph: { spacing: { before: 100, after: 100 }, indent: { left: 360 } } }
    ]
  },
  numbering: {
    config: [
      { reference: "main-bullets",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } },
          { level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 1080, hanging: 360 } } } }
        ] },
      { reference: "step-list",
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "phase-list",
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "Phase %1:", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }
    ]
  },
  sections: [{
    properties: {
      page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
    },
    headers: {
      default: new Header({ children: [new Paragraph({ 
        alignment: AlignmentType.RIGHT,
        children: [new TextRun({ text: "Figma → Claude Agent SDK Production Pipeline", size: 18, color: COLORS.muted })]
      })] })
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ 
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: "Page ", size: 18, color: COLORS.muted }), 
          new TextRun({ children: [PageNumber.CURRENT], size: 18, color: COLORS.muted }), 
          new TextRun({ text: " | Confidential Architecture Document", size: 18, color: COLORS.muted })
        ]
      })] })
    },
    children: [
      // TITLE PAGE
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("Figma Design System to Claude Agent SDK")] }),
      new Paragraph({ children: [new TextRun({ text: "Production Pipeline Architecture & Implementation Guide", size: 28, color: COLORS.secondary })] }),
      new Paragraph({ spacing: { before: 400 }, children: [new TextRun({ text: "Version 1.0 | December 2025", size: 20, color: COLORS.muted })] }),
      new Paragraph({ children: [new TextRun({ text: "AI-Native Platform Architecture with Design System Fidelity", size: 20, color: COLORS.muted })] }),
      
      // EXECUTIVE SUMMARY
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Executive Summary")] }),
      new Paragraph({ children: [new TextRun("This document provides a comprehensive, step-by-step implementation guide for integrating Figma design systems with Claude Agent SDK, Supabase database layer, and Schema.org-compliant ontologies. The architecture ensures design fidelity is maintained from Figma through to production deployment, with extensible agent orchestration capabilities.")] }),
      
      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Key Deliverables:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Automated design token extraction via Figma REST API (no third-party plugins)")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Token-to-CSS/Tailwind transformation pipeline")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Claude Agent SDK integration with design-aware component generation")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Supabase schema with vector search for semantic design queries")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Schema.org and OAA ontology mappings")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("CI/CD pipeline for dev/stage/prod environments")] }),

      // ARCHITECTURE OVERVIEW
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Architecture Overview")] }),
      new Paragraph({ children: [new TextRun("The pipeline consists of six interconnected layers that maintain design fidelity while enabling AI-driven extensibility.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("System Layers")] }),
      new Table({
        columnWidths: [2340, 3510, 3510],
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Layer", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Components", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Purpose", bold: true, color: "FFFFFF" })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "1. Design Source", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Figma Files, Variables, Components, Styles")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Single source of truth for all design decisions")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "2. Token Pipeline", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Figma API Extractor, Token Transformer, CSS/Tailwind Generator")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Convert design tokens to consumable formats")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "3. Agent Layer", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Claude SDK, Design-Aware Agents, Component Generators")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("AI orchestration with design system context")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "4. Data Layer", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Supabase, pgvector, Edge Functions")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Persistent storage with semantic search")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "5. Ontology Layer", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Schema.org Mappings, OAA Definitions, Type System")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Semantic interoperability and future-proofing")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: "6. Delivery Layer", bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Next.js, React, Shadcn/ui, CI/CD")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3510, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Production deployment with design fidelity")] })] })
          ]})
        ]
      }),

      // PHASE 1: FIGMA SETUP
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 1: Figma Design System Setup")] }),
      new Paragraph({ children: [new TextRun("Establish the foundation by structuring Figma for API-driven token extraction.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("1.1 Figma Variables Structure")] }),
      new Paragraph({ children: [new TextRun("Figma Variables (introduced in 2023) provide the most robust method for design tokens. Structure your variables in collections that map directly to semantic usage.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Required Variable Collections:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "primitives: ", bold: true }), new TextRun("Raw color values, spacing units, font sizes (e.g., blue-500, spacing-4)")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "semantic: ", bold: true }), new TextRun("Purpose-driven aliases (e.g., color-primary, color-background, spacing-component)")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "component: ", bold: true }), new TextRun("Component-specific overrides (e.g., button-padding, card-radius)")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "brand: ", bold: true }), new TextRun("Multi-tenant brand switching variables (modes for each brand)")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("1.2 Variable Modes for Multi-Tenant")] }),
      new Paragraph({ children: [new TextRun("For BAIV-style multi-tenant architecture, create variable modes within the brand collection. Each mode represents a complete brand variant.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Mode Structure:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("default: Base brand (your platform's default styling)")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("client-alpha: First client brand configuration")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("client-beta: Second client brand configuration")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("1.3 Component Structure")] }),
      new Paragraph({ children: [new TextRun("Organize components using the atomic design methodology with consistent naming conventions that enable programmatic access.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Naming Convention:", bold: true, italics: true }), new TextRun({ text: " [category]/[component]/[variant]", italics: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("atoms/button/primary")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("atoms/button/secondary")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("molecules/card/default")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("organisms/header/main")] }),

      // PHASE 2: TOKEN EXTRACTION
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 2: Design Token Extraction Pipeline")] }),
      new Paragraph({ children: [new TextRun("Extract design tokens directly from Figma using the REST API—no third-party plugins required.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.1 Figma API Authentication")] }),
      new Paragraph({ children: [new TextRun("Generate a Personal Access Token from Figma Settings → Account → Personal Access Tokens. Store securely in environment variables.")] }),

      new Paragraph({ spacing: { before: 200 }, style: "CodeBlock", children: [new TextRun("FIGMA_ACCESS_TOKEN=figd_xxxxx")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("FIGMA_FILE_KEY=your-file-key-from-url")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.2 API Endpoints")] }),
      new Paragraph({ children: [new TextRun("The Figma REST API provides several endpoints for token extraction:")] }),

      new Table({
        columnWidths: [3120, 6240],
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, shading: { fill: COLORS.secondary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Endpoint", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 6240, type: WidthType.DXA }, shading: { fill: COLORS.secondary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Data Returned", bold: true, color: "FFFFFF" })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("GET /v1/files/:key/variables/local")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 6240, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("All local variables with collections and modes")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("GET /v1/files/:key/styles")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 6240, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Published styles (colors, typography, effects)")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("GET /v1/files/:key/components")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 6240, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Component metadata and structure")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("GET /v1/files/:key")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 6240, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Full file structure including component properties")] })] })
          ]})
        ]
      }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("2.3 Token Transformation")] }),
      new Paragraph({ children: [new TextRun("Transform Figma's raw API response into the W3C Design Token Community Group format for maximum interoperability.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Output Formats:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "tokens.json: ", bold: true }), new TextRun("W3C DTCG format for tooling compatibility")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "variables.css: ", bold: true }), new TextRun("CSS custom properties for runtime theming")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "tailwind.config.ts: ", bold: true }), new TextRun("Tailwind theme extension")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "schema.json: ", bold: true }), new TextRun("Schema.org-compliant token definitions")] }),

      // PHASE 3: CLAUDE AGENT SDK
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 3: Claude Agent SDK Integration")] }),
      new Paragraph({ children: [new TextRun("Integrate the Claude Agent SDK with design system awareness for component generation and UI orchestration.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("3.1 Agent Architecture")] }),
      new Paragraph({ children: [new TextRun("Create specialized agents that understand the design system context and can generate compliant components.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Core Agents:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "DesignSystemAgent: ", bold: true }), new TextRun("Maintains token context, validates design compliance")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "ComponentGeneratorAgent: ", bold: true }), new TextRun("Generates React components using design tokens")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "LayoutAgent: ", bold: true }), new TextRun("Composes page layouts from component library")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "ValidationAgent: ", bold: true }), new TextRun("Ensures output matches design specifications")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("3.2 Design Context Injection")] }),
      new Paragraph({ children: [new TextRun("Inject design system context into agent prompts to ensure generated code respects design constraints.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Context Components:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Token dictionary with semantic mappings")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Component API specifications from Figma")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Variant rules and conditional logic")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Brand mode configurations")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("3.3 Tool Definitions")] }),
      new Paragraph({ children: [new TextRun("Define Claude tools that agents can invoke for design system operations.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Available Tools:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "get_design_tokens: ", bold: true }), new TextRun("Retrieve tokens by category or semantic purpose")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "get_component_spec: ", bold: true }), new TextRun("Fetch component API and variant definitions")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "validate_component: ", bold: true }), new TextRun("Check generated code against design rules")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "generate_component: ", bold: true }), new TextRun("Create new component with design compliance")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "switch_brand_mode: ", bold: true }), new TextRun("Toggle between multi-tenant brand configurations")] }),

      // PHASE 4: DATABASE LAYER
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 4: Supabase Database Layer")] }),
      new Paragraph({ children: [new TextRun("Implement persistent storage with vector search capabilities for semantic design queries.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("4.1 Schema Design")] }),
      new Paragraph({ children: [new TextRun("Structure the database to support design tokens, component metadata, and multi-tenant brand configurations.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Core Tables:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "design_tokens: ", bold: true }), new TextRun("Token definitions with embeddings for semantic search")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "components: ", bold: true }), new TextRun("Component specifications and Figma references")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "brands: ", bold: true }), new TextRun("Multi-tenant brand configurations")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "brand_tokens: ", bold: true }), new TextRun("Brand-specific token overrides")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "generated_components: ", bold: true }), new TextRun("AI-generated component history with version control")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("4.2 Vector Search with pgvector")] }),
      new Paragraph({ children: [new TextRun("Enable semantic search over design tokens and components using pgvector extension.")] }),

      new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "Use Cases:", bold: true })] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Find similar components by description")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Semantic token search (e.g., 'warm colors for call-to-action')")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun("Design pattern matching across brands")] }),

      // PHASE 5: ONTOLOGY LAYER
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 5: Ontology & Schema.org Integration")] }),
      new Paragraph({ children: [new TextRun("Map design system entities to Schema.org types for maximum interoperability and AI agent discoverability.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("5.1 Schema.org Mappings")] }),
      
      new Table({
        columnWidths: [3120, 3120, 3120],
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, shading: { fill: COLORS.accent, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Design Entity", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, shading: { fill: COLORS.accent, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Schema.org Type", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, shading: { fill: COLORS.accent, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Custom Extension", bold: true, color: "FFFFFF" })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Design Token")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("PropertyValue")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("DesignToken")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Component")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("SoftwareSourceCode")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("UIComponent")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Brand Configuration")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Brand")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("BrandDesignSystem")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Color Token")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("PropertyValue")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("ColorToken")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Typography Token")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("PropertyValue")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("TypographyToken")] })] })
          ]})
        ]
      }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("5.2 OAA Ontology for Agent Interoperability")] }),
      new Paragraph({ children: [new TextRun("Define Open Agent Architecture (OAA) compatible ontologies for cross-platform agent communication.")] }),

      // PHASE 6: PRODUCTION DEPLOYMENT
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Phase 6: Production Deployment Pipeline")] }),
      new Paragraph({ children: [new TextRun("Establish CI/CD workflows that maintain design fidelity from development through production.")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("6.1 Environment Structure")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "Development: ", bold: true }), new TextRun("Local development with hot reload and design token watch")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "Staging: ", bold: true }), new TextRun("Integration testing with full design system validation")] }),
      new Paragraph({ numbering: { reference: "main-bullets", level: 0 }, children: [new TextRun({ text: "Production: ", bold: true }), new TextRun("Optimized builds with cached design tokens")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("6.2 CI/CD Pipeline Steps")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Token Sync: ", bold: true }), new TextRun("Fetch latest tokens from Figma API on commit")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Transform: ", bold: true }), new TextRun("Generate CSS, Tailwind config, and type definitions")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Validate: ", bold: true }), new TextRun("Run design compliance tests against components")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Build: ", bold: true }), new TextRun("Compile Next.js application with design tokens")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Test: ", bold: true }), new TextRun("Visual regression testing against Figma snapshots")] }),
      new Paragraph({ numbering: { reference: "step-list", level: 0 }, children: [new TextRun({ text: "Deploy: ", bold: true }), new TextRun("Push to target environment (Vercel/DigitalOcean)")] }),

      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("6.3 Design Token Versioning")] }),
      new Paragraph({ children: [new TextRun("Implement semantic versioning for design token releases to enable rollback and audit capabilities.")] }),

      // IMPLEMENTATION TIMELINE
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Implementation Timeline")] }),
      new Paragraph({ children: [new TextRun("Recommended 8-week rapid iteration MVP implementation schedule.")] }),

      new Table({
        columnWidths: [1560, 2340, 3120, 2340],
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 1560, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Week", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Phase", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Deliverables", bold: true, color: "FFFFFF" })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, shading: { fill: COLORS.primary, type: ShadingType.CLEAR },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Dependencies", bold: true, color: "FFFFFF" })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 1560, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("1-2")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Figma Setup")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Variables, components, API access")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Figma Pro account")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 1560, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("3-4")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Token Pipeline")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Extraction, transformation, CSS/Tailwind output")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Phase 1 complete")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 1560, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("5-6")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Agent Integration")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Claude SDK setup, design-aware agents")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Phase 2 complete")] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 1560, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("7-8")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Production Deploy")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 3120, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("CI/CD, multi-env deployment, validation")] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2340, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun("Phases 3-4 complete")] })] })
          ]})
        ]
      }),

      // APPENDIX
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Appendix: File Structure")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("figma-agent-pipeline/")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("├── src/")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── lib/                    # Core utilities")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   ├── figma-api.ts        # Figma REST API client")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   ├── token-transformer.ts # Token → CSS/Tailwind")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   └── design-context.ts   # Agent context builder")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── agents/                 # Claude Agent definitions")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   ├── design-system.ts    # Design system agent")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   ├── component-gen.ts    # Component generator")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   │   └── validation.ts       # Design validation agent")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── components/             # Generated React components")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── schemas/                # JSON schemas & ontologies")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   └── types/                  # TypeScript definitions")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("├── database/")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── migrations/             # Supabase migrations")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   └── seeds/                  # Initial data")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("├── config/")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   ├── tokens/                 # Generated token files")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("│   └── tailwind.config.ts      # Extended Tailwind config")] }),
      new Paragraph({ style: "CodeBlock", children: [new TextRun("└── deploy/                     # CI/CD configurations")] })
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/figma-agent-pipeline/docs/figma-agent-architecture.docx", buffer);
  console.log("Architecture document generated successfully");
});
