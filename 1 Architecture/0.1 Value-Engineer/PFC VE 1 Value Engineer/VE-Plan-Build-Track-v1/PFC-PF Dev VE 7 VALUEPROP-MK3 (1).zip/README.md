
  # PFC-PF Dev VE 7 VALUEPROP-MK3

  This is a code bundle for PFC-PF Dev VE 7 VALUEPROP-MK3. The original project is available at https://www.figma.com/design/eRrSyOAYZaE1P30YW0rRwj/PFC-PF-Dev-VE-7-VALUEPROP-MK3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  