import { useState } from "react";
import { Button } from "./ui/button";
import { LogIn, LogOut } from "lucide-react";

interface HomePageProps {
  onNavigate: (view: "admin" | "agency" | "direct" | "affiliate") => void;
  onSignIn: () => void;
  onSignOut: () => void;
  isSignedIn: boolean;
}

export function HomePage({ onNavigate, onSignIn, onSignOut, isSignedIn }: HomePageProps) {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-200">
        <nav className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-8">
              <h1 className="text-xl font-semibold text-neutral-950">baiv 2</h1>
              
              {/* Main Navigation */}
              <div className="hidden md:flex items-center gap-6">
                <button
                  onClick={() => onNavigate("admin")}
                  className="text-sm text-neutral-600 hover:text-neutral-950 transition-colors"
                >
                  Admin
                </button>
                <button
                  onClick={() => onNavigate("agency")}
                  className="text-sm text-neutral-600 hover:text-neutral-950 transition-colors"
                >
                  Agency
                </button>
                <button
                  onClick={() => onNavigate("direct")}
                  className="text-sm text-neutral-600 hover:text-neutral-950 transition-colors"
                >
                  Direct Client
                </button>
                <button
                  onClick={() => onNavigate("affiliate")}
                  className="text-sm text-neutral-600 hover:text-neutral-950 transition-colors"
                >
                  Affiliate
                </button>
              </div>
            </div>

            {/* Auth Buttons */}
            <div className="flex items-center gap-3">
              {isSignedIn ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onSignOut}
                  className="gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </Button>
              ) : (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onSignIn}
                  >
                    Sign In
                  </Button>
                  <Button
                    size="sm"
                    onClick={onSignIn}
                    className="bg-[#030213] hover:bg-[#030213]/90"
                  >
                    Start Free
                  </Button>
                </>
              )}
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-normal mb-6 text-neutral-950 tracking-tight">
            Build faster with our platform
          </h2>
          <p className="text-xl text-[#717182] mb-8 max-w-3xl mx-auto leading-relaxed">
            A functional, lean SaaS platform designed for teams that ship. No bloat, just the tools you need to build and scale.
          </p>
          <div className="flex items-center justify-center gap-3">
            <Button
              size="lg"
              className="bg-[#030213] hover:bg-[#030213]/90 px-6"
              onClick={onSignIn}
            >
              Get Started Free
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-6"
            >
              View Documentation
            </Button>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 px-6 bg-gray-50/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-medium mb-4 text-neutral-950">
              Simple, transparent pricing
            </h3>
            <p className="text-[#717182]">
              Choose the plan that fits your needs. All plans include a 14-day free trial.
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            {/* Starter Plan */}
            <div className="bg-white rounded-lg border border-gray-200 p-8">
              <div className="mb-6">
                <h4 className="text-lg font-medium mb-2 text-neutral-950">Starter</h4>
                <p className="text-sm text-[#717182] mb-4">Perfect for trying out the platform</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-semibold">$0</span>
                  <span className="text-sm text-[#717182]">/month</span>
                </div>
              </div>
              <Button variant="outline" className="w-full mb-6">
                Get Started
              </Button>
              <ul className="space-y-3">
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Up to 3 projects
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Basic analytics
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Community support
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  1 GB storage
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  API access
                </li>
              </ul>
            </div>

            {/* Professional Plan */}
            <div className="bg-white rounded-lg border-2 border-neutral-950 p-8 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-neutral-950 text-white text-xs font-medium px-3 py-1 rounded-full">
                  Popular
                </span>
              </div>
              <div className="mb-6">
                <h4 className="text-lg font-medium mb-2 text-neutral-950">Professional</h4>
                <p className="text-sm text-[#717182] mb-4">For professionals and growing teams</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-semibold">$29</span>
                  <span className="text-sm text-[#717182]">/month</span>
                </div>
              </div>
              <Button className="w-full mb-6 bg-[#030213] hover:bg-[#030213]/90">
                Start Free Trial
              </Button>
              <ul className="space-y-3">
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Unlimited projects
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Advanced analytics
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Priority support
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  50 GB storage
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  API access
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Custom integrations
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Team collaboration
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Advanced security
                </li>
              </ul>
            </div>

            {/* Enterprise Plan */}
            <div className="bg-white rounded-lg border border-gray-200 p-8">
              <div className="mb-6">
                <h4 className="text-lg font-medium mb-2 text-neutral-950">Enterprise</h4>
                <p className="text-sm text-[#717182] mb-4">For large organizations</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-semibold">$99</span>
                  <span className="text-sm text-[#717182]">/month</span>
                </div>
              </div>
              <Button variant="outline" className="w-full mb-6">
                Contact Sales
              </Button>
              <ul className="space-y-3">
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Everything in Professional
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Dedicated support
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Unlimited storage
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  SSO & SAML
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Custom SLA
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Advanced permissions
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  Audit logs
                </li>
                <li className="flex items-start gap-3 text-sm text-[#717182]">
                  <svg className="w-5 h-5 flex-shrink-0 text-neutral-950" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.67" d="M16.667 5L7.5 14.167 3.333 10" />
                  </svg>
                  White-label options
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h5 className="font-medium mb-4 text-neutral-950">Product</h5>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Features</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Pricing</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Updates</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-4 text-neutral-950">Company</h5>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">About</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Blog</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Careers</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-4 text-neutral-950">Resources</h5>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Documentation</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Support</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Status</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-4 text-neutral-950">Legal</h5>
              <ul className="space-y-2">
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Privacy</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Terms</a></li>
                <li><a href="#" className="text-sm text-[#717182] hover:text-neutral-950">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="text-center text-sm text-[#717182] pt-8 border-t border-gray-200">
            © 2025 baiv 2. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
