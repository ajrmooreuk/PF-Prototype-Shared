import { useState } from "react";
import { HomePage } from "./components/HomePage";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { Label } from "./components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./components/ui/select";
import { Badge } from "./components/ui/badge";
import { ScrollArea } from "./components/ui/scroll-area";
import { Progress } from "./components/ui/progress";
import { Separator } from "./components/ui/separator";
import { Checkbox } from "./components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./components/ui/tooltip";
import {
  Sparkles,
  Target,
  Users,
  Package,
  Zap,
  TrendingUp,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  Save,
  Brain,
  X,
  Plus,
  Trash2,
  Edit,
  Building2,
  Lightbulb,
  Shield,
  Award,
  ArrowLeft,
  HelpCircle,
  Info,
  Home,
  MapPin,
  Briefcase,
  DollarSign,
  GraduationCap,
  Star,
  LogOut,
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { Baiv2App } from "./modules/baiv2";
import { PricingCard } from "./modules/baiv2/PricingCard";
import { AppBreadcrumb } from "./components/AppBreadcrumb";

// Mock data
const mockInstances = [
  {
    id: "baiv",
    name: "BAIV",
    description: "Business AI Visibility Platform",
  },
  {
    id: "w4m",
    name: "W4M",
    description: "Workflow Management",
  },
];

const mockOrganizations = [
  {
    id: "org-baiv",
    name: "BAIV",
    instanceId: "baiv",
    industry: "AI & Platform Services",
  },
  {
    id: "org-acme",
    name: "Acme Corp",
    instanceId: "baiv",
    industry: "SaaS",
  },
  {
    id: "org-globex",
    name: "Globex Corporation",
    instanceId: "baiv",
    industry: "Manufacturing",
  },
  {
    id: "org-initech",
    name: "Initech",
    instanceId: "w4m",
    industry: "Consulting",
  },
];

const mockStrategies = [
  {
    id: "strat-0",
    name: "AI Platform Growth Strategy",
    orgId: "org-baiv",
  },
  {
    id: "strat-1",
    name: "Market Expansion 2025",
    orgId: "org-acme",
  },
  {
    id: "strat-2",
    name: "Digital Transformation",
    orgId: "org-globex",
  },
];

const mockBrands = [
  { id: "brand-0", name: "BAIV Platform", instanceId: "baiv" },
  { id: "brand-1", name: "Acme Pro", instanceId: "baiv" },
  { id: "brand-2", name: "Globex Plus", instanceId: "baiv" },
];

const mockProducts = [
  {
    id: "prod-0",
    name: "Value Engineering Suite",
    brandId: "brand-0",
  },
  {
    id: "prod-0b",
    name: "AI Assistant Module",
    brandId: "brand-0",
  },
  {
    id: "prod-1",
    name: "Analytics Platform",
    brandId: "brand-1",
  },
  { id: "prod-2", name: "Workflow Suite", brandId: "brand-1" },
  {
    id: "prod-3",
    name: "Manufacturing OS",
    brandId: "brand-2",
  },
];

const mockPricingTiers = [
  {
    id: "starter",
    name: "Starter",
    price: 29,
    description: "Perfect for small teams",
    features: [
      "Up to 10 users",
      "Basic analytics",
      "Email support",
      "1GB storage",
    ],
  },
  {
    id: "professional",
    name: "Professional",
    price: 99,
    description: "For growing businesses",
    features: [
      "Up to 50 users",
      "Advanced analytics",
      "Priority support",
      "10GB storage",
      "Custom integrations",
      "API access",
    ],
    recommended: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 299,
    description: "For large organizations",
    features: [
      "Unlimited users",
      "Enterprise analytics",
      "24/7 dedicated support",
      "Unlimited storage",
      "Custom integrations",
      "API access",
      "SLA guarantee",
      "White-label options",
    ],
  },
];

const contextOptions = {
  marketSectors: [
    {
      name: "B2B SaaS",
      subCategories: [
        "CRM & Sales",
        "Marketing Automation",
        "HR & Talent",
        "Finance & Accounting",
        "DevOps & Engineering",
        "Collaboration & Productivity",
        "Analytics & BI",
        "Customer Support",
      ],
    },
    {
      name: "E-commerce",
      subCategories: [
        "B2C Retail",
        "B2B Commerce",
        "Marketplace Platforms",
        "Subscription Commerce",
        "Digital Goods",
        "Dropshipping",
        "Omnichannel Retail",
      ],
    },
    {
      name: "Healthcare",
      subCategories: [
        "Telemedicine",
        "Health Records & EMR",
        "Medical Devices",
        "Pharma & Biotech",
        "Health Insurance",
        "Clinical Trials",
        "Patient Engagement",
        "Healthcare Analytics",
      ],
    },
    {
      name: "FinTech",
      subCategories: [
        "Payments & Processing",
        "Lending & Credit",
        "Wealth Management",
        "Banking & Neobanks",
        "Insurance Tech",
        "RegTech & Compliance",
        "Cryptocurrency & Blockchain",
        "Financial Planning",
      ],
    },
    {
      name: "Manufacturing",
      subCategories: [
        "Industrial IoT",
        "Supply Chain Management",
        "Quality Control",
        "Predictive Maintenance",
        "Process Automation",
        "Inventory Management",
        "Production Planning",
      ],
    },
    {
      name: "Professional Services",
      subCategories: [
        "Legal Tech",
        "Accounting & Tax",
        "Consulting",
        "Recruiting & Staffing",
        "Marketing Agencies",
        "Real Estate",
        "Architecture & Engineering",
      ],
    },
    {
      name: "Education",
      subCategories: [
        "K-12 Education",
        "Higher Education",
        "Online Learning Platforms",
        "Corporate Training",
        "Educational Content",
        "Student Management",
        "EdTech Tools",
      ],
    },
    {
      name: "Government",
      subCategories: [
        "Federal Government",
        "State & Local",
        "Public Safety",
        "Citizen Services",
        "Infrastructure Management",
        "Policy & Regulation",
        "Defense & Security",
      ],
    },
  ],
  orgMaturity: [
    "Startup (0-2 years)",
    "Growth (3-5 years)",
    "Established (6-10 years)",
    "Enterprise (10+ years)",
  ],
  innovation: [
    "Early Adopter",
    "Innovation Leader",
    "Fast Follower",
    "Pragmatic Adopter",
  ],
  aiReadiness: [
    "Exploring AI",
    "Piloting AI",
    "Scaling AI",
    "AI-Native",
  ],
};

export default function App() {
  const [showHomePage, setShowHomePage] = useState(true);
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedInstanceId, setSelectedInstanceId] =
    useState("");
  const [selectedOrgId, setSelectedOrgId] = useState("");
  const [organizations, setOrganizations] = useState(
    mockOrganizations,
  );
  const [strategies, setStrategies] = useState(mockStrategies);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [activeModule, setActiveModule] = useState<"value-prop" | "baiv2">("baiv2");
  const [activeTab, setActiveTab] = useState<"admin" | "agency" | "direct" | "affiliate">("admin");
  const [defaultTabView, setDefaultTabView] = useState("dashboard");
  const [selectedPricingTier, setSelectedPricingTier] = useState<string | null>(null);

  const [orgContext, setOrgContext] = useState({
    marketSectors: [] as string[],
    marketSectorDetails: [] as Array<{sector: string, subCategories: string[], customSubCategories: string[]}>,
    orgMaturity: [] as string[],
    innovation: [] as string[],
    aiReadiness: [] as string[],
  });

  const [expandedSectors, setExpandedSectors] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    name: "",
    strategyId: undefined as string | undefined,
    customerSegments: [] as any[],
    productsServices: [] as any[],
    painRelievers: [] as any[],
    gainCreators: [] as any[],
    valueMetrics: [] as any[],
  });

  const [newSegment, setNewSegment] = useState({
    name: "",
    description: "",
    // ICP Firmographics
    companySize: "",
    industry: "",
    revenue: "",
    geography: "",
    // ICP Demographics
    jobTitles: [""],
    departments: [""],
    seniority: "",
    // ICP Psychographics & Behavioral
    customerJobs: [""],
    pains: [""],
    gains: [""],
    goals: [""],
    challenges: [""],
    buyingProcess: "",
    decisionCriteria: [""],
    // Priority & Value
    priority: "medium",
    estimatedValue: "",
    // Sub-segments
    subSegments: [] as any[],
  });

  const [icpSection, setIcpSection] = useState("overview"); // overview, firmographics, demographics, psychographics, subsegments

  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
  });

  const [newPainReliever, setNewPainReliever] = useState({
    segmentId: "",
    painAddressed: "",
    solution: "",
    impact: "medium",
  });

  const [newGainCreator, setNewGainCreator] = useState({
    segmentId: "",
    gainDelivered: "",
    mechanism: "",
  });

  const [newValueMetric, setNewValueMetric] = useState({
    name: "",
    description: "",
    target: "",
    current: "",
  });

  const wizardSteps = [
    {
      number: 1,
      title: "Context & Scope",
      icon: Building2,
      description: "Define organizational context",
      tooltip: "Set up context for value proposition",
    },
    {
      number: 2,
      title: "Ideal Customer Profiles",
      icon: Users,
      description: "Define ICPs & Sub-Segments",
      tooltip: "Identify who you create value for with detailed profiles",
    },
    {
      number: 3,
      title: "Products & Services",
      icon: Package,
      description: "Map your offerings",
      tooltip: "Define what you offer",
    },
    {
      number: 4,
      title: "Pain Relievers",
      icon: Shield,
      description: "How you alleviate pains",
      tooltip: "Connect offerings to pain points",
    },
    {
      number: 5,
      title: "Gain Creators",
      icon: TrendingUp,
      description: "How you create gains",
      tooltip: "Define how you deliver outcomes",
    },
    {
      number: 6,
      title: "Value Metrics",
      icon: Target,
      description: "Measure value delivered",
      tooltip: "Define success metrics",
    },
    {
      number: 7,
      title: "Pricing Strategy",
      icon: DollarSign,
      description: "Define pricing model",
      tooltip: "Choose pricing tier and strategy",
    },
    {
      number: 8,
      title: "Review & Finalize",
      icon: CheckCircle2,
      description: "Review and save",
      tooltip: "Final review before saving",
    },
  ];

  const handleNext = () => {
    if (
      currentStep === 1 &&
      (!selectedInstanceId || !selectedOrgId)
    ) {
      toast.error("Please select instance and organization");
      return;
    }
    if (currentStep < 8) setCurrentStep((prev) => prev + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    } else {
      // If on step 1, go back to Value Engineer tab in BAIV2
      setActiveModule("baiv2");
      setActiveTab("admin");
      setDefaultTabView("value-engineer");
      toast.success("Returned to Value Engineer");
    }
  };

  const handleSave = () => {
    if (!formData.name || !selectedOrgId) {
      toast.error("Please complete all required fields");
      return;
    }

    const vpData = {
      id: `valueprop_${Date.now()}`,
      instanceId: selectedInstanceId,
      orgId: selectedOrgId,
      ...formData,
      orgContext,
      createdAt: new Date().toISOString(),
    };

    console.log("📊 Value Proposition Saved:", vpData);
    toast.success("Value proposition saved successfully!");

    setTimeout(() => {
      setCurrentStep(1);
      window.location.reload();
    }, 1500);
  };

  const addCustomerSegment = () => {
    if (!newSegment.name) {
      toast.error("Please enter ICP name");
      return;
    }

    const segment = {
      id: `seg_${Date.now()}`,
      ...newSegment,
      customerJobs: newSegment.customerJobs.filter((j) => j.trim()),
      pains: newSegment.pains?.filter((p) => p.trim()) || [],
      gains: newSegment.gains?.filter((g) => g.trim()) || [],
      goals: newSegment.goals.filter((g) => g.trim()),
      challenges: newSegment.challenges.filter((c) => c.trim()),
      decisionCriteria: newSegment.decisionCriteria.filter((d) => d.trim()),
      jobTitles: newSegment.jobTitles.filter((t) => t.trim()),
      departments: newSegment.departments.filter((d) => d.trim()),
    };

    setFormData((prev) => ({
      ...prev,
      customerSegments: [...prev.customerSegments, segment],
    }));

    setNewSegment({
      name: "",
      description: "",
      companySize: "",
      industry: "",
      revenue: "",
      geography: "",
      jobTitles: [""],
      departments: [""],
      seniority: "",
      customerJobs: [""],
      pains: [""],
      gains: [""],
      goals: [""],
      challenges: [""],
      buyingProcess: "",
      decisionCriteria: [""],
      priority: "medium",
      estimatedValue: "",
      subSegments: [],
    });

    setIcpSection("overview");
    toast.success("Ideal Customer Profile added");
  };

  const addProductService = () => {
    if (!newProduct.name) {
      toast.error("Please enter product/service name");
      return;
    }

    const product = {
      id: `prod_${Date.now()}`,
      ...newProduct,
    };

    setFormData((prev) => ({
      ...prev,
      productsServices: [...prev.productsServices, product],
    }));

    setNewProduct({ name: "", description: "" });
    toast.success("Product/service added");
  };

  const addPainReliever = () => {
    if (
      !newPainReliever.segmentId ||
      !newPainReliever.painAddressed
    ) {
      toast.error("Please select segment and pain addressed");
      return;
    }

    const reliever = {
      id: `pr_${Date.now()}`,
      ...newPainReliever,
    };

    setFormData((prev) => ({
      ...prev,
      painRelievers: [...prev.painRelievers, reliever],
    }));

    setNewPainReliever({
      segmentId: "",
      painAddressed: "",
      solution: "",
      impact: "medium",
    });

    toast.success("Pain reliever added");
  };

  const addGainCreator = () => {
    if (
      !newGainCreator.segmentId ||
      !newGainCreator.gainDelivered
    ) {
      toast.error("Please select segment and gain delivered");
      return;
    }

    const creator = {
      id: `gc_${Date.now()}`,
      ...newGainCreator,
    };

    setFormData((prev) => ({
      ...prev,
      gainCreators: [...prev.gainCreators, creator],
    }));

    setNewGainCreator({
      segmentId: "",
      gainDelivered: "",
      mechanism: "",
    });

    toast.success("Gain creator added");
  };

  const addValueMetric = () => {
    if (!newValueMetric.name) {
      toast.error("Please enter metric name");
      return;
    }

    const metric = {
      id: `vm_${Date.now()}`,
      ...newValueMetric,
    };

    setFormData((prev) => ({
      ...prev,
      valueMetrics: [...prev.valueMetrics, metric],
    }));

    setNewValueMetric({
      name: "",
      description: "",
      target: "",
      current: "",
    });

    toast.success("Value metric added");
  };

  // Show home page if not signed in
  if (showHomePage) {
    return (
      <HomePage
        onNavigate={(view) => {
          setShowHomePage(false);
          setIsSignedIn(true);
          setActiveModule("baiv2");
          setActiveTab(view);
          toast.success(`Welcome to ${view.charAt(0).toUpperCase() + view.slice(1)} Portal`);
        }}
        onSignIn={() => {
          setShowHomePage(false);
          setIsSignedIn(true);
          toast.success("Signed in successfully");
        }}
        onSignOut={() => {
          setShowHomePage(true);
          setIsSignedIn(false);
          toast.success("Signed out successfully");
        }}
        isSignedIn={isSignedIn}
      />
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Page Header */}
      <div className="border-b bg-card/30 backdrop-blur-sm">
        <div className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowHomePage(true);
                    toast.success("Returned to Home");
                  }}
                  className="shrink-0"
                  title="Go to Home Page"
                >
                  <Home className="w-5 h-5" />
                </Button>
                <Separator orientation="vertical" className="h-8" />
                <div className="flex-1 min-w-0">
                  <h1 className="text-2xl font-semibold">
                    Be AI Visible
                  </h1>
                  <p className="text-sm text-muted-foreground mt-1">
                    {activeModule === "value-prop" 
                      ? "Define customer-focused value propositions using the Value Proposition Canvas"
                      : "AI-powered platform for value engineering and solution architecture"
                    }
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant={activeModule === "baiv2" && activeTab === "admin" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  setActiveModule("baiv2");
                  setActiveTab("admin");
                }}
              >
                Admin
              </Button>
              <Button
                variant={activeModule === "baiv2" && activeTab === "agency" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  setActiveModule("baiv2");
                  setActiveTab("agency");
                }}
              >
                Agency Client
              </Button>
              <Button
                variant={activeModule === "baiv2" && activeTab === "direct" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  setActiveModule("baiv2");
                  setActiveTab("direct");
                }}
              >
                Direct Client
              </Button>
              <Button
                variant={activeModule === "baiv2" && activeTab === "affiliate" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  setActiveModule("baiv2");
                  setActiveTab("affiliate");
                }}
              >
                Affiliate
              </Button>
              <Separator orientation="vertical" className="h-6" />
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setShowAIAssistant(!showAIAssistant)
                      }
                    >
                      <Brain className="w-4 h-4 mr-2" />
                      AI Help
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Get AI-powered suggestions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <Separator orientation="vertical" className="h-6" />
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setShowHomePage(true);
                  setIsSignedIn(false);
                  toast.success("Signed out successfully");
                }}
                className="gap-2"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Assistant */}
      {showAIAssistant && (
        <div className="border-b bg-blue-50 dark:bg-blue-950/20">
          <div className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                  AI Context Assistant
                </h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAIAssistant(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Demo mode - In production, this provides
              contextual AI assistance based on your inputs.
            </p>
          </div>
        </div>
      )}

      <ScrollArea className="flex-1">
        <div className="p-6 max-w-7xl mx-auto">
          {activeModule === "baiv2" ? (
            <Baiv2App 
              activeTab={activeTab} 
              defaultTabView={defaultTabView}
              onLaunchValueProp={() => setActiveModule("value-prop")}
            />
          ) : (
            <>
          {/* Breadcrumb Navigation */}
          <AppBreadcrumb
            className="mb-4"
            items={[
              {
                label: "Home",
                onClick: () => {
                  setActiveModule("baiv2");
                  setActiveTab("admin");
                  setDefaultTabView("dashboard");
                  toast.success("Returned to Home");
                },
              },
              {
                label: "Admin",
                onClick: () => {
                  setActiveModule("baiv2");
                  setActiveTab("admin");
                  setDefaultTabView("dashboard");
                },
              },
              {
                label: "Value Engineer",
                onClick: () => {
                  setActiveModule("baiv2");
                  setActiveTab("admin");
                  setDefaultTabView("value-engineer");
                  toast.info("Returning to Value Engineer");
                },
              },
              {
                label: "Value Proposition Wizard",
                onClick: () => {
                  if (currentStep > 1) {
                    setCurrentStep(1);
                    toast.info("Returned to start of wizard");
                  }
                },
              },
              {
                label: wizardSteps[currentStep - 1].title,
                isCurrentPage: true,
              },
            ]}
          />

          {/* Progress */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">
                  Step {currentStep} of 7:{" "}
                  {wizardSteps[currentStep - 1].title}
                </span>
                <span className="text-sm text-muted-foreground">
                  {Math.round((currentStep / 7) * 100)}%
                  Complete
                </span>
              </div>
              <Progress
                value={(currentStep / 7) * 100}
                className="h-2"
              />

              {/* Step Indicators */}
              <div className="flex items-center justify-between mt-4">
                {wizardSteps.map((step) => (
                  <TooltipProvider key={step.number}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex flex-col items-center gap-1">
                          <div
                            className={`
                              w-10 h-10 rounded-full flex items-center justify-center
                              ${
                                currentStep === step.number
                                  ? "bg-[#00a4bf] text-white"
                                  : currentStep > step.number
                                    ? "bg-green-500 text-white"
                                    : "bg-muted text-muted-foreground"
                              }
                            `}
                          >
                            {currentStep > step.number ? (
                              <CheckCircle2 className="w-5 h-5" />
                            ) : (
                              <step.icon className="w-5 h-5" />
                            )}
                          </div>
                          <span className="text-xs text-center hidden md:block">
                            {step.title.split(" ")[0]}
                          </span>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="font-semibold">
                          {step.title}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {step.description}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Step Content */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {(() => {
                  const StepIcon =
                    wizardSteps[currentStep - 1].icon;
                  return <StepIcon className="w-5 h-5" />;
                })()}
                {wizardSteps[currentStep - 1].title}
              </CardTitle>
              <CardDescription>
                {wizardSteps[currentStep - 1].description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Step 1: Context & Scope */}
              {currentStep === 1 && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="instance">Instance *</Label>
                    <Select
                      value={selectedInstanceId}
                      onValueChange={(value) => {
                        setSelectedInstanceId(value);
                        setSelectedOrgId("");
                        const filtered =
                          mockOrganizations.filter(
                            (org) => org.instanceId === value,
                          );
                        setOrganizations(filtered);
                      }}
                    >
                      <SelectTrigger id="instance">
                        <SelectValue placeholder="Select instance" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockInstances.map((inst) => (
                          <SelectItem
                            key={inst.id}
                            value={inst.id}
                          >
                            {inst.name} - {inst.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedInstanceId && (
                    <div className="space-y-2">
                      <Label htmlFor="organization">
                        Organization *
                      </Label>
                      <Select
                        value={selectedOrgId}
                        onValueChange={(value) => {
                          setSelectedOrgId(value);
                          const filtered =
                            mockStrategies.filter(
                              (s) => s.orgId === value,
                            );
                          setStrategies(filtered);
                        }}
                      >
                        <SelectTrigger id="organization">
                          <SelectValue placeholder="Select organization" />
                        </SelectTrigger>
                        <SelectContent>
                          {organizations.map((org) => (
                            <SelectItem
                              key={org.id}
                              value={org.id}
                            >
                              {org.name} ({org.industry})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {selectedOrgId && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <Label className="flex items-center gap-2">
                          Market Sectors & Sub-Categories
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <HelpCircle className="w-4 h-4 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>
                                  Select market sectors and their specific sub-categories
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </Label>
                        <div className="space-y-2 rounded-lg border p-4 max-h-96 overflow-y-auto">
                          {contextOptions.marketSectors.map(
                            (sectorObj) => {
                              const isSectorSelected = orgContext.marketSectors.includes(sectorObj.name);
                              const isExpanded = expandedSectors.includes(sectorObj.name);
                              const sectorDetails = orgContext.marketSectorDetails.find(d => d.sector === sectorObj.name);
                              const selectedSubCategories = sectorDetails?.subCategories || [];
                              const customSubCategories = sectorDetails?.customSubCategories || [];
                              
                              return (
                                <div key={sectorObj.name} className="space-y-2">
                                  <div className="flex items-center space-x-2">
                                    <Checkbox
                                      id={sectorObj.name}
                                      checked={isSectorSelected}
                                      onCheckedChange={(checked) => {
                                        if (checked) {
                                          setOrgContext((prev) => ({
                                            ...prev,
                                            marketSectors: [...prev.marketSectors, sectorObj.name],
                                            marketSectorDetails: [
                                              ...prev.marketSectorDetails,
                                              { sector: sectorObj.name, subCategories: [], customSubCategories: [] }
                                            ],
                                          }));
                                          setExpandedSectors((prev) => [...prev, sectorObj.name]);
                                        } else {
                                          setOrgContext((prev) => ({
                                            ...prev,
                                            marketSectors: prev.marketSectors.filter((s) => s !== sectorObj.name),
                                            marketSectorDetails: prev.marketSectorDetails.filter((d) => d.sector !== sectorObj.name),
                                          }));
                                          setExpandedSectors((prev) => prev.filter((s) => s !== sectorObj.name));
                                        }
                                      }}
                                    />
                                    <Label
                                      htmlFor={sectorObj.name}
                                      className="text-sm font-semibold cursor-pointer flex-1"
                                    >
                                      {sectorObj.name}
                                    </Label>
                                    {isSectorSelected && (
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 w-6 p-0"
                                        onClick={() => {
                                          setExpandedSectors((prev) =>
                                            isExpanded
                                              ? prev.filter((s) => s !== sectorObj.name)
                                              : [...prev, sectorObj.name]
                                          );
                                        }}
                                      >
                                        <ChevronDown
                                          className={`w-4 h-4 transition-transform ${
                                            isExpanded ? "rotate-180" : ""
                                          }`}
                                        />
                                      </Button>
                                    )}
                                  </div>
                                  
                                  {isSectorSelected && isExpanded && (
                                    <div className="ml-6 pl-4 border-l-2 border-muted space-y-2">
                                      <p className="text-xs text-muted-foreground mb-2">
                                        Select applicable sub-categories:
                                      </p>
                                      {sectorObj.subCategories.map((subCat) => (
                                        <div key={subCat} className="flex items-center space-x-2">
                                          <Checkbox
                                            id={`${sectorObj.name}-${subCat}`}
                                            checked={selectedSubCategories.includes(subCat)}
                                            onCheckedChange={(checked) => {
                                              setOrgContext((prev) => ({
                                                ...prev,
                                                marketSectorDetails: prev.marketSectorDetails.map((d) =>
                                                  d.sector === sectorObj.name
                                                    ? {
                                                        ...d,
                                                        subCategories: checked
                                                          ? [...d.subCategories, subCat]
                                                          : d.subCategories.filter((s) => s !== subCat),
                                                      }
                                                    : d
                                                ),
                                              }));
                                            }}
                                          />
                                          <Label
                                            htmlFor={`${sectorObj.name}-${subCat}`}
                                            className="text-xs font-normal cursor-pointer"
                                          >
                                            {subCat}
                                          </Label>
                                        </div>
                                      ))}
                                      
                                      {/* Custom Sub-Categories */}
                                      <div className="mt-3 pt-3 border-t space-y-2">
                                        <p className="text-xs text-muted-foreground">
                                          Add custom sub-category:
                                        </p>
                                        {customSubCategories.map((customSub, idx) => (
                                          <div key={idx} className="flex items-center space-x-2">
                                            <Checkbox
                                              checked={true}
                                              disabled
                                            />
                                            <span className="text-xs flex-1">{customSub}</span>
                                            <Button
                                              type="button"
                                              variant="ghost"
                                              size="sm"
                                              className="h-6 w-6 p-0"
                                              onClick={() => {
                                                setOrgContext((prev) => ({
                                                  ...prev,
                                                  marketSectorDetails: prev.marketSectorDetails.map((d) =>
                                                    d.sector === sectorObj.name
                                                      ? {
                                                          ...d,
                                                          customSubCategories: d.customSubCategories.filter((_, i) => i !== idx),
                                                        }
                                                      : d
                                                  ),
                                                }));
                                              }}
                                            >
                                              <X className="w-3 h-3" />
                                            </Button>
                                          </div>
                                        ))}
                                        <div className="flex gap-2">
                                          <Input
                                            placeholder="Enter custom sub-category"
                                            className="h-8 text-xs"
                                            onKeyDown={(e) => {
                                              if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                                                const newSubCat = e.currentTarget.value.trim();
                                                setOrgContext((prev) => ({
                                                  ...prev,
                                                  marketSectorDetails: prev.marketSectorDetails.map((d) =>
                                                    d.sector === sectorObj.name
                                                      ? {
                                                          ...d,
                                                          customSubCategories: [...d.customSubCategories, newSubCat],
                                                        }
                                                      : d
                                                  ),
                                                }));
                                                e.currentTarget.value = '';
                                                toast.success('Custom sub-category added');
                                              }
                                            }}
                                          />
                                          <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            className="h-8 px-2"
                                            onClick={(e) => {
                                              const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                                              if (input && input.value.trim()) {
                                                const newSubCat = input.value.trim();
                                                setOrgContext((prev) => ({
                                                  ...prev,
                                                  marketSectorDetails: prev.marketSectorDetails.map((d) =>
                                                    d.sector === sectorObj.name
                                                      ? {
                                                          ...d,
                                                          customSubCategories: [...d.customSubCategories, newSubCat],
                                                        }
                                                      : d
                                                  ),
                                                }));
                                                input.value = '';
                                                toast.success('Custom sub-category added');
                                              }
                                            }}
                                          >
                                            <Plus className="w-3 h-3" />
                                          </Button>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            }
                          )}
                        </div>
                        
                        {/* Selected Sectors Summary */}
                        {orgContext.marketSectors.length > 0 && (
                          <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                            <p className="text-xs font-medium text-blue-900 dark:text-blue-100 mb-2">
                              Selected: {orgContext.marketSectors.length} sector(s)
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {orgContext.marketSectorDetails.map((detail) => {
                                const totalSubs = detail.subCategories.length + detail.customSubCategories.length;
                                return (
                                  <Badge 
                                    key={detail.sector} 
                                    variant="secondary"
                                    className="text-xs"
                                  >
                                    {detail.sector} {totalSubs > 0 && `(${totalSubs})`}
                                  </Badge>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-3">
                        <Label className="flex items-center gap-2">
                          AI Readiness
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <HelpCircle className="w-4 h-4 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>
                                  Organization's AI adoption
                                  stage
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </Label>
                        <div className="space-y-2 rounded-lg border p-4">
                          {contextOptions.aiReadiness.map(
                            (level) => (
                              <div
                                key={level}
                                className="flex items-center space-x-2"
                              >
                                <Checkbox
                                  id={level}
                                  checked={orgContext.aiReadiness.includes(
                                    level,
                                  )}
                                  onCheckedChange={(
                                    checked,
                                  ) => {
                                    if (checked) {
                                      setOrgContext((prev) => ({
                                        ...prev,
                                        aiReadiness: [
                                          ...prev.aiReadiness,
                                          level,
                                        ],
                                      }));
                                    } else {
                                      setOrgContext((prev) => ({
                                        ...prev,
                                        aiReadiness:
                                          prev.aiReadiness.filter(
                                            (l) => l !== level,
                                          ),
                                      }));
                                    }
                                  }}
                                />
                                <Label
                                  htmlFor={level}
                                  className="text-sm font-normal cursor-pointer"
                                >
                                  {level}
                                </Label>
                              </div>
                            ),
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Step 2: Ideal Customer Profiles */}
              {currentStep === 2 && (
                <>
                  <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                          Define 2-4 Ideal Customer Profiles (ICPs) with firmographics, demographics, psychographics, and sub-segments for precise targeting
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-4 border rounded-lg p-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Add Ideal Customer Profile
                    </h4>

                    <Tabs value={icpSection} onValueChange={setIcpSection}>
                      <TabsList className="grid w-full grid-cols-5">
                        <TabsTrigger value="overview">Overview</TabsTrigger>
                        <TabsTrigger value="firmographics">Firmographics</TabsTrigger>
                        <TabsTrigger value="demographics">Demographics</TabsTrigger>
                        <TabsTrigger value="psychographics">Psychographics</TabsTrigger>
                        <TabsTrigger value="subsegments">Sub-Segments</TabsTrigger>
                      </TabsList>

                      {/* Overview Tab */}
                      <TabsContent value="overview" className="space-y-4 mt-4">
                        <div className="space-y-2">
                          <Label htmlFor="segmentName">
                            ICP Name *
                          </Label>
                          <Input
                            id="segmentName"
                            value={newSegment.name}
                            onChange={(e) =>
                              setNewSegment((prev) => ({
                                ...prev,
                                name: e.target.value,
                              }))
                            }
                            placeholder="e.g., Mid-Market SaaS Companies"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="segmentDesc">
                            Description
                          </Label>
                          <Textarea
                            id="segmentDesc"
                            value={newSegment.description}
                            onChange={(e) =>
                              setNewSegment((prev) => ({
                                ...prev,
                                description: e.target.value,
                              }))
                            }
                            placeholder="Describe this ideal customer profile"
                            rows={3}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="priority">
                              Priority Level
                            </Label>
                            <Select
                              value={newSegment.priority}
                              onValueChange={(value) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  priority: value,
                                }))
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="high">
                                  <div className="flex items-center gap-2">
                                    <Star className="w-4 h-4 text-amber-500" />
                                    High Priority
                                  </div>
                                </SelectItem>
                                <SelectItem value="medium">
                                  <div className="flex items-center gap-2">
                                    <Star className="w-4 h-4 text-blue-500" />
                                    Medium Priority
                                  </div>
                                </SelectItem>
                                <SelectItem value="low">
                                  <div className="flex items-center gap-2">
                                    <Star className="w-4 h-4 text-gray-500" />
                                    Low Priority
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="estimatedValue">
                              Estimated Annual Value
                            </Label>
                            <Input
                              id="estimatedValue"
                              value={newSegment.estimatedValue}
                              onChange={(e) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  estimatedValue: e.target.value,
                                }))
                              }
                              placeholder="e.g., $50,000 - $200,000"
                            />
                          </div>
                        </div>
                      </TabsContent>

                      {/* Firmographics Tab */}
                      <TabsContent value="firmographics" className="space-y-4 mt-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="companySize" className="flex items-center gap-2">
                              <Building2 className="w-4 h-4" />
                              Company Size
                            </Label>
                            <Input
                              id="companySize"
                              value={newSegment.companySize}
                              onChange={(e) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  companySize: e.target.value,
                                }))
                              }
                              placeholder="e.g., 50-500 employees"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="industry" className="flex items-center gap-2">
                              <Briefcase className="w-4 h-4" />
                              Industry
                            </Label>
                            <Input
                              id="industry"
                              value={newSegment.industry}
                              onChange={(e) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  industry: e.target.value,
                                }))
                              }
                              placeholder="e.g., B2B SaaS, Healthcare, FinTech"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="revenue" className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4" />
                              Annual Revenue
                            </Label>
                            <Input
                              id="revenue"
                              value={newSegment.revenue}
                              onChange={(e) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  revenue: e.target.value,
                                }))
                              }
                              placeholder="e.g., $5M - $50M ARR"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="geography" className="flex items-center gap-2">
                              <MapPin className="w-4 h-4" />
                              Geography
                            </Label>
                            <Input
                              id="geography"
                              value={newSegment.geography}
                              onChange={(e) =>
                                setNewSegment((prev) => ({
                                  ...prev,
                                  geography: e.target.value,
                                }))
                              }
                              placeholder="e.g., North America, EMEA, APAC"
                            />
                          </div>
                        </div>
                      </TabsContent>

                      {/* Demographics Tab */}
                      <TabsContent value="demographics" className="space-y-4 mt-4">
                        <div className="space-y-2">
                          <Label className="flex items-center gap-2">
                            <GraduationCap className="w-4 h-4" />
                            Job Titles
                          </Label>
                          {newSegment.jobTitles.map((title, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={title}
                                onChange={(e) => {
                                  const updated = [...newSegment.jobTitles];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    jobTitles: updated,
                                  }));
                                }}
                                placeholder="e.g., VP of Sales, Director of Marketing"
                              />
                              {idx === newSegment.jobTitles.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      jobTitles: [...prev.jobTitles, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label>Departments</Label>
                          {newSegment.departments.map((dept, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={dept}
                                onChange={(e) => {
                                  const updated = [...newSegment.departments];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    departments: updated,
                                  }));
                                }}
                                placeholder="e.g., Sales, Marketing, Operations"
                              />
                              {idx === newSegment.departments.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      departments: [...prev.departments, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="seniority">Seniority Level</Label>
                          <Input
                            id="seniority"
                            value={newSegment.seniority}
                            onChange={(e) =>
                              setNewSegment((prev) => ({
                                ...prev,
                                seniority: e.target.value,
                              }))
                            }
                            placeholder="e.g., C-Level, VP/Director, Manager"
                          />
                        </div>
                      </TabsContent>

                      {/* Psychographics Tab */}
                      <TabsContent value="psychographics" className="space-y-4 mt-4">
                        <div className="space-y-2">
                          <Label>Customer Jobs</Label>
                          {newSegment.customerJobs.map((job, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={job}
                                onChange={(e) => {
                                  const updated = [...newSegment.customerJobs];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    customerJobs: updated,
                                  }));
                                }}
                                placeholder="What job is the customer trying to get done?"
                              />
                              {idx === newSegment.customerJobs.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      customerJobs: [...prev.customerJobs, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label>Goals & Motivations</Label>
                          {newSegment.goals.map((goal, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={goal}
                                onChange={(e) => {
                                  const updated = [...newSegment.goals];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    goals: updated,
                                  }));
                                }}
                                placeholder="What are their key goals and motivations?"
                              />
                              {idx === newSegment.goals.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      goals: [...prev.goals, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label>Challenges & Frustrations</Label>
                          {newSegment.challenges.map((challenge, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={challenge}
                                onChange={(e) => {
                                  const updated = [...newSegment.challenges];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    challenges: updated,
                                  }));
                                }}
                                placeholder="What challenges or frustrations do they face?"
                              />
                              {idx === newSegment.challenges.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      challenges: [...prev.challenges, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label>Decision Criteria</Label>
                          {newSegment.decisionCriteria.map((criteria, idx) => (
                            <div key={idx} className="flex gap-2">
                              <Input
                                value={criteria}
                                onChange={(e) => {
                                  const updated = [...newSegment.decisionCriteria];
                                  updated[idx] = e.target.value;
                                  setNewSegment((prev) => ({
                                    ...prev,
                                    decisionCriteria: updated,
                                  }));
                                }}
                                placeholder="What criteria do they use to make decisions?"
                              />
                              {idx === newSegment.decisionCriteria.length - 1 && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setNewSegment((prev) => ({
                                      ...prev,
                                      decisionCriteria: [...prev.decisionCriteria, ""],
                                    }))
                                  }
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="buyingProcess">Buying Process</Label>
                          <Textarea
                            id="buyingProcess"
                            value={newSegment.buyingProcess}
                            onChange={(e) =>
                              setNewSegment((prev) => ({
                                ...prev,
                                buyingProcess: e.target.value,
                              }))
                            }
                            placeholder="Describe their typical buying process and decision-making flow"
                            rows={3}
                          />
                        </div>
                      </TabsContent>

                      {/* Sub-Segments Tab */}
                      <TabsContent value="subsegments" className="space-y-4 mt-4">
                        <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200">
                          <CardContent className="pt-4">
                            <div className="flex items-start gap-2">
                              <Info className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                              <p className="text-sm text-amber-900 dark:text-amber-100">
                                Define sub-segments within this ICP for more granular targeting (e.g., by vertical, use case, or maturity)
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <div className="text-center py-8 text-muted-foreground">
                          <p className="text-sm">Sub-segment functionality coming soon</p>
                          <p className="text-xs mt-1">Add the main ICP first, then configure sub-segments in future updates</p>
                        </div>
                      </TabsContent>
                    </Tabs>

                    <Separator />

                    <Button
                      onClick={addCustomerSegment}
                      className="w-full"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Save ICP
                    </Button>
                  </div>

                  {formData.customerSegments.length > 0 && (
                    <div className="space-y-3">
                      <Label>
                        Ideal Customer Profiles ({formData.customerSegments.length})
                      </Label>
                      {formData.customerSegments.map((seg) => (
                        <Card key={seg.id} className="border-l-4 border-l-blue-500">
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-start gap-3 mb-3">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-1">
                                      <h5 className="font-semibold">{seg.name}</h5>
                                      {seg.priority && (
                                        <Badge variant={seg.priority === "high" ? "default" : "secondary"}>
                                          {seg.priority === "high" ? "High Priority" : seg.priority === "medium" ? "Medium" : "Low"}
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                      {seg.description}
                                    </p>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  {seg.companySize && (
                                    <div>
                                      <span className="text-muted-foreground">Company Size:</span>
                                      <p>{seg.companySize}</p>
                                    </div>
                                  )}
                                  {seg.industry && (
                                    <div>
                                      <span className="text-muted-foreground">Industry:</span>
                                      <p>{seg.industry}</p>
                                    </div>
                                  )}
                                  {seg.revenue && (
                                    <div>
                                      <span className="text-muted-foreground">Revenue:</span>
                                      <p>{seg.revenue}</p>
                                    </div>
                                  )}
                                  {seg.geography && (
                                    <div>
                                      <span className="text-muted-foreground">Geography:</span>
                                      <p>{seg.geography}</p>
                                    </div>
                                  )}
                                </div>

                                <div className="flex flex-wrap gap-2 mt-3">
                                  {seg.customerJobs && seg.customerJobs.length > 0 && (
                                    <Badge variant="secondary">
                                      {seg.customerJobs.length} jobs
                                    </Badge>
                                  )}
                                  {seg.goals && seg.goals.length > 0 && (
                                    <Badge variant="secondary">
                                      {seg.goals.length} goals
                                    </Badge>
                                  )}
                                  {seg.challenges && seg.challenges.length > 0 && (
                                    <Badge variant="secondary">
                                      {seg.challenges.length} challenges
                                    </Badge>
                                  )}
                                  {seg.jobTitles && seg.jobTitles.filter((t: string) => t).length > 0 && (
                                    <Badge variant="secondary">
                                      {seg.jobTitles.filter((t: string) => t).length} roles
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setFormData((prev) => ({
                                    ...prev,
                                    customerSegments:
                                      prev.customerSegments.filter(
                                        (s) => s.id !== seg.id,
                                      ),
                                  }));
                                  toast.success("ICP removed");
                                }}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              )}

              {/* Step 3: Products & Services */}
              {currentStep === 3 && (
                <>
                  <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                          List the products and services that create value for customers
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-4 border rounded-lg p-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Add Product/Service
                    </h4>

                    <div className="space-y-2">
                      <Label htmlFor="productName">Name *</Label>
                      <Input
                        id="productName"
                        value={newProduct.name}
                        onChange={(e) =>
                          setNewProduct((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="e.g., Analytics Dashboard"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="productDesc">Description</Label>
                      <Textarea
                        id="productDesc"
                        value={newProduct.description}
                        onChange={(e) =>
                          setNewProduct((prev) => ({
                            ...prev,
                            description: e.target.value,
                          }))
                        }
                        placeholder="Describe this product/service"
                        rows={2}
                      />
                    </div>

                    <Button onClick={addProductService} className="w-full">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Product/Service
                    </Button>
                  </div>

                  {formData.productsServices.length > 0 && (
                    <div className="space-y-3">
                      <Label>
                        Added Products/Services ({formData.productsServices.length})
                      </Label>
                      {formData.productsServices.map((prod) => (
                        <Card key={prod.id}>
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <h5 className="font-semibold">{prod.name}</h5>
                                <p className="text-sm text-muted-foreground">
                                  {prod.description}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setFormData((prev) => ({
                                    ...prev,
                                    productsServices: prev.productsServices.filter(
                                      (p) => p.id !== prod.id,
                                    ),
                                  }));
                                }}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              )}

              {/* Step 4: Pain Relievers */}
              {currentStep === 4 && (
                <>
                  <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                          Describe how your offerings alleviate customer pains
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {formData.customerSegments.length === 0 ? (
                    <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900">
                      <CardContent className="pt-4">
                        <p className="text-sm text-amber-900 dark:text-amber-100">
                          Please add customer segments first (Step 2)
                        </p>
                      </CardContent>
                    </Card>
                  ) : (
                    <>
                      <div className="space-y-4 border rounded-lg p-4">
                        <h4 className="font-semibold flex items-center gap-2">
                          <Plus className="w-4 h-4" />
                          Add Pain Reliever
                        </h4>

                        <div className="space-y-2">
                          <Label htmlFor="painSegment">Customer Segment *</Label>
                          <Select
                            value={newPainReliever.segmentId}
                            onValueChange={(value) =>
                              setNewPainReliever((prev) => ({
                                ...prev,
                                segmentId: value,
                              }))
                            }
                          >
                            <SelectTrigger id="painSegment">
                              <SelectValue placeholder="Select segment" />
                            </SelectTrigger>
                            <SelectContent>
                              {formData.customerSegments.map((seg) => (
                                <SelectItem key={seg.id} value={seg.id}>
                                  {seg.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="painAddressed">Pain Addressed *</Label>
                          <Input
                            id="painAddressed"
                            value={newPainReliever.painAddressed}
                            onChange={(e) =>
                              setNewPainReliever((prev) => ({
                                ...prev,
                                painAddressed: e.target.value,
                              }))
                            }
                            placeholder="What pain point does this address?"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="solution">Solution</Label>
                          <Textarea
                            id="solution"
                            value={newPainReliever.solution}
                            onChange={(e) =>
                              setNewPainReliever((prev) => ({
                                ...prev,
                                solution: e.target.value,
                              }))
                            }
                            placeholder="How do you relieve this pain?"
                            rows={2}
                          />
                        </div>

                        <Button onClick={addPainReliever} className="w-full">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Pain Reliever
                        </Button>
                      </div>

                      {formData.painRelievers.length > 0 && (
                        <div className="space-y-3">
                          <Label>
                            Added Pain Relievers ({formData.painRelievers.length})
                          </Label>
                          {formData.painRelievers.map((pr) => (
                            <Card key={pr.id}>
                              <CardContent className="pt-4">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <h5 className="font-semibold">
                                      {pr.painAddressed}
                                    </h5>
                                    <p className="text-sm text-muted-foreground">
                                      {pr.solution}
                                    </p>
                                    <Badge variant="secondary" className="mt-2">
                                      {
                                        formData.customerSegments.find(
                                          (s) => s.id === pr.segmentId,
                                        )?.name
                                      }
                                    </Badge>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setFormData((prev) => ({
                                        ...prev,
                                        painRelievers: prev.painRelievers.filter(
                                          (p) => p.id !== pr.id,
                                        ),
                                      }));
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </>
              )}

              {/* Step 5: Gain Creators */}
              {currentStep === 5 && (
                <>
                  <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                          Describe how your offerings create customer gains
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {formData.customerSegments.length === 0 ? (
                    <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900">
                      <CardContent className="pt-4">
                        <p className="text-sm text-amber-900 dark:text-amber-100">
                          Please add customer segments first (Step 2)
                        </p>
                      </CardContent>
                    </Card>
                  ) : (
                    <>
                      <div className="space-y-4 border rounded-lg p-4">
                        <h4 className="font-semibold flex items-center gap-2">
                          <Plus className="w-4 h-4" />
                          Add Gain Creator
                        </h4>

                        <div className="space-y-2">
                          <Label htmlFor="gainSegment">Customer Segment *</Label>
                          <Select
                            value={newGainCreator.segmentId}
                            onValueChange={(value) =>
                              setNewGainCreator((prev) => ({
                                ...prev,
                                segmentId: value,
                              }))
                            }
                          >
                            <SelectTrigger id="gainSegment">
                              <SelectValue placeholder="Select segment" />
                            </SelectTrigger>
                            <SelectContent>
                              {formData.customerSegments.map((seg) => (
                                <SelectItem key={seg.id} value={seg.id}>
                                  {seg.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="gainDelivered">Gain Delivered *</Label>
                          <Input
                            id="gainDelivered"
                            value={newGainCreator.gainDelivered}
                            onChange={(e) =>
                              setNewGainCreator((prev) => ({
                                ...prev,
                                gainDelivered: e.target.value,
                              }))
                            }
                            placeholder="What gain do you create?"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="mechanism">Mechanism</Label>
                          <Textarea
                            id="mechanism"
                            value={newGainCreator.mechanism}
                            onChange={(e) =>
                              setNewGainCreator((prev) => ({
                                ...prev,
                                mechanism: e.target.value,
                              }))
                            }
                            placeholder="How do you create this gain?"
                            rows={2}
                          />
                        </div>

                        <Button onClick={addGainCreator} className="w-full">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Gain Creator
                        </Button>
                      </div>

                      {formData.gainCreators.length > 0 && (
                        <div className="space-y-3">
                          <Label>
                            Added Gain Creators ({formData.gainCreators.length})
                          </Label>
                          {formData.gainCreators.map((gc) => (
                            <Card key={gc.id}>
                              <CardContent className="pt-4">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <h5 className="font-semibold">
                                      {gc.gainDelivered}
                                    </h5>
                                    <p className="text-sm text-muted-foreground">
                                      {gc.mechanism}
                                    </p>
                                    <Badge variant="secondary" className="mt-2">
                                      {
                                        formData.customerSegments.find(
                                          (s) => s.id === gc.segmentId,
                                        )?.name
                                      }
                                    </Badge>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setFormData((prev) => ({
                                        ...prev,
                                        gainCreators: prev.gainCreators.filter(
                                          (g) => g.id !== gc.id,
                                        ),
                                      }));
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </>
              )}

              {/* Step 6: Value Metrics */}
              {currentStep === 6 && (
                <>
                  <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                          Define metrics to measure value delivered
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-4 border rounded-lg p-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Add Value Metric
                    </h4>

                    <div className="space-y-2">
                      <Label htmlFor="metricName">Metric Name *</Label>
                      <Input
                        id="metricName"
                        value={newValueMetric.name}
                        onChange={(e) =>
                          setNewValueMetric((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="e.g., Customer Satisfaction"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="metricDesc">Description</Label>
                      <Textarea
                        id="metricDesc"
                        value={newValueMetric.description}
                        onChange={(e) =>
                          setNewValueMetric((prev) => ({
                            ...prev,
                            description: e.target.value,
                          }))
                        }
                        placeholder="Describe this metric"
                        rows={2}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="current">Current Value</Label>
                        <Input
                          id="current"
                          value={newValueMetric.current}
                          onChange={(e) =>
                            setNewValueMetric((prev) => ({
                              ...prev,
                              current: e.target.value,
                            }))
                          }
                          placeholder="e.g., 75%"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="target">Target Value</Label>
                        <Input
                          id="target"
                          value={newValueMetric.target}
                          onChange={(e) =>
                            setNewValueMetric((prev) => ({
                              ...prev,
                              target: e.target.value,
                            }))
                          }
                          placeholder="e.g., 90%"
                        />
                      </div>
                    </div>

                    <Button onClick={addValueMetric} className="w-full">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Value Metric
                    </Button>
                  </div>

                  {formData.valueMetrics.length > 0 && (
                    <div className="space-y-3">
                      <Label>
                        Added Value Metrics ({formData.valueMetrics.length})
                      </Label>
                      {formData.valueMetrics.map((vm) => (
                        <Card key={vm.id}>
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h5 className="font-semibold">{vm.name}</h5>
                                <p className="text-sm text-muted-foreground">
                                  {vm.description}
                                </p>
                                <div className="flex gap-3 mt-2">
                                  {vm.current && (
                                    <Badge variant="outline">
                                      Current: {vm.current}
                                    </Badge>
                                  )}
                                  {vm.target && (
                                    <Badge variant="outline">
                                      Target: {vm.target}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setFormData((prev) => ({
                                    ...prev,
                                    valueMetrics: prev.valueMetrics.filter(
                                      (m) => m.id !== vm.id,
                                    ),
                                  }));
                                }}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              )}

              {/* Step 7: Pricing Strategy */}
              {currentStep === 7 && (
                <>
                  <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-green-900 dark:text-green-100">
                          Select a pricing tier that aligns with your value proposition and target market
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Choose Your Pricing Plan</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {mockPricingTiers.map((tier) => (
                        <div key={tier.id} className={selectedPricingTier === tier.id ? "ring-2 ring-primary rounded-lg" : ""}>
                          <PricingCard
                            tier={tier}
                            onSelect={(tierId) => {
                              setSelectedPricingTier(tierId);
                              toast.success(`${tier.name} plan selected`);
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {selectedPricingTier && (
                    <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                      <CardContent className="pt-4">
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-blue-900 dark:text-blue-100">
                            Selected: <strong>{mockPricingTiers.find(t => t.id === selectedPricingTier)?.name}</strong> plan
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}

              {/* Step 8: Review */}
              {currentStep === 8 && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="vpName">
                      Value Proposition Name *
                    </Label>
                    <Input
                      id="vpName"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      placeholder="Give your value proposition a name"
                    />
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold text-[#00a4bf]">
                          {formData.customerSegments.length}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Segments
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold text-[#e84e1c]">
                          {formData.productsServices.length}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Products
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold text-orange-500">
                          {formData.painRelievers.length}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Pain Relievers
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold text-green-500">
                          {formData.gainCreators.length}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Gain Creators
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-green-900 dark:text-green-100">
                            Ready to Save
                          </p>
                          <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                            Review your value proposition and click "Save & Finalize" when ready
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            <Button
              variant="outline"
              onClick={handleBack}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            {currentStep < 8 ? (
              <Button onClick={handleNext}>
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleSave}
                className="bg-green-600 hover:bg-green-700"
              >
                <Save className="w-4 h-4 mr-2" />
                Save & Finalize
              </Button>
            )}
          </div>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
