import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Palette, Layout, Smartphone, Monitor, Figma, Sparkles, Users, FileText } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface DesignUIUXProps {
  onBack: () => void;
}

export function DesignUIUX({ onBack }: DesignUIUXProps) {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Design UI UX Process</h2>
            <p className="text-muted-foreground">
              Design user interfaces, user experiences, and visual design systems
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        </div>
      </div>

      {/* Design UI UX Process Steps */}
      <div className="space-y-4">
        {/* DU 100 - Design Research & Strategy */}
        <Card className="border-l-4 border-l-pink-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-pink-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-pink-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 100</Badge>
                  <CardTitle>Design Research & Strategy</CardTitle>
                  <CardDescription className="mt-1">
                    Conduct user research, competitive analysis, and define design strategy
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define user personas, journey maps, and design principles</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 200 - Information Architecture */}
        <Card className="border-l-4 border-l-indigo-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                  <Layout className="w-6 h-6 text-indigo-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 200</Badge>
                  <CardTitle>Information Architecture & Wireframing</CardTitle>
                  <CardDescription className="mt-1">
                    Structure content hierarchy, navigation, and create wireframes
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define site maps, user flows, and low-fidelity wireframes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 300 - Visual Design System */}
        <Card className="border-l-4 border-l-violet-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <Palette className="w-6 h-6 text-violet-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 300</Badge>
                  <CardTitle>Visual Design System & Branding</CardTitle>
                  <CardDescription className="mt-1">
                    Create design tokens, color palettes, typography, and component libraries
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define colors, fonts, spacing, iconography, and design tokens</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 400 - UI Component Design */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Figma className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 400</Badge>
                  <CardTitle>UI Component Design & Prototyping</CardTitle>
                  <CardDescription className="mt-1">
                    Design reusable UI components and interactive prototypes
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Create buttons, forms, cards, modals, and component variants</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 500 - Responsive Design */}
        <Card className="border-l-4 border-l-cyan-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <div className="flex items-center gap-1">
                    <Monitor className="w-4 h-4 text-cyan-500" />
                    <Smartphone className="w-3 h-3 text-cyan-500" />
                  </div>
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 500</Badge>
                  <CardTitle>Responsive & Adaptive Design</CardTitle>
                  <CardDescription className="mt-1">
                    Design for multiple screen sizes, devices, and accessibility standards
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define breakpoints, mobile-first approach, and WCAG compliance</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 600 - Interaction Design */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 600</Badge>
                  <CardTitle>Interaction Design & Microinteractions</CardTitle>
                  <CardDescription className="mt-1">
                    Define animations, transitions, and interactive feedback systems
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Create hover states, loading animations, and transition timing</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 700 - Design Documentation */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 700</Badge>
                  <CardTitle>Design Documentation & Handoff</CardTitle>
                  <CardDescription className="mt-1">
                    Create design specs, style guides, and developer handoff documentation
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define design specifications, component usage guidelines, and handoff assets</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DU 800 - Usability Testing */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DU 800</Badge>
                  <CardTitle>Usability Testing & Iteration</CardTitle>
                  <CardDescription className="mt-1">
                    Conduct user testing, gather feedback, and iterate on designs
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define testing protocols, feedback collection, and iteration cycles</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}