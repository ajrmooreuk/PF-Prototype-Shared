import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Eye, TrendingUp, BarChart3, Users, Search, Target, Zap, Award } from "lucide-react";
import { toast } from "sonner@2.0.3";

export function ProductBAIV() {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Product BAIV Platform AI Visibility</h2>
            <p className="text-muted-foreground">
              Strategic AI visibility initiatives for product positioning and market presence
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              window.history.back();
              toast.success("Returned to PF Dashboard");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to PF Dashboard
          </Button>
        </div>
      </div>

      {/* Product BAIV Process Steps */}
      <div className="space-y-4">
        {/* PB 100 - AI Visibility Strategy */}
        <Card className="border-l-4 border-l-cyan-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <Eye className="w-6 h-6 text-cyan-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 100</Badge>
                  <CardTitle>AI Visibility Strategy</CardTitle>
                  <CardDescription className="mt-1">
                    Define AI visibility goals, target audiences, and positioning strategy
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define visibility objectives, target personas, and market positioning</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 200 - Market Intelligence */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Search className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 200</Badge>
                  <CardTitle>Market Intelligence & Research</CardTitle>
                  <CardDescription className="mt-1">
                    AI-powered market analysis, competitor insights, and trend identification
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Configure market scanning, competitor analysis, and trend monitoring</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 300 - Content Strategy */}
        <Card className="border-l-4 border-l-indigo-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                  <Target className="w-6 h-6 text-indigo-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 300</Badge>
                  <CardTitle>Content Strategy & Distribution</CardTitle>
                  <CardDescription className="mt-1">
                    AI-optimized content creation, SEO strategy, and multi-channel distribution
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define content pillars, SEO optimization, and distribution channels</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 400 - Audience Engagement */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 400</Badge>
                  <CardTitle>Audience Engagement & Growth</CardTitle>
                  <CardDescription className="mt-1">
                    Build and engage target audiences across digital platforms
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define engagement tactics, community building, and growth strategies</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 500 - Performance Analytics */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 500</Badge>
                  <CardTitle>Performance Analytics & Insights</CardTitle>
                  <CardDescription className="mt-1">
                    Measure visibility metrics, ROI, and audience behavior patterns
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define KPIs, tracking dashboards, and performance reporting</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 600 - Optimization & Scaling */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 600</Badge>
                  <CardTitle>Optimization & Scaling</CardTitle>
                  <CardDescription className="mt-1">
                    Continuous improvement and scalable growth strategies
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define A/B testing, conversion optimization, and scaling frameworks</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 700 - Brand Authority */}
        <Card className="border-l-4 border-l-rose-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-rose-500/10 flex items-center justify-center">
                  <Award className="w-6 h-6 text-rose-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 700</Badge>
                  <CardTitle>Brand Authority & Thought Leadership</CardTitle>
                  <CardDescription className="mt-1">
                    Establish industry authority and thought leadership presence
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define speaking opportunities, publications, partnerships, and recognition</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PB 800 - AI-Powered Reputation */}
        <Card className="border-l-4 border-l-teal-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-teal-500/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-teal-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PB 800</Badge>
                  <CardTitle>AI-Powered Reputation Management</CardTitle>
                  <CardDescription className="mt-1">
                    Monitor and enhance brand reputation using AI-driven insights
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define sentiment analysis, reputation monitoring, and crisis management</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
