import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { TrendingUp, TrendingDown, Users, DollarSign, Activity, Package, ChevronDown, ChevronUp, Filter, Target, Briefcase, PiggyBank, GraduationCap, Shield, Check, X } from "lucide-react";
import type { Platform, DashboardMetric } from "./types";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Sparkline } from "../../components/Sparkline";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";

interface PlatformDashboardProps {
  platforms: Platform[];
  metrics: DashboardMetric[];
}

// TODO: Future enhancement - Add PF Instance config ontology data input/edit functionality
// This will allow users to configure and manage instance-level ontology settings,
// including custom data models, relationships, and validation rules

export function PlatformDashboard({ platforms, metrics }: PlatformDashboardProps) {
  const [selectedInstance, setSelectedInstance] = useState<string>("all");
  const [selectedProduct, setSelectedProduct] = useState<string>("all");
  const [expandedPlatforms, setExpandedPlatforms] = useState<string[]>([]);
  const [bscPerspective, setBscPerspective] = useState<string>("customer");

  // BSC Perspective Data
  const bscPerspectives = {
    customer: {
      title: "Customer Perspective",
      icon: Users,
      color: "#00a4bf",
      metrics: [
        { label: "Customer Satisfaction (NPS)", value: "42", target: "50", unit: "score", trend: "up", change: 8 },
        { label: "Customer Retention Rate", value: "92%", target: "95%", unit: "%", trend: "up", change: 3 },
        { label: "Time to Value", value: "21 days", target: "14 days", unit: "days", trend: "down", change: -15 },
        { label: "Active Users", value: "6.5K", target: "10K", unit: "users", trend: "up", change: 12 },
        { label: "Feature Adoption Rate", value: "68%", target: "85%", unit: "%", trend: "up", change: 5 },
        { label: "Customer Support CSAT", value: "85%", target: "90%", unit: "%", trend: "up", change: 2 },
      ],
      goals: [
        "Achieve 90%+ customer satisfaction (NPS 50+)",
        "Reduce time-to-value to <14 days",
        "Increase adoption rate to 85%+",
        "Build community of 10k+ active users",
      ],
      initiatives: [
        "AI-powered onboarding",
        "Customer success AI assistant",
        "Value tracking dashboard",
        "In-app guidance system",
      ],
    },
    internal: {
      title: "Internal Process Perspective",
      icon: Briefcase,
      color: "#2196f3",
      metrics: [
        { label: "Platform Uptime", value: "99.7%", target: "99.9%", unit: "%", trend: "up", change: 0.2 },
        { label: "API Response Time", value: "145ms", target: "<100ms", unit: "ms", trend: "down", change: -8 },
        { label: "Data Processing Volume", value: "7M/day", target: "10M/day", unit: "points", trend: "up", change: 18 },
        { label: "Model Accuracy", value: "92%", target: "95%", unit: "%", trend: "up", change: 3 },
        { label: "Deployment Speed", value: "72h", target: "48h", unit: "hours", trend: "down", change: -12 },
        { label: "Bug Resolution Time", value: "4.2h", target: "3h", unit: "hours", trend: "down", change: -15 },
      ],
      salesMarketingKPIs: [
        { 
          label: "Lead Conversion Rate", 
          value: "24%", 
          target: "30%", 
          trend: "up", 
          change: 8,
          sparklineData: [18, 19, 21, 20, 22, 23, 24, 25, 24, 24],
          color: "#00a4bf"
        },
        { 
          label: "Marketing Qualified Leads", 
          value: "342", 
          target: "500", 
          trend: "up", 
          change: 15,
          sparklineData: [280, 290, 305, 298, 315, 325, 330, 335, 340, 342],
          color: "#2196f3"
        },
        { 
          label: "Sales Qualified Leads", 
          value: "156", 
          target: "200", 
          trend: "up", 
          change: 12,
          sparklineData: [120, 125, 130, 135, 140, 145, 148, 152, 154, 156],
          color: "#4caf50"
        },
        { 
          label: "Sales Cycle Length", 
          value: "45 days", 
          target: "30 days", 
          trend: "down", 
          change: -10,
          sparklineData: [52, 51, 50, 49, 48, 47, 46, 45, 45, 45],
          color: "#ff9800"
        },
        { 
          label: "Marketing ROI", 
          value: "3.2x", 
          target: "4.0x", 
          trend: "up", 
          change: 18,
          sparklineData: [2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.15, 3.2],
          color: "#9c27b0"
        },
        { 
          label: "Campaign Success Rate", 
          value: "68%", 
          target: "75%", 
          trend: "up", 
          change: 5,
          sparklineData: [60, 62, 63, 64, 65, 66, 67, 67, 68, 68],
          color: "#e91e63"
        },
        { 
          label: "Pipeline Velocity", 
          value: "$2.4M", 
          target: "$3.5M", 
          trend: "up", 
          change: 22,
          sparklineData: [1.8, 1.9, 2.0, 2.1, 2.15, 2.2, 2.25, 2.3, 2.35, 2.4],
          color: "#00bcd4"
        },
        { 
          label: "Customer Acquisition Cost", 
          value: "$1,450", 
          target: "$1,200", 
          trend: "down", 
          change: -8,
          sparklineData: [1650, 1620, 1590, 1560, 1530, 1500, 1480, 1460, 1455, 1450],
          color: "#ff5722"
        },
      ],
      goals: [
        "Automate 80% of visibility reporting",
        "Deploy AI models in <48 hours",
        "Achieve 99.9% platform uptime",
        "Process 10M+ data points daily",
      ],
      initiatives: [
        "ML pipeline automation",
        "Real-time analytics engine",
        "Infrastructure scaling",
        "DevOps optimization",
      ],
    },
    finance: {
      title: "Financial Perspective",
      icon: PiggyBank,
      color: "#4caf50",
      metrics: [
        { label: "Annual Recurring Revenue", value: "$12M", target: "$50M", unit: "USD", trend: "up", change: 28 },
        { label: "MRR Growth", value: "12%", target: "15%", unit: "%", trend: "up", change: 2 },
        { label: "Gross Margin", value: "68%", target: "70%", unit: "%", trend: "up", change: 3 },
        { label: "CAC Payback Period", value: "8 mo", target: "6 mo", unit: "months", trend: "down", change: -10 },
        { label: "LTV:CAC Ratio", value: "4:1", target: "5:1", unit: "ratio", trend: "up", change: 15 },
        { label: "Net Revenue Retention", value: "115%", target: "120%", unit: "%", trend: "up", change: 5 },
      ],
      goals: [
        "Reach $50M ARR by 2025",
        "Achieve profitability by Q4 2025",
        "Maintain 120%+ NDR",
        "Reduce CAC by 30%",
      ],
      initiatives: [
        "Product-led growth strategy",
        "Pricing optimization",
        "Expansion revenue programs",
        "Cost efficiency initiatives",
      ],
    },
    learning: {
      title: "Learning & Growth Perspective",
      icon: GraduationCap,
      color: "#9c27b0",
      metrics: [
        { label: "Training Hours per Quarter", value: "28h", target: "40h", unit: "hours", trend: "up", change: 12 },
        { label: "AI Models Deployed", value: "9", target: "15", unit: "models", trend: "up", change: 25 },
        { label: "Patents Filed", value: "2", target: "5", unit: "patents", trend: "up", change: 100 },
        { label: "Research Papers Published", value: "4", target: "10", unit: "papers", trend: "up", change: 33 },
        { label: "Certifications Achieved", value: "1", target: "3", unit: "certs", trend: "neutral", change: 0 },
        { label: "Employee Satisfaction", value: "82%", target: "90%", unit: "%", trend: "up", change: 5 },
      ],
      goals: [
        "Train team on latest AI/ML techniques",
        "Build proprietary AI visibility models",
        "Achieve ISO 27001 certification",
        "Develop 5+ AI patents",
      ],
      initiatives: [
        "Continuous learning program",
        "R&D investment increase",
        "Innovation labs",
        "Industry partnerships",
      ],
    },
  };

  // RBAC (Role-Based Access Control) for each perspective
  const rbacPermissions = {
    customer: {
      title: "Customer Perspective Access Control",
      description: "Permissions for customer-facing metrics and features",
      capabilities: [
        {
          capability: "View Metrics Dashboard",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Export Customer Reports",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Customer Preferences",
          admin: true,
          client: true,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Access Historical Data",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Submit Feedback/Support Tickets",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "View Satisfaction Scores",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Configure Alerts/Notifications",
          admin: true,
          client: true,
          agency: false,
          affiliates: false,
        },
      ],
    },
    internal: {
      title: "Internal Process Perspective Access Control",
      description: "Permissions for internal operations and processes",
      capabilities: [
        {
          capability: "View Platform Operations Metrics",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Sales & Marketing KPIs",
          admin: true,
          client: false,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Access Development Tools",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Submit Bug Reports",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "View System Status",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Campaign Analytics",
          admin: true,
          client: false,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Access API Documentation",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
      ],
    },
    finance: {
      title: "Financial Perspective Access Control",
      description: "Permissions for financial data and billing",
      capabilities: [
        {
          capability: "View Full Financial Dashboard",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Own Billing Information",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Download Invoices",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Payment Methods",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "View Revenue Metrics",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Access Commission Reports",
          admin: true,
          client: false,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Modify Pricing/Plans",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
      ],
    },
    learning: {
      title: "Learning & Growth Perspective Access Control",
      description: "Permissions for training and development resources",
      capabilities: [
        {
          capability: "Access Training Library",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Enroll in Courses",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "View Certification Progress",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Access Advanced AI Training",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Create/Manage Training Content",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Team Training Analytics",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Download Certifications",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
      ],
    },
  };

  // PF Instances - Adding BAIV, PF Core, and W4M
  const pfInstances = [
    { id: "all", name: "All Instances" },
    { id: "baiv", name: "BAIV" },
    { id: "pf-core", name: "PF Core" },
    { id: "w4m", name: "W4M" },
  ];

  // Get all products from all platforms
  const allProducts = platforms.flatMap(p => p.products || []);
  const uniqueProducts = Array.from(
    new Map(allProducts.map(p => [p.id, p])).values()
  );

  // Filter platforms based on selection
  const filteredPlatforms = platforms.filter(platform => {
    if (selectedInstance !== "all" && platform.id !== selectedInstance) {
      return false;
    }
    return true;
  });

  // Filter products based on selection
  const getFilteredProducts = (platformProducts: any[]) => {
    if (selectedProduct === "all") {
      return platformProducts;
    }
    return platformProducts.filter(p => p.id === selectedProduct);
  };

  const getTrendIcon = (trend?: 'up' | 'down' | 'neutral') => {
    if (trend === 'up') return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (trend === 'down') return <TrendingDown className="w-4 h-4 text-red-600" />;
    return null;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Platform Dashboard</h2>
        <p className="text-muted-foreground">Monitor your platform performance</p>
      </div>

      {/* Top-Level Filters */}
      <Card className="border-2 border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="w-5 h-5" />
            PF Instance & Product Filters
          </CardTitle>
          <CardDescription>
            Filter by PF Instance and Product to focus your dashboard view
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* PF Instance Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">PF Instance</label>
              <Select value={selectedInstance} onValueChange={setSelectedInstance}>
                <SelectTrigger>
                  <SelectValue placeholder="Select instance" />
                </SelectTrigger>
                <SelectContent>
                  {pfInstances.map(instance => (
                    <SelectItem key={instance.id} value={instance.id}>
                      {instance.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Product Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Product</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Products</SelectItem>
                  {uniqueProducts.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Active Filter Indicators */}
          {(selectedInstance !== "all" || selectedProduct !== "all") && (
            <div className="flex items-center gap-2 mt-4 pt-4 border-t">
              <span className="text-xs text-muted-foreground">Active Filters:</span>
              {selectedInstance !== "all" && (
                <Badge variant="secondary" className="text-xs">
                  Instance: {pfInstances.find(i => i.id === selectedInstance)?.name}
                </Badge>
              )}
              {selectedProduct !== "all" && (
                <Badge variant="secondary" className="text-xs">
                  Product: {uniqueProducts.find(p => p.id === selectedProduct)?.name}
                </Badge>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSelectedInstance("all");
                  setSelectedProduct("all");
                }}
                className="ml-auto text-xs h-6"
              >
                Clear All
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className="text-2xl font-bold mt-1">{metric.value}</p>
                  {metric.change !== undefined && (
                    <div className="flex items-center gap-1 mt-1">
                      {getTrendIcon(metric.trend)}
                      <span className={`text-sm ${
                        metric.trend === 'up' ? 'text-green-600' : 
                        metric.trend === 'down' ? 'text-red-600' : 
                        'text-muted-foreground'
                      }`}>
                        {metric.change > 0 ? '+' : ''}{metric.change}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* BSC Perspectives Tabs */}
      <Card className="border-2 border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Target className="w-5 h-5" />
            Balanced Scorecard Perspectives
          </CardTitle>
          <CardDescription>
            View key performance indicators across different business perspectives
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={bscPerspective} onValueChange={setBscPerspective}>
            <TabsList className="grid grid-cols-4 max-w-2xl">
              <TabsTrigger value="customer">Customer</TabsTrigger>
              <TabsTrigger value="internal">Internal</TabsTrigger>
              <TabsTrigger value="finance">Finance</TabsTrigger>
              <TabsTrigger value="learning">Learning</TabsTrigger>
            </TabsList>
            <TabsContent value="customer">
              <div className="space-y-4">
                <h4 className="text-lg font-semibold">Customer Perspective</h4>
                <p className="text-sm text-muted-foreground">Focus on customer satisfaction and retention</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bscPerspectives.customer.metrics.map((metric, index) => (
                    <Card key={index}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">{metric.label}</p>
                            <p className="text-2xl font-bold mt-1">{metric.value}</p>
                            {metric.change !== undefined && (
                              <div className="flex items-center gap-1 mt-1">
                                {getTrendIcon(metric.trend)}
                                <span className={`text-sm ${
                                  metric.trend === 'up' ? 'text-green-600' : 
                                  metric.trend === 'down' ? 'text-red-600' : 
                                  'text-muted-foreground'
                                }`}>
                                  {metric.change > 0 ? '+' : ''}{metric.change}%
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            <span className="text-sm text-muted-foreground">{metric.target}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Goals</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.customer.goals.map((goal, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{goal}</li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Initiatives</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.customer.initiatives.map((initiative, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{initiative}</li>
                    ))}
                  </ul>
                </div>

                {/* RBAC Table */}
                <div className="mt-6 border-t pt-6">
                  <h5 className="text-sm font-semibold flex items-center gap-2 mb-4">
                    <Shield className="w-4 h-4" />
                    Platform Access by Roles (RBAC)
                  </h5>
                  <p className="text-xs text-muted-foreground mb-4">
                    {rbacPermissions.customer.description}
                  </p>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-1/2">Capability</TableHead>
                          <TableHead className="text-center">Admin</TableHead>
                          <TableHead className="text-center">Client</TableHead>
                          <TableHead className="text-center">Agency</TableHead>
                          <TableHead className="text-center">Affiliates</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rbacPermissions.customer.capabilities.map((cap, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                            <TableCell className="text-center">
                              {cap.admin ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.client ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.agency ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.affiliates ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="internal">
              <div className="space-y-4">
                <h4 className="text-lg font-semibold">Internal Process Perspective</h4>
                <p className="text-sm text-muted-foreground">Focus on internal efficiency and quality</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bscPerspectives.internal.metrics.map((metric, index) => (
                    <Card key={index}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">{metric.label}</p>
                            <p className="text-2xl font-bold mt-1">{metric.value}</p>
                            {metric.change !== undefined && (
                              <div className="flex items-center gap-1 mt-1">
                                {getTrendIcon(metric.trend)}
                                <span className={`text-sm ${
                                  metric.trend === 'up' ? 'text-green-600' : 
                                  metric.trend === 'down' ? 'text-red-600' : 
                                  'text-muted-foreground'
                                }`}>
                                  {metric.change > 0 ? '+' : ''}{metric.change}%
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            <span className="text-sm text-muted-foreground">{metric.target}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Sales & Marketing KPIs</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {bscPerspectives.internal.salesMarketingKPIs.map((kpi, index) => (
                      <Card key={index}>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-muted-foreground">{kpi.label}</p>
                              <p className="text-2xl font-bold mt-1">{kpi.value}</p>
                              {kpi.change !== undefined && (
                                <div className="flex items-center gap-1 mt-1">
                                  {getTrendIcon(kpi.trend)}
                                  <span className={`text-sm ${
                                    kpi.trend === 'up' ? 'text-green-600' : 
                                    kpi.trend === 'down' ? 'text-red-600' : 
                                    'text-muted-foreground'
                                  }`}>
                                    {kpi.change > 0 ? '+' : ''}{kpi.change}%
                                  </span>
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Target className="w-4 h-4" />
                              <span className="text-sm text-muted-foreground">{kpi.target}</span>
                            </div>
                          </div>
                          <Sparkline
                            data={kpi.sparklineData}
                            color={kpi.color}
                          />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Goals</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.internal.goals.map((goal, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{goal}</li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Initiatives</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.internal.initiatives.map((initiative, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{initiative}</li>
                    ))}
                  </ul>
                </div>

                {/* RBAC Table */}
                <div className="mt-6 border-t pt-6">
                  <h5 className="text-sm font-semibold flex items-center gap-2 mb-4">
                    <Shield className="w-4 h-4" />
                    Platform Access by Roles (RBAC)
                  </h5>
                  <p className="text-xs text-muted-foreground mb-4">
                    {rbacPermissions.internal.description}
                  </p>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-1/2">Capability</TableHead>
                          <TableHead className="text-center">Admin</TableHead>
                          <TableHead className="text-center">Client</TableHead>
                          <TableHead className="text-center">Agency</TableHead>
                          <TableHead className="text-center">Affiliates</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rbacPermissions.internal.capabilities.map((cap, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                            <TableCell className="text-center">
                              {cap.admin ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.client ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.agency ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.affiliates ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="finance">
              <div className="space-y-4">
                <h4 className="text-lg font-semibold">Financial Perspective</h4>
                <p className="text-sm text-muted-foreground">Focus on financial performance and growth</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bscPerspectives.finance.metrics.map((metric, index) => (
                    <Card key={index}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">{metric.label}</p>
                            <p className="text-2xl font-bold mt-1">{metric.value}</p>
                            {metric.change !== undefined && (
                              <div className="flex items-center gap-1 mt-1">
                                {getTrendIcon(metric.trend)}
                                <span className={`text-sm ${
                                  metric.trend === 'up' ? 'text-green-600' : 
                                  metric.trend === 'down' ? 'text-red-600' : 
                                  'text-muted-foreground'
                                }`}>
                                  {metric.change > 0 ? '+' : ''}{metric.change}%
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            <span className="text-sm text-muted-foreground">{metric.target}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Initiatives</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.finance.initiatives.map((initiative, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{initiative}</li>
                    ))}
                  </ul>
                </div>

                {/* RBAC Table */}
                <div className="mt-6 border-t pt-6">
                  <h5 className="text-sm font-semibold flex items-center gap-2 mb-4">
                    <Shield className="w-4 h-4" />
                    Platform Access by Roles (RBAC)
                  </h5>
                  <p className="text-xs text-muted-foreground mb-4">
                    {rbacPermissions.finance.description}
                  </p>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-1/2">Capability</TableHead>
                          <TableHead className="text-center">Admin</TableHead>
                          <TableHead className="text-center">Client</TableHead>
                          <TableHead className="text-center">Agency</TableHead>
                          <TableHead className="text-center">Affiliates</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rbacPermissions.finance.capabilities.map((cap, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                            <TableCell className="text-center">
                              {cap.admin ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.client ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.agency ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.affiliates ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="learning">
              <div className="space-y-4">
                <h4 className="text-lg font-semibold">Learning & Growth Perspective</h4>
                <p className="text-sm text-muted-foreground">Focus on continuous learning and innovation</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {bscPerspectives.learning.metrics.map((metric, index) => (
                    <Card key={index}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-muted-foreground">{metric.label}</p>
                            <p className="text-2xl font-bold mt-1">{metric.value}</p>
                            {metric.change !== undefined && (
                              <div className="flex items-center gap-1 mt-1">
                                {getTrendIcon(metric.trend)}
                                <span className={`text-sm ${
                                  metric.trend === 'up' ? 'text-green-600' : 
                                  metric.trend === 'down' ? 'text-red-600' : 
                                  'text-muted-foreground'
                                }`}>
                                  {metric.change > 0 ? '+' : ''}{metric.change}%
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            <span className="text-sm text-muted-foreground">{metric.target}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="mt-4">
                  <h5 className="text-sm font-semibold">Initiatives</h5>
                  <ul className="list-disc list-inside">
                    {bscPerspectives.learning.initiatives.map((initiative, index) => (
                      <li key={index} className="text-sm text-muted-foreground">{initiative}</li>
                    ))}
                  </ul>
                </div>

                {/* RBAC Table */}
                <div className="mt-6 border-t pt-6">
                  <h5 className="text-sm font-semibold flex items-center gap-2 mb-4">
                    <Shield className="w-4 h-4" />
                    Platform Access by Roles (RBAC)
                  </h5>
                  <p className="text-xs text-muted-foreground mb-4">
                    {rbacPermissions.learning.description}
                  </p>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-1/2">Capability</TableHead>
                          <TableHead className="text-center">Admin</TableHead>
                          <TableHead className="text-center">Client</TableHead>
                          <TableHead className="text-center">Agency</TableHead>
                          <TableHead className="text-center">Affiliates</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rbacPermissions.learning.capabilities.map((cap, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                            <TableCell className="text-center">
                              {cap.admin ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.client ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.agency ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {cap.affiliates ? (
                                <Check className="w-4 h-4 text-green-600 mx-auto" />
                              ) : (
                                <X className="w-4 h-4 text-red-600 mx-auto" />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Platforms List */}
      <div>
        <h3 className="text-lg font-semibold mb-4">PF Instances</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredPlatforms.map((platform) => {
            const isExpanded = expandedPlatforms.includes(platform.id);
            const toggleExpand = () => {
              setExpandedPlatforms(prev => 
                prev.includes(platform.id) 
                  ? prev.filter(id => id !== platform.id)
                  : [...prev, platform.id]
              );
            };
            
            return (
            <Card key={platform.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle>{platform.name}</CardTitle>
                    <CardDescription>{platform.description}</CardDescription>
                  </div>
                  <Badge variant={
                    platform.status === 'active' ? 'default' : 
                    platform.status === 'pending' ? 'secondary' : 
                    'outline'
                  }>
                    {platform.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {platform.metrics && (
                  <div className="flex items-center gap-4 text-sm">
                    {platform.metrics.users && (
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span>{platform.metrics.users}</span>
                      </div>
                    )}
                    {platform.metrics.revenue && (
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-muted-foreground" />
                        <span>${platform.metrics.revenue}</span>
                      </div>
                    )}
                    {platform.metrics.growth && (
                      <div className="flex items-center gap-1">
                        <Activity className="w-4 h-4 text-muted-foreground" />
                        <span>{platform.metrics.growth}%</span>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Instance Products Sub-Navigation */}
                {platform.products && platform.products.length > 0 && (
                  <div className="border-t pt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={toggleExpand}
                      className="w-full justify-between"
                    >
                      <span className="flex items-center gap-2">
                        <Package className="w-4 h-4" />
                        <span className="font-medium">
                          {platform.id === 'baiv' ? 'BAIV Products' : 'Instance Products'} ({platform.products.length})
                        </span>
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </Button>
                    
                    {isExpanded && (
                      <div className="mt-3 space-y-2">
                        {getFilteredProducts(platform.products).map((product) => (
                          <div
                            key={product.id}
                            className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <p className="text-sm font-medium truncate">{product.name}</p>
                                  {product.category && (
                                    <Badge variant="outline" className="text-xs">
                                      {product.category}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {product.description}
                                </p>
                              </div>
                              <Badge 
                                variant={product.status === 'active' ? 'default' : product.status === 'beta' ? 'secondary' : 'outline'}
                                className="shrink-0"
                              >
                                {product.status}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}