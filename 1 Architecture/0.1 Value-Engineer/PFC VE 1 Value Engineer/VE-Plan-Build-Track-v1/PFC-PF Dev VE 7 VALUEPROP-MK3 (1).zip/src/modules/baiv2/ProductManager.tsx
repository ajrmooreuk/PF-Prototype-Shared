import { Button } from "../../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Package, GitBranch, Target, Users, TrendingUp, CheckCircle2, Lightbulb, LineChart } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { MermaidDiagram } from "../../components/MermaidDiagram";

interface ProductManagerProps {
  onBack?: () => void;
}

export function ProductManager({ onBack }: ProductManagerProps) {
  // Example Mermaid diagram showing VE to Product flow
  const veToProductFlow = `
    flowchart LR
      VE[Value Engineering] -->|Customer Insights| VP[Value Propositions]
      VP -->|Translation| F[Product Features]
      F -->|Prioritization| R[Product Roadmap]
      R -->|Development| P[Product Release]
      P -->|Measurement| M[Adoption Metrics]
      M -->|Feedback Loop| VE
      
      style VE fill:#9c27b0,stroke:#7b1fa2,color:#fff
      style VP fill:#00a4bf,stroke:#008ca0,color:#fff
      style F fill:#2196f3,stroke:#1976d2,color:#fff
      style R fill:#4caf50,stroke:#388e3c,color:#fff
      style P fill:#ff9800,stroke:#f57c00,color:#fff
      style M fill:#e91e63,stroke:#c2185b,color:#fff
  `;

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Product Manager</h2>
            <p className="text-muted-foreground">
              Convert value propositions into actual product features aligned with Value Engineering
            </p>
          </div>
          {onBack && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                onBack();
                toast.success("Returned to PF Dashboard");
              }}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to PF Dashboard
            </Button>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {/* VE to Product Flow Diagram */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GitBranch className="w-5 h-5" />
              Value Engineering to Product Flow
            </CardTitle>
            <CardDescription>
              Visual representation of how value propositions translate into product features
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/50 p-4 rounded-lg">
              <MermaidDiagram chart={veToProductFlow} />
            </div>
          </CardContent>
        </Card>

        {/* Value Proposition to Product Features */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Value to Product</Badge>
                  <CardTitle>Value Proposition Translation</CardTitle>
                  <CardDescription className="mt-1">
                    Convert VE value propositions into actionable product features and requirements
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Translation Process</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Value prop decomposition</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Feature prioritization</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>User story mapping</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Acceptance criteria</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Product Roadmap Management */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <GitBranch className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Roadmap</Badge>
                  <CardTitle>Product Roadmap & Planning</CardTitle>
                  <CardDescription className="mt-1">
                    Manage product roadmap aligned with VE objectives and business goals
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Roadmap Components</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Quarterly planning</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Epic management</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Dependency tracking</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Release planning</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Feature Adoption & Change Management */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Adoption</Badge>
                  <CardTitle>Feature Adoption & Change Direction</CardTitle>
                  <CardDescription className="mt-1">
                    Drive feature adoption and direct product changes aligned with VE strategy
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Adoption Strategies</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Feature launch planning</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>User onboarding flows</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>In-app messaging</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Change communication</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Product Metrics & Analytics */}
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center">
                  <LineChart className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Metrics</Badge>
                  <CardTitle>Product Metrics & Performance</CardTitle>
                  <CardDescription className="mt-1">
                    Track product performance metrics aligned with VE value delivery goals
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Key Product Metrics</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Feature usage</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Adoption rate</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Engagement depth</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Time to value</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stakeholder Alignment */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Alignment</Badge>
                  <CardTitle>Cross-Functional Collaboration</CardTitle>
                  <CardDescription className="mt-1">
                    Coordinate with Engineering, Design, Sales, and Marketing for unified execution
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Collaboration Areas</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Engineering coordination</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Design collaboration</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>GTM alignment</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Customer success sync</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded">
          <p>
            <strong>Sign-up Feature:</strong> The Product Manager module bridges Value Engineering and actual product development, enabling systematic conversion of value propositions into features while driving adoption and directing changes aligned with strategic VE objectives.
          </p>
        </div>
      </div>
    </div>
  );
}