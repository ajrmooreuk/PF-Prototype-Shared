export interface PricingTier {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  recommended?: boolean;
}

export interface Platform {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive' | 'pending';
  metrics?: {
    users?: number;
    revenue?: number;
    growth?: number;
  };
  products?: PlatformProduct[];
}

export interface PlatformProduct {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive' | 'beta';
  category?: string;
}

export interface DashboardMetric {
  label: string;
  value: string | number;
  change?: number;
  trend?: 'up' | 'down' | 'neutral';
}