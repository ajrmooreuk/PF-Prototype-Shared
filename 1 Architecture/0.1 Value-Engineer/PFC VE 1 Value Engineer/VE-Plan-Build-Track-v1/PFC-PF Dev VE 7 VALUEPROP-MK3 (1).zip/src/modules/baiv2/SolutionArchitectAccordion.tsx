import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "../../components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { 
  Workflow, 
  Database, 
  Settings, 
  Shield, 
  Layout, 
  Layers, 
  Network, 
  GitBranch,
  Users,
  Briefcase,
  DollarSign,
  Lightbulb,
  Check,
  X,
  FileText,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  Link as LinkIcon
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface SolutionArchitectAccordionProps {
  rbacPerspective: string;
  setRbacPerspective: (value: string) => void;
  rbacPermissions: any;
  setSaSubView: (view: string | null) => void;
  onBackToDashboard: () => void;
}

export function SolutionArchitectAccordion({ 
  rbacPerspective, 
  setRbacPerspective, 
  rbacPermissions,
  setSaSubView,
  onBackToDashboard
}: SolutionArchitectAccordionProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Solution Architect Process</h2>
            <p className="text-muted-foreground">
              Structured workflow for solution architecture design and implementation
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onBackToDashboard}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to PF Dashboard
          </Button>
        </div>
      </div>

      {/* Accordion with all 9 steps */}
      <Accordion type="single" collapsible className="space-y-4">
        {/* Step 1: Instance Requirements & Discovery */}
        <AccordionItem value="step-1" className="border rounded-lg overflow-hidden border-l-4 border-l-violet-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-violet-500/10 flex items-center justify-center shrink-0">
                <Layout className="w-6 h-6 text-violet-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-violet-100 dark:bg-violet-950">SA 100</Badge>
                  <span className="font-semibold">Instance Requirements & Discovery</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Gather and analyze instance-specific business requirements and technical constraints
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-4">
              {/* Scope Description */}
              <div className="p-4 bg-violet-50 dark:bg-violet-950/20 rounded-lg border border-violet-200 dark:border-violet-800">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Layout className="w-4 h-4 text-violet-600" />
                  Scope & Deliverables
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Convert Value Proposition (VP) to Product Requirements Document (PRD)</p>
                  <p>• Create Product Breakdown Structure (PBS) and Work Breakdown Structure (WBS)</p>
                  <p>• Define Epics, Features, and User Stories with acceptance criteria</p>
                  <p>• Specify Functional Requirements (FRs) and Non-Functional Requirements (NFRs)</p>
                  <p>• Establish RBAC (Role-Based Access Control) and RACI (Responsibility Assignment)</p>
                </div>
              </div>

              {/* Requirements Flow */}
              <div className="text-sm text-muted-foreground space-y-2">
                <p className="font-medium">Requirements Discovery Flow:</p>
                <p>VP to PRD conversion → PRD Documentation → PBS & WBS → Epics/Features/Stories Breakdown → FRs & NFRs → RBAC & RACI</p>
                <div className="text-xs mt-2 p-3 bg-muted/50 rounded-lg">
                  <p className="font-medium mb-1">Breakdown Hierarchy:</p>
                  <p><strong>PRD:</strong> Defines what to build (requirements, scope, success criteria)</p>
                  <p><strong>PBS:</strong> Product components breakdown (modules, features, sub-features)</p>
                  <p><strong>WBS:</strong> Work packages breakdown (tasks, deliverables, timelines)</p>
                  <p><strong>Epics/Features/Stories:</strong> Agile breakdown mapped from PBS & WBS (user stories, acceptance criteria)</p>
                </div>
              </div>

              {/* Related Sub-Sections */}
              <div className="border-t pt-4">
                <div className="font-medium mb-3 flex items-center gap-2 text-sm">
                  <LinkIcon className="w-4 h-4 text-violet-600" />
                  Related Sub-Sections
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="justify-start h-auto py-2 px-3"
                    onClick={() => {
                      setSaSubView("requirements");
                      toast.success("Opening Requirements & Discovery");
                    }}
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold">Full Requirements Module</div>
                      <div className="text-xs text-muted-foreground">VP, PRD, PBS, WBS, Stories</div>
                    </div>
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="justify-start h-auto py-2 px-3"
                    disabled
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold flex items-center gap-1">
                        Security Architect <ArrowRight className="w-3 h-3" />
                      </div>
                      <div className="text-xs text-muted-foreground">RBAC & RACI Matrices</div>
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 2: Agent Architect */}
        <AccordionItem value="step-2" className="border rounded-lg overflow-hidden border-l-4 border-l-purple-500 bg-purple-50/30 dark:bg-purple-950/10">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0">
                <Workflow className="w-6 h-6 text-purple-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-purple-100 dark:bg-purple-950">AA 100-600</Badge>
                  <span className="font-semibold">Agent Architect</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Design and configure AI agents for value engineering workflows
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-4">
              {/* Scope Description */}
              <div className="p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Workflow className="w-4 h-4 text-purple-600" />
                  Scope & Deliverables
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Define AI agent roles, capabilities, and workflows for value engineering</p>
                  <p>• Configure agent personas and interaction patterns</p>
                  <p>• Design multi-agent orchestration and collaboration frameworks</p>
                  <p>• Establish agent governance, monitoring, and quality assurance</p>
                  <p>• Integrate agents with data sources, APIs, and external systems</p>
                </div>
              </div>

              {/* Related Sub-Sections */}
              <div className="border-t pt-4">
                <div className="font-medium mb-3 flex items-center gap-2 text-sm">
                  <LinkIcon className="w-4 h-4 text-purple-600" />
                  Related Sub-Sections
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="justify-start h-auto py-2 px-3"
                    onClick={() => {
                      setSaSubView("agent-architect");
                      toast.info("Navigating to Agent Architect");
                    }}
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold">Full Agent Architect Module</div>
                      <div className="text-xs text-muted-foreground">AA 100-600 Process</div>
                    </div>
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="justify-start h-auto py-2 px-3"
                    onClick={() => {
                      setSaSubView("data-architect");
                      toast.info("Navigating to Data Architect");
                    }}
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold flex items-center gap-1">
                        Data Architect <ArrowRight className="w-3 h-3" />
                      </div>
                      <div className="text-xs text-muted-foreground">Data Models & APIs</div>
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 3: Data Architect */}
        <AccordionItem value="step-3" className="border rounded-lg overflow-hidden border-l-4 border-l-blue-500 bg-blue-50/30 dark:bg-blue-950/10">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                <Database className="w-6 h-6 text-blue-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-blue-100 dark:bg-blue-950">DA 100-800</Badge>
                  <span className="font-semibold">Data Architect</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Design ontologies, database schemas, API integrations, and analytics
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-4">
              {/* Scope Description */}
              <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-600" />
                  Scope & Deliverables
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Design data models, schemas, and entity relationships (ERD)</p>
                  <p>• Define ontologies and semantic data structures</p>
                  <p>• Configure database architecture (relational, NoSQL, graph, vector)</p>
                  <p>• Design API contracts, endpoints, and integration patterns</p>
                  <p>• Establish data governance, quality standards, and analytics pipelines</p>
                </div>
              </div>

              {/* Related Sub-Sections */}
              <div className="border-t pt-4">
                <div className="font-medium mb-3 flex items-center gap-2 text-sm">
                  <LinkIcon className="w-4 h-4 text-blue-600" />
                  Related Sub-Sections
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="justify-start h-auto py-2 px-3"
                    onClick={() => {
                      setSaSubView("data-architect");
                      toast.info("Navigating to Data Architect");
                    }}
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold">Full Data Architect Module</div>
                      <div className="text-xs text-muted-foreground">DA 100-800 Process</div>
                    </div>
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="justify-start h-auto py-2 px-3"
                    disabled
                  >
                    <div className="text-left">
                      <div className="text-xs font-semibold flex items-center gap-1">
                        OAA Ontology <ArrowRight className="w-3 h-3" />
                      </div>
                      <div className="text-xs text-muted-foreground">Ontology Validation</div>
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 4: OAA Ontology Architect */}
        <AccordionItem value="step-4" className="border rounded-lg overflow-hidden border-l-4 border-l-green-500 bg-green-50/30 dark:bg-green-950/10">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
                <Settings className="w-6 h-6 text-green-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-green-100 dark:bg-green-950">OAA 100-400</Badge>
                  <span className="font-semibold">OAA Ontology Architect</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Design and validate ontologies with OAA approval process
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Ontology Design • OAA Validation • Semantic Models • Knowledge Graphs</p>
              </div>
              <div className="flex justify-end">
                <Button size="sm" variant="outline" disabled>
                  Configure
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 5: Security Architect - Full RBAC Tables */}
        <AccordionItem value="step-5" className="border rounded-lg overflow-hidden border-l-4 border-l-red-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-red-500/10 flex items-center justify-center shrink-0">
                <Shield className="w-6 h-6 text-red-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-red-100 dark:bg-red-950">SA 600</Badge>
                  <span className="font-semibold">Security Architect</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Role-Based Access Control (RBAC), security architecture, compliance frameworks
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-6">
              {/* Security Focus Areas */}
              <div className="p-4 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-800">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-600" />
                  Security Focus Areas
                </div>
                <div className="text-sm text-muted-foreground">
                  <p>Authentication • Authorization • Encryption • Compliance • GDPR • SOC2 • ISO 27001</p>
                </div>
              </div>

              {/* RBAC Roles Summary */}
              <div>
                <div className="font-medium mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  RBAC Roles Summary (from VE 100 RRR)
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="flex items-center gap-2 text-xs p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <div>
                      <div className="font-semibold">Admin</div>
                      <div className="text-muted-foreground">100% Access</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <CheckCircle2 className="w-5 h-5 text-blue-600" />
                    <div>
                      <div className="font-semibold">Client</div>
                      <div className="text-muted-foreground">68% Access</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <CheckCircle2 className="w-5 h-5 text-purple-600" />
                    <div>
                      <div className="font-semibold">Agency</div>
                      <div className="text-muted-foreground">71% Access</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                    <CheckCircle2 className="w-5 h-5 text-orange-600" />
                    <div>
                      <div className="font-semibold">Affiliates</div>
                      <div className="text-muted-foreground">25% Access</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* RBAC Tables by Perspective */}
              <div className="border-t pt-6">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-red-600" />
                  Platform Access by Roles (RBAC)
                </h4>
                <Tabs value={rbacPerspective} onValueChange={setRbacPerspective}>
                  <TabsList className="grid w-full max-w-2xl grid-cols-4">
                    <TabsTrigger value="customer">
                      <Users className="w-4 h-4 mr-2" />
                      Customer
                    </TabsTrigger>
                    <TabsTrigger value="internal">
                      <Briefcase className="w-4 h-4 mr-2" />
                      Internal
                    </TabsTrigger>
                    <TabsTrigger value="finance">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Finance
                    </TabsTrigger>
                    <TabsTrigger value="learning">
                      <Lightbulb className="w-4 h-4 mr-2" />
                      Learning
                    </TabsTrigger>
                  </TabsList>

                  {/* Customer Perspective */}
                  <TabsContent value="customer" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${rbacPermissions.customer.color}15` }}
                        >
                          <Users className="w-5 h-5" style={{ color: rbacPermissions.customer.color }} />
                        </div>
                        <div>
                          <h5 className="font-semibold">{rbacPermissions.customer.title}</h5>
                          <p className="text-xs text-muted-foreground mt-1">
                            {rbacPermissions.customer.description}
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-1/2">Capability</TableHead>
                              <TableHead className="text-center">Admin</TableHead>
                              <TableHead className="text-center">Client</TableHead>
                              <TableHead className="text-center">Agency</TableHead>
                              <TableHead className="text-center">Affiliates</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rbacPermissions.customer.capabilities.map((cap: any, index: number) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                                <TableCell className="text-center">
                                  {cap.admin ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.client ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.agency ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.affiliates ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Internal Perspective */}
                  <TabsContent value="internal" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${rbacPermissions.internal.color}15` }}
                        >
                          <Briefcase className="w-5 h-5" style={{ color: rbacPermissions.internal.color }} />
                        </div>
                        <div>
                          <h5 className="font-semibold">{rbacPermissions.internal.title}</h5>
                          <p className="text-xs text-muted-foreground mt-1">
                            {rbacPermissions.internal.description}
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-1/2">Capability</TableHead>
                              <TableHead className="text-center">Admin</TableHead>
                              <TableHead className="text-center">Client</TableHead>
                              <TableHead className="text-center">Agency</TableHead>
                              <TableHead className="text-center">Affiliates</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rbacPermissions.internal.capabilities.map((cap: any, index: number) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                                <TableCell className="text-center">
                                  {cap.admin ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.client ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.agency ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.affiliates ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Finance Perspective */}
                  <TabsContent value="finance" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${rbacPermissions.finance.color}15` }}
                        >
                          <DollarSign className="w-5 h-5" style={{ color: rbacPermissions.finance.color }} />
                        </div>
                        <div>
                          <h5 className="font-semibold">{rbacPermissions.finance.title}</h5>
                          <p className="text-xs text-muted-foreground mt-1">
                            {rbacPermissions.finance.description}
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-1/2">Capability</TableHead>
                              <TableHead className="text-center">Admin</TableHead>
                              <TableHead className="text-center">Client</TableHead>
                              <TableHead className="text-center">Agency</TableHead>
                              <TableHead className="text-center">Affiliates</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rbacPermissions.finance.capabilities.map((cap: any, index: number) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                                <TableCell className="text-center">
                                  {cap.admin ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.client ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.agency ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.affiliates ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Learning Perspective */}
                  <TabsContent value="learning" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${rbacPermissions.learning.color}15` }}
                        >
                          <Lightbulb className="w-5 h-5" style={{ color: rbacPermissions.learning.color }} />
                        </div>
                        <div>
                          <h5 className="font-semibold">{rbacPermissions.learning.title}</h5>
                          <p className="text-xs text-muted-foreground mt-1">
                            {rbacPermissions.learning.description}
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-1/2">Capability</TableHead>
                              <TableHead className="text-center">Admin</TableHead>
                              <TableHead className="text-center">Client</TableHead>
                              <TableHead className="text-center">Agency</TableHead>
                              <TableHead className="text-center">Affiliates</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {rbacPermissions.learning.capabilities.map((cap: any, index: number) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium text-sm">{cap.capability}</TableCell>
                                <TableCell className="text-center">
                                  {cap.admin ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.client ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.agency ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  {cap.affiliates ? (
                                    <Check className="w-4 h-4 text-green-600 mx-auto" />
                                  ) : (
                                    <X className="w-4 h-4 text-red-600 mx-auto" />
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Security Policy Codes */}
              <div className="border-t pt-6">
                <div className="font-medium mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-600" />
                  Security Policy Codes
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-muted rounded">
                    <span className="font-mono text-purple-600">AUTH-0xx:</span> Customer Perspective
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <span className="font-mono text-blue-600">AUTH-1xx:</span> Internal Perspective
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <span className="font-mono text-green-600">AUTH-2xx:</span> Finance Perspective
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <span className="font-mono text-orange-600">AUTH-3xx:</span> Learning Perspective
                  </div>
                </div>
              </div>

              {/* Overall Summary */}
              <Card className="border-2 border-primary/20 bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-base">Overall RBAC Summary</CardTitle>
                  <CardDescription className="text-xs">Total capabilities across all perspectives (28 total)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">28/28</div>
                      <div className="text-xs font-medium mt-1">Admin</div>
                      <div className="text-xs text-muted-foreground">100% Access</div>
                    </div>
                    <div className="text-center p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">19/28</div>
                      <div className="text-xs font-medium mt-1">Client</div>
                      <div className="text-xs text-muted-foreground">68% Access</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">20/28</div>
                      <div className="text-xs font-medium mt-1">Agency</div>
                      <div className="text-xs text-muted-foreground">71% Access</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">7/28</div>
                      <div className="text-xs font-medium mt-1">Affiliates</div>
                      <div className="text-xs text-muted-foreground">25% Access</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 6: HLD/DD Architecture Design */}
        <AccordionItem value="step-6" className="border rounded-lg overflow-hidden border-l-4 border-l-sky-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-sky-500/10 flex items-center justify-center shrink-0">
                <Layers className="w-6 h-6 text-sky-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-sky-100 dark:bg-sky-950">SA 200</Badge>
                  <span className="font-semibold">Architecture Design</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Design system architecture, components, and integration patterns
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>High-Level Design (HLD) • Low-Level Design (LLD) • Data Flow • Security • Performance</p>
              </div>
              <div className="flex justify-end">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => {
                    setSaSubView("architecture");
                    toast.success("Opening Architecture Design");
                  }}
                >
                  Configure
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 7: Integration Patterns */}
        <AccordionItem value="step-7" className="border rounded-lg overflow-hidden border-l-4 border-l-rose-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-rose-500/10 flex items-center justify-center shrink-0">
                <Network className="w-6 h-6 text-rose-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-rose-100 dark:bg-rose-950">SA 500</Badge>
                  <span className="font-semibold">Integration Patterns</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Define API strategies, messaging patterns, and system integrations
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define integration approaches, API design, and communication protocols</p>
              </div>
              <div className="flex justify-end">
                <Button size="sm" variant="outline" disabled>
                  Configure
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 8: PaaS CI/CD Deployment */}
        <AccordionItem value="step-8" className="border rounded-lg overflow-hidden border-l-4 border-l-fuchsia-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-fuchsia-500/10 flex items-center justify-center shrink-0">
                <Workflow className="w-6 h-6 text-fuchsia-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-fuchsia-100 dark:bg-fuchsia-950">SA 700</Badge>
                  <span className="font-semibold">Deployment Strategy</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Plan deployment pipelines, environments, and release management
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define CI/CD pipelines, deployment models, and rollback strategies</p>
              </div>
              <div className="flex justify-end">
                <Button size="sm" variant="outline" disabled>
                  Configure
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Step 9: Monitoring & Operations */}
        <AccordionItem value="step-9" className="border rounded-lg overflow-hidden border-l-4 border-l-lime-500">
          <AccordionTrigger className="px-6 hover:no-underline">
            <div className="flex items-center gap-4 w-full">
              <div className="w-12 h-12 rounded-lg bg-lime-500/10 flex items-center justify-center shrink-0">
                <GitBranch className="w-6 h-6 text-lime-500" />
              </div>
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="bg-lime-100 dark:bg-lime-950">SA 800</Badge>
                  <span className="font-semibold">Monitoring & Operations</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Establish monitoring, logging, alerting, and operational procedures
                </p>
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-6 pb-4">
            <div className="pt-4 border-t space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define observability tools, alerting rules, and operational runbooks</p>
              </div>
              <div className="flex justify-end">
                <Button size="sm" variant="outline" disabled>
                  Configure
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}