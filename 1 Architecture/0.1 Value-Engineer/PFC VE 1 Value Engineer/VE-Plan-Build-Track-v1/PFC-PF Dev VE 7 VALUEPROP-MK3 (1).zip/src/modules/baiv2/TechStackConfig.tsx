import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Separator } from "../../components/ui/separator";
import { 
  ArrowLeft, 
  Package,
  Database,
  Server,
  Cloud,
  Shield,
  Lock,
  Key,
  CheckCircle2,
  Circle,
  AlertTriangle,
  Settings,
  Code2,
  Network,
  Globe,
  Eye,
  EyeOff
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { useState } from "react";

interface TechStackConfigProps {
  onBack?: () => void;
}

export function TechStackConfig({ onBack }: TechStackConfigProps) {
  const [showApiKeys, setShowApiKeys] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline">SA 300</Badge>
            <Badge className="bg-emerald-500">Tech Stack and Config</Badge>
          </div>
          <h2 className="text-2xl font-semibold mb-2">Tech Stack and Configuration</h2>
          <p className="text-muted-foreground">
            Technology stack selection, API configuration, and secure access management (Admin-only control)
          </p>
        </div>
        {onBack && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        )}
      </div>

      {/* Admin Access Warning */}
      <Card className="border-l-4 border-l-amber-500 bg-amber-50/50 dark:bg-amber-950/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
            <div className="flex-1">
              <div className="font-semibold text-sm mb-1">Admin-Only Access Control</div>
              <div className="text-sm text-muted-foreground">
                All configuration changes, API key management, and security settings on this page can only be modified by users with <span className="font-semibold text-amber-700 dark:text-amber-400">Admin role</span>. Client, Agency, and Affiliate users have read-only access to approved configurations.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sub-Step Workflow */}
      <div className="space-y-4">
        {/* SA 300.1 - Technology Stack Selection */}
        <Card className="border-l-4 border-l-emerald-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Package className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 300.1</Badge>
                  <CardTitle className="text-lg">Technology Stack Selection</CardTitle>
                  <CardDescription className="mt-1">
                    Define frontend, backend, database, and infrastructure technologies
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  <Lock className="w-3 h-3 mr-1" />
                  Admin Only
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Frontend Stack */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-emerald-600" />
                  Frontend Stack
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">React.js</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">v18.2+ with TypeScript</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Tailwind CSS</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">v4.0 with design tokens</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">shadcn/ui</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Component library</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">React Router</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">v6+ for navigation</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">React Query</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Server state management</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Zustand</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Global state (lightweight)</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Backend Stack */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Server className="w-4 h-4 text-emerald-600" />
                  Backend Stack
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Node.js</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">v20+ LTS runtime</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Express.js</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">RESTful API framework</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">TypeScript</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Type safety backend</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Prisma ORM</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Database abstraction</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">JWT</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Token-based auth</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Zod</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Schema validation</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Database Stack */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  Database & Storage Stack
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">PostgreSQL</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Primary database</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Supabase</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Postgres + Auth + Storage</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Redis</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Caching layer</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Infrastructure Stack */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Cloud className="w-4 h-4 text-emerald-600" />
                  Infrastructure & Hosting
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Vercel</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Frontend hosting + Edge</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">AWS/Azure</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Cloud infrastructure</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">Docker</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground">Containerization</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 300.2 - API Configuration */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Network className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 300.2</Badge>
                  <CardTitle className="text-lg">API Configuration & Access</CardTitle>
                  <CardDescription className="mt-1">
                    Configure internal and external APIs with secure access patterns
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  <Lock className="w-3 h-3 mr-1" />
                  Admin Only
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Internal APIs */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-blue-600" />
                  Internal APIs (Platform)
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Value Proposition API</div>
                        <Badge variant="outline" className="text-xs">v1.0</Badge>
                      </div>
                      <Badge className="bg-green-600 text-xs">Active</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Base URL: <code className="bg-muted px-1 rounded">/api/v1/value-propositions</code></div>
                      <div>• Auth: JWT Bearer Token (Required)</div>
                      <div>• Rate Limit: 1000 requests/hour per user</div>
                      <div>• Access: Admin (Full), Client (Read/Write), Agency (Read), Affiliate (None)</div>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Requirements API</div>
                        <Badge variant="outline" className="text-xs">v1.0</Badge>
                      </div>
                      <Badge className="bg-green-600 text-xs">Active</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Base URL: <code className="bg-muted px-1 rounded">/api/v1/requirements</code></div>
                      <div>• Auth: JWT Bearer Token (Required)</div>
                      <div>• Rate Limit: 500 requests/hour per user</div>
                      <div>• Access: Admin (Full), Client (Read), Agency (Read/Write), Affiliate (None)</div>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">User Management API</div>
                        <Badge variant="outline" className="text-xs">v1.0</Badge>
                      </div>
                      <Badge className="bg-green-600 text-xs">Active</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Base URL: <code className="bg-muted px-1 rounded">/api/v1/users</code></div>
                      <div>• Auth: JWT Bearer Token (Required)</div>
                      <div>• Rate Limit: 200 requests/hour per user</div>
                      <div>• Access: Admin (Full), Client (None), Agency (Read), Affiliate (None)</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* External APIs */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-600" />
                  External API Integrations
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">OpenAI API</div>
                        <Badge variant="outline" className="text-xs">GPT-4</Badge>
                      </div>
                      <Badge className="bg-green-600 text-xs">Configured</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Purpose: AI-powered value proposition analysis</div>
                      <div>• Endpoint: <code className="bg-muted px-1 rounded">https://api.openai.com/v1</code></div>
                      <div>• Key Status: <span className="text-green-600 font-medium">Valid</span> (Admin-only access)</div>
                      <div>• Usage: 50,000 tokens/day limit</div>
                    </div>
                  </div>

                  <div className="p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Stripe API</div>
                        <Badge variant="outline" className="text-xs">Payment</Badge>
                      </div>
                      <Badge className="bg-green-600 text-xs">Configured</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Purpose: Payment processing for subscriptions</div>
                      <div>• Endpoint: <code className="bg-muted px-1 rounded">https://api.stripe.com/v1</code></div>
                      <div>• Key Status: <span className="text-green-600 font-medium">Valid</span> (Admin-only access)</div>
                      <div>• Webhook: Configured for payment events</div>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Salesforce API</div>
                        <Badge variant="outline" className="text-xs">CRM</Badge>
                      </div>
                      <Badge variant="secondary" className="text-xs">Pending</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Purpose: CRM data synchronization</div>
                      <div>• Endpoint: <code className="bg-muted px-1 rounded">https://[instance].salesforce.com</code></div>
                      <div>• Key Status: <span className="text-amber-600 font-medium">Not Configured</span></div>
                      <div>• Action Required: Admin to configure OAuth credentials</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 300.3 - API Security & Access Control */}
        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 300.3</Badge>
                  <CardTitle className="text-lg">API Security & Access Control</CardTitle>
                  <CardDescription className="mt-1">
                    Security policies and access control for API configuration (Admin-only modifications)
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="destructive" className="text-xs">
                  <Lock className="w-3 h-3 mr-1" />
                  Restricted
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Access Control Matrix */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Key className="w-4 h-4 text-red-600" />
                  Configuration Access Control Matrix
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2 bg-muted/50">Configuration Type</th>
                        <th className="text-center p-2 bg-muted/50">Admin</th>
                        <th className="text-center p-2 bg-muted/50">Client</th>
                        <th className="text-center p-2 bg-muted/50">Agency</th>
                        <th className="text-center p-2 bg-muted/50">Affiliate</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="p-2">Tech Stack Selection</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">API Key Management</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">API Endpoints Config</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Security Policies</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Rate Limits</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="secondary" className="text-xs">View</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Database Credentials</td>
                        <td className="text-center p-2"><Badge variant="destructive" className="text-xs">Write</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">None</Badge></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <Separator />

              {/* Security Policies */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-600" />
                  Security Enforcement Policies
                </div>
                <div className="space-y-2">
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800 text-xs">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium">API Key Encryption at Rest</div>
                        <div className="text-muted-foreground">All API keys stored with AES-256 encryption</div>
                      </div>
                    </div>
                  </div>
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800 text-xs">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium">Admin-Only Key Rotation</div>
                        <div className="text-muted-foreground">API keys can only be rotated by Admin users</div>
                      </div>
                    </div>
                  </div>
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800 text-xs">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium">Audit Logging</div>
                        <div className="text-muted-foreground">All configuration changes logged with user, timestamp, and IP</div>
                      </div>
                    </div>
                  </div>
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800 text-xs">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium">2FA Required for Changes</div>
                        <div className="text-muted-foreground">Two-factor authentication required for security-sensitive changes</div>
                      </div>
                    </div>
                  </div>
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800 text-xs">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium">IP Whitelist for Admin Actions</div>
                        <div className="text-muted-foreground">Admin configuration changes restricted to whitelisted IPs</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 300.4 - Environment Configuration */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Settings className="w-5 h-5 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 300.4</Badge>
                  <CardTitle className="text-lg">Environment Configuration</CardTitle>
                  <CardDescription className="mt-1">
                    Development, staging, and production environment settings
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  <Lock className="w-3 h-3 mr-1" />
                  Admin Only
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Environment Configs */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Cloud className="w-4 h-4 text-purple-600" />
                  Environment Configurations
                </div>
                <div className="space-y-3">
                  {/* Production */}
                  <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Production Environment</div>
                        <Badge className="bg-green-600 text-xs">Live</Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 text-xs"
                        onClick={() => {
                          setShowApiKeys(!showApiKeys);
                          toast.info(showApiKeys ? "API keys hidden" : "API keys revealed (Admin only)");
                        }}
                      >
                        {showApiKeys ? <EyeOff className="w-3 h-3 mr-1" /> : <Eye className="w-3 h-3 mr-1" />}
                        {showApiKeys ? "Hide" : "Show"} Keys
                      </Button>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Domain: <code className="bg-muted px-1 rounded">https://app.baiv.com</code></div>
                      <div>• Database: <code className="bg-muted px-1 rounded">prod-db.baiv.internal</code></div>
                      <div>• API Key: <code className="bg-muted px-1 rounded">{showApiKeys ? "pk_prod_abc123xyz789" : "••••••••••••••••"}</code></div>
                      <div>• Status: ✓ Healthy | Uptime: 99.98%</div>
                    </div>
                  </div>

                  {/* Staging */}
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Staging Environment</div>
                        <Badge className="bg-blue-600 text-xs">Testing</Badge>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Domain: <code className="bg-muted px-1 rounded">https://staging.baiv.com</code></div>
                      <div>• Database: <code className="bg-muted px-1 rounded">staging-db.baiv.internal</code></div>
                      <div>• API Key: <code className="bg-muted px-1 rounded">{showApiKeys ? "pk_staging_def456uvw012" : "••••••••••••••••"}</code></div>
                      <div>• Status: ✓ Healthy | Last Deploy: 2 hours ago</div>
                    </div>
                  </div>

                  {/* Development */}
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-xs">Development Environment</div>
                        <Badge className="bg-amber-600 text-xs">Local</Badge>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>• Domain: <code className="bg-muted px-1 rounded">http://localhost:3000</code></div>
                      <div>• Database: <code className="bg-muted px-1 rounded">localhost:5432</code></div>
                      <div>• API Key: <code className="bg-muted px-1 rounded">{showApiKeys ? "pk_dev_ghi789rst345" : "••••••••••••••••"}</code></div>
                      <div>• Status: ✓ Running | Mock data enabled</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Environment Variables */}
              <div className="text-sm">
                <div className="font-medium mb-2">Key Environment Variables (Admin Access Only)</div>
                <div className="p-3 bg-muted/30 rounded-lg font-mono text-xs space-y-1">
                  <div className="text-muted-foreground"># Database</div>
                  <div>DATABASE_URL={showApiKeys ? "postgresql://user:pass@host:5432/baiv_prod" : "••••••••••••••••"}</div>
                  <div className="text-muted-foreground pt-2"># External APIs</div>
                  <div>OPENAI_API_KEY={showApiKeys ? "sk-proj-abc123..." : "••••••••••••••••"}</div>
                  <div>STRIPE_SECRET_KEY={showApiKeys ? "sk_live_xyz789..." : "••••••••••••••••"}</div>
                  <div className="text-muted-foreground pt-2"># Authentication</div>
                  <div>JWT_SECRET={showApiKeys ? "super_secret_jwt_key_2024" : "••••••••••••••••"}</div>
                  <div>SESSION_SECRET={showApiKeys ? "session_secret_key_abc" : "••••••••••••••••"}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 300.5 - Configuration Audit Trail */}
        <Card className="border-l-4 border-l-slate-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-slate-500/10 flex items-center justify-center">
                  <Database className="w-5 h-5 text-slate-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 300.5</Badge>
                  <CardTitle className="text-lg">Configuration Audit Trail</CardTitle>
                  <CardDescription className="mt-1">
                    Complete history of all configuration changes (Admin view only)
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Recent Configuration Changes</div>
                <div className="space-y-2">
                  <div className="p-2 bg-muted/50 rounded border text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-medium">OpenAI API Key Updated</div>
                      <Badge variant="outline" className="text-xs">2 days ago</Badge>
                    </div>
                    <div className="text-muted-foreground">
                      <div>• User: admin@baiv.com</div>
                      <div>• Action: Rotated API key for security compliance</div>
                      <div>• IP: 203.0.113.45</div>
                    </div>
                  </div>

                  <div className="p-2 bg-muted/50 rounded border text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-medium">Rate Limit Adjusted</div>
                      <Badge variant="outline" className="text-xs">5 days ago</Badge>
                    </div>
                    <div className="text-muted-foreground">
                      <div>• User: admin@baiv.com</div>
                      <div>• Action: Increased VP API rate limit from 500 to 1000 req/hr</div>
                      <div>• IP: 203.0.113.45</div>
                    </div>
                  </div>

                  <div className="p-2 bg-muted/50 rounded border text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-medium">Database Credentials Rotated</div>
                      <Badge variant="outline" className="text-xs">1 week ago</Badge>
                    </div>
                    <div className="text-muted-foreground">
                      <div>• User: admin@baiv.com</div>
                      <div>• Action: Monthly security rotation of production DB password</div>
                      <div>• IP: 203.0.113.45</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
