import { ArrowLeft, Database, Network, Share2, Table, FileJson, Lock, BarChart3 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { toast } from "sonner@2.0.3";

interface DataArchitectProps {
  onBack: () => void;
}

export function DataArchitect({ onBack }: DataArchitectProps) {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Data Architect Process</h2>
            <p className="text-muted-foreground">
              Design ontologies, database schemas, and API integrations
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        </div>
      </div>

      {/* Data Architect Process Steps */}
      <div className="space-y-4">
        {/* DA 100 - Analysis Analytics and Reporting */}
        <Card className="border-l-4 border-l-sky-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-sky-500/10 flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-sky-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 100</Badge>
                  <CardTitle>Analysis Analytics and Reporting</CardTitle>
                  <CardDescription className="mt-1">
                    Define comprehensive data analysis, analytics frameworks, and reporting strategies
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define analysis methodologies, analytics frameworks, and reporting architectures</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 200 - Ontology Design */}
        <Card className="border-l-4 border-l-violet-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <Share2 className="w-6 h-6 text-violet-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 200</Badge>
                  <CardTitle>Ontology Design & Management</CardTitle>
                  <CardDescription className="mt-1">
                    Define domain ontologies, taxonomies, and knowledge graphs
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define ontology structures, relationships, and semantic models</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 300 - Database Architecture */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Database className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 300</Badge>
                  <CardTitle>Database Architecture & Schema Design</CardTitle>
                  <CardDescription className="mt-1">
                    Design database schemas, relationships, and data models
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define tables, indexes, constraints, and normalization strategies</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 400 - API Integration Architecture */}
        <Card className="border-l-4 border-l-emerald-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Network className="w-6 h-6 text-emerald-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 400</Badge>
                  <CardTitle>API Integration Architecture</CardTitle>
                  <CardDescription className="mt-1">
                    Design API contracts, integration patterns, and data flows
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define API specifications, integration middleware, and data transformation</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 500 - Data Modeling */}
        <Card className="border-l-4 border-l-cyan-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <Table className="w-6 h-6 text-cyan-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 500</Badge>
                  <CardTitle>Data Modeling & ERD</CardTitle>
                  <CardDescription className="mt-1">
                    Create entity-relationship diagrams and data flow models
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define entities, attributes, cardinality, and relationships</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 600 - Data Governance */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Lock className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 600</Badge>
                  <CardTitle>Data Governance & Security</CardTitle>
                  <CardDescription className="mt-1">
                    Define data policies, access controls, and compliance frameworks
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define data classification, retention policies, and audit requirements</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 700 - Data Quality & Validation */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <FileJson className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 700</Badge>
                  <CardTitle>Data Quality & Validation</CardTitle>
                  <CardDescription className="mt-1">
                    Implement data validation rules and quality assurance processes
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define validation schemas, data quality metrics, and cleansing procedures</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* DA 800 - Analytics & Business Intelligence */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">DA 800</Badge>
                  <CardTitle>Analytics & Business Intelligence</CardTitle>
                  <CardDescription className="mt-1">
                    Design analytics architecture, BI dashboards, and data-driven insights
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define analytics pipelines, reporting frameworks, and BI visualization strategies</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}