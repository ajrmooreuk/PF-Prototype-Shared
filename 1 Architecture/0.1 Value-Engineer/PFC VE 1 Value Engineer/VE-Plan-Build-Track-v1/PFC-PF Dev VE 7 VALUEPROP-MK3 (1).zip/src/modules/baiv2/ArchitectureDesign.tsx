import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Separator } from "../../components/ui/separator";
import { 
  ArrowLeft, 
  Layout,
  Layers,
  Network,
  Database,
  Server,
  Cloud,
  Shield,
  Zap,
  CheckCircle2,
  Circle,
  GitBranch,
  Box
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ArchitectureDesignProps {
  onBack?: () => void;
}

export function ArchitectureDesign({ onBack }: ArchitectureDesignProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline">SA 200</Badge>
            <Badge className="bg-sky-500">Architecture Design</Badge>
          </div>
          <h2 className="text-2xl font-semibold mb-2">Architecture Design Workflow</h2>
          <p className="text-muted-foreground">
            High-Level Design (HLD) and Detailed Low-Level Design (LLD) for BAIV platform
          </p>
        </div>
        {onBack && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        )}
      </div>

      {/* Sub-Step Workflow */}
      <div className="space-y-4">
        {/* SA 200.1 - High-Level Design (HLD) */}
        <Card className="border-l-4 border-l-sky-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-sky-500/10 flex items-center justify-center">
                  <Layout className="w-5 h-5 text-sky-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 200.1</Badge>
                  <CardTitle className="text-lg">High-Level Design (HLD)</CardTitle>
                  <CardDescription className="mt-1">
                    System architecture overview and component interaction
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* System Architecture */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Layout className="w-4 h-4 text-sky-600" />
                  System Architecture Layers
                </div>
                <div className="space-y-2">
                  {/* Presentation Layer */}
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="font-medium text-xs mb-1 flex items-center gap-2">
                      <Box className="w-3 h-3" />
                      Presentation Layer (Frontend)
                    </div>
                    <div className="text-xs text-muted-foreground pl-5 space-y-0.5">
                      <div>• React.js with TypeScript</div>
                      <div>• Tailwind CSS + shadcn/ui components</div>
                      <div>• State management (React Context/Zustand)</div>
                      <div>• Responsive design (mobile-first)</div>
                    </div>
                  </div>

                  {/* Application Layer */}
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-950/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                    <div className="font-medium text-xs mb-1 flex items-center gap-2">
                      <Server className="w-3 h-3" />
                      Application Layer (Backend)
                    </div>
                    <div className="text-xs text-muted-foreground pl-5 space-y-0.5">
                      <div>• Node.js + Express.js / Next.js API Routes</div>
                      <div>• RESTful API architecture</div>
                      <div>• Business logic & validation</div>
                      <div>• Authentication & Authorization (JWT)</div>
                    </div>
                  </div>

                  {/* Data Layer */}
                  <div className="p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <div className="font-medium text-xs mb-1 flex items-center gap-2">
                      <Database className="w-3 h-3" />
                      Data Layer (Persistence)
                    </div>
                    <div className="text-xs text-muted-foreground pl-5 space-y-0.5">
                      <div>• PostgreSQL (Relational data)</div>
                      <div>• Redis (Caching & sessions)</div>
                      <div>• S3 (File storage)</div>
                      <div>• Supabase (Backend-as-a-Service)</div>
                    </div>
                  </div>

                  {/* Infrastructure Layer */}
                  <div className="p-3 bg-violet-50 dark:bg-violet-950/20 rounded-lg border border-violet-200 dark:border-violet-800">
                    <div className="font-medium text-xs mb-1 flex items-center gap-2">
                      <Cloud className="w-3 h-3" />
                      Infrastructure Layer (Cloud)
                    </div>
                    <div className="text-xs text-muted-foreground pl-5 space-y-0.5">
                      <div>• Vercel / AWS / Azure hosting</div>
                      <div>• CDN for static assets</div>
                      <div>• Load balancing & auto-scaling</div>
                      <div>• Monitoring & logging (Datadog/New Relic)</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Component Diagram */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-sky-600" />
                  Major Components & Modules
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Authentication Module</div>
                    <div className="text-muted-foreground">User login, RBAC</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Value Prop Module</div>
                    <div className="text-muted-foreground">VP Wizard, Canvas</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">VE Process Module</div>
                    <div className="text-muted-foreground">8-step workflow</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">SA Module</div>
                    <div className="text-muted-foreground">Requirements, Design</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">CE Module</div>
                    <div className="text-muted-foreground">Context definition</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Analytics Module</div>
                    <div className="text-muted-foreground">Metrics, reporting</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Integration Patterns */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Network className="w-4 h-4 text-sky-600" />
                  Integration Patterns
                </div>
                <div className="space-y-1.5 text-xs pl-6">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-600 mt-0.5" />
                    <div><span className="font-medium">Microservices:</span> Modular services for VE, SA, CE</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-600 mt-0.5" />
                    <div><span className="font-medium">API Gateway:</span> Single entry point for all services</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-600 mt-0.5" />
                    <div><span className="font-medium">Event-Driven:</span> Async processing via message queues</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-600 mt-0.5" />
                    <div><span className="font-medium">Webhooks:</span> Real-time notifications to external systems</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 200.2 - Low-Level Design (LLD) */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Layers className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 200.2</Badge>
                  <CardTitle className="text-lg">Low-Level Design (LLD)</CardTitle>
                  <CardDescription className="mt-1">
                    Detailed component design, classes, and interfaces
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Class Structure */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-blue-600" />
                  Class Structure (Example: Value Proposition Module)
                </div>
                <div className="p-3 bg-muted/30 rounded-lg font-mono text-xs space-y-2">
                  <div className="text-blue-600">// Core Classes</div>
                  <div>class <span className="text-emerald-600 font-semibold">ValueProposition</span> {`{`}</div>
                  <div className="pl-4 space-y-0.5">
                    <div>id: string;</div>
                    <div>name: string;</div>
                    <div>organizationId: string;</div>
                    <div>customerSegments: CustomerSegment[];</div>
                    <div>products: Product[];</div>
                    <div>painRelievers: PainReliever[];</div>
                    <div>gainCreators: GainCreator[];</div>
                    <div>valueMetrics: ValueMetric[];</div>
                  </div>
                  <div>{`}`}</div>
                  
                  <div className="pt-2">class <span className="text-emerald-600 font-semibold">CustomerSegment</span> {`{`}</div>
                  <div className="pl-4 space-y-0.5">
                    <div>id: string;</div>
                    <div>name: string;</div>
                    <div>jobs: Job[];</div>
                    <div>pains: Pain[];</div>
                    <div>gains: Gain[];</div>
                  </div>
                  <div>{`}`}</div>
                </div>
              </div>

              <Separator />

              {/* Database Schema Detail */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-600" />
                  Database Schema (Detailed)
                </div>
                <div className="space-y-2">
                  {/* Organizations Table */}
                  <div className="p-2 bg-muted/50 rounded">
                    <div className="font-medium text-xs mb-1">organizations</div>
                    <div className="grid grid-cols-3 gap-1 text-xs text-muted-foreground">
                      <div>id (UUID, PK)</div>
                      <div>name (VARCHAR)</div>
                      <div>created_at (TIMESTAMP)</div>
                      <div>instance_id (UUID, FK)</div>
                      <div>status (ENUM)</div>
                      <div>updated_at (TIMESTAMP)</div>
                    </div>
                  </div>

                  {/* Value Propositions Table */}
                  <div className="p-2 bg-muted/50 rounded">
                    <div className="font-medium text-xs mb-1">value_propositions</div>
                    <div className="grid grid-cols-3 gap-1 text-xs text-muted-foreground">
                      <div>id (UUID, PK)</div>
                      <div>name (VARCHAR)</div>
                      <div>organization_id (UUID, FK)</div>
                      <div>strategy_id (UUID, FK)</div>
                      <div>brand_id (UUID, FK)</div>
                      <div>pricing_tier_id (UUID, FK)</div>
                      <div>status (ENUM)</div>
                      <div>created_by (UUID, FK)</div>
                      <div>created_at (TIMESTAMP)</div>
                    </div>
                  </div>

                  {/* Customer Segments Table */}
                  <div className="p-2 bg-muted/50 rounded">
                    <div className="font-medium text-xs mb-1">customer_segments</div>
                    <div className="grid grid-cols-3 gap-1 text-xs text-muted-foreground">
                      <div>id (UUID, PK)</div>
                      <div>vp_id (UUID, FK)</div>
                      <div>name (VARCHAR)</div>
                      <div>description (TEXT)</div>
                      <div>jobs_data (JSONB)</div>
                      <div>pains_data (JSONB)</div>
                      <div>gains_data (JSONB)</div>
                      <div>created_at (TIMESTAMP)</div>
                      <div>updated_at (TIMESTAMP)</div>
                    </div>
                  </div>

                  {/* Users & Roles Table */}
                  <div className="p-2 bg-muted/50 rounded">
                    <div className="font-medium text-xs mb-1">users & user_roles</div>
                    <div className="grid grid-cols-3 gap-1 text-xs text-muted-foreground">
                      <div>users.id (UUID, PK)</div>
                      <div>users.email (VARCHAR)</div>
                      <div>users.org_id (UUID, FK)</div>
                      <div>user_roles.user_id (FK)</div>
                      <div>user_roles.role (ENUM)</div>
                      <div>user_roles.permissions (JSONB)</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* API Endpoints */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Network className="w-4 h-4 text-blue-600" />
                  API Endpoints (RESTful Design)
                </div>
                <div className="space-y-1.5 font-mono text-xs">
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border-l-2 border-green-500">
                    <span className="text-green-600 font-semibold">POST</span> /api/v1/value-propositions
                  </div>
                  <div className="p-2 bg-blue-50 dark:bg-blue-950/20 rounded border-l-2 border-blue-500">
                    <span className="text-blue-600 font-semibold">GET</span> /api/v1/value-propositions/:id
                  </div>
                  <div className="p-2 bg-amber-50 dark:bg-amber-950/20 rounded border-l-2 border-amber-500">
                    <span className="text-amber-600 font-semibold">PUT</span> /api/v1/value-propositions/:id
                  </div>
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border-l-2 border-red-500">
                    <span className="text-red-600 font-semibold">DELETE</span> /api/v1/value-propositions/:id
                  </div>
                  <div className="p-2 bg-blue-50 dark:bg-blue-950/20 rounded border-l-2 border-blue-500">
                    <span className="text-blue-600 font-semibold">GET</span> /api/v1/organizations/:id/value-propositions
                  </div>
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border-l-2 border-green-500">
                    <span className="text-green-600 font-semibold">POST</span> /api/v1/value-propositions/:id/convert-to-prd
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 200.3 - Data Flow Design */}
        <Card className="border-l-4 border-l-indigo-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                  <GitBranch className="w-5 h-5 text-indigo-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 200.3</Badge>
                  <CardTitle className="text-lg">Data Flow & State Management</CardTitle>
                  <CardDescription className="mt-1">
                    Data flow patterns and state management architecture
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Data Flow */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-indigo-600" />
                  Value Proposition Creation Flow
                </div>
                <div className="space-y-2 pl-6">
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">1</div>
                    <div className="flex-1">
                      <div className="font-medium">User Input (Frontend)</div>
                      <div className="text-muted-foreground">User fills VP wizard form</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">2</div>
                    <div className="flex-1">
                      <div className="font-medium">Validation (Client-side)</div>
                      <div className="text-muted-foreground">Form validation & error handling</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">3</div>
                    <div className="flex-1">
                      <div className="font-medium">API Request (POST)</div>
                      <div className="text-muted-foreground">Send data to backend API</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">4</div>
                    <div className="flex-1">
                      <div className="font-medium">Business Logic (Backend)</div>
                      <div className="text-muted-foreground">Process, validate, transform data</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">5</div>
                    <div className="flex-1">
                      <div className="font-medium">Database Write</div>
                      <div className="text-muted-foreground">Persist to PostgreSQL/Supabase</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">6</div>
                    <div className="flex-1">
                      <div className="font-medium">Response (JSON)</div>
                      <div className="text-muted-foreground">Return created resource with ID</div>
                    </div>
                  </div>
                  <div className="ml-3 border-l-2 border-indigo-300 h-4"></div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 text-white flex items-center justify-center font-semibold">7</div>
                    <div className="flex-1">
                      <div className="font-medium">State Update (Frontend)</div>
                      <div className="text-muted-foreground">Update UI & show success toast</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* State Management */}
              <div className="text-sm">
                <div className="font-medium mb-2">State Management Pattern</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Local State</div>
                    <div className="text-muted-foreground">
                      <div>• React useState</div>
                      <div>• Form inputs, UI state</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Global State</div>
                    <div className="text-muted-foreground">
                      <div>• Context API / Zustand</div>
                      <div>• User auth, app settings</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Server State</div>
                    <div className="text-muted-foreground">
                      <div>• React Query / SWR</div>
                      <div>• API data caching</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">URL State</div>
                    <div className="text-muted-foreground">
                      <div>• React Router</div>
                      <div>• Navigation, params</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 200.4 - Security Architecture */}
        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 200.4</Badge>
                  <CardTitle className="text-lg">Security Architecture</CardTitle>
                  <CardDescription className="mt-1">
                    Authentication, authorization, and security patterns
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Security Layers */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-600" />
                  Security Layers
                </div>
                <div className="space-y-2">
                  <div className="p-2 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800">
                    <div className="font-medium text-xs mb-1">Authentication</div>
                    <div className="text-xs text-muted-foreground pl-3">
                      <div>• JWT-based authentication</div>
                      <div>• Session management with HTTP-only cookies</div>
                      <div>• OAuth 2.0 / SSO integration</div>
                      <div>• Multi-factor authentication (MFA)</div>
                    </div>
                  </div>
                  
                  <div className="p-2 bg-orange-50 dark:bg-orange-950/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="font-medium text-xs mb-1">Authorization (RBAC)</div>
                    <div className="text-xs text-muted-foreground pl-3">
                      <div>• Role-based access control</div>
                      <div>• Permission middleware on API routes</div>
                      <div>• Resource-level permissions</div>
                      <div>• Admin, Client, Agency, Affiliate roles</div>
                    </div>
                  </div>

                  <div className="p-2 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800">
                    <div className="font-medium text-xs mb-1">Data Protection</div>
                    <div className="text-xs text-muted-foreground pl-3">
                      <div>• Encryption at rest (AES-256)</div>
                      <div>• Encryption in transit (TLS 1.3)</div>
                      <div>• Secure password hashing (bcrypt)</div>
                      <div>• PII data masking</div>
                    </div>
                  </div>

                  <div className="p-2 bg-yellow-50 dark:bg-yellow-950/20 rounded border border-yellow-200 dark:border-yellow-800">
                    <div className="font-medium text-xs mb-1">API Security</div>
                    <div className="text-xs text-muted-foreground pl-3">
                      <div>• Rate limiting (per IP/user)</div>
                      <div>• CORS configuration</div>
                      <div>• Input validation & sanitization</div>
                      <div>• SQL injection prevention (ORM)</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 200.5 - Performance Architecture */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 200.5</Badge>
                  <CardTitle className="text-lg">Performance & Scalability</CardTitle>
                  <CardDescription className="mt-1">
                    Optimization strategies and scalability patterns
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Performance Strategies */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-green-600" />
                  Performance Optimization
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800 text-xs">
                    <div className="font-medium mb-1">Frontend</div>
                    <div className="text-muted-foreground space-y-0.5">
                      <div>• Code splitting & lazy loading</div>
                      <div>• Image optimization (WebP)</div>
                      <div>• Bundle size optimization</div>
                      <div>• Browser caching</div>
                    </div>
                  </div>
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800 text-xs">
                    <div className="font-medium mb-1">Backend</div>
                    <div className="text-muted-foreground space-y-0.5">
                      <div>• Database query optimization</div>
                      <div>• Redis caching layer</div>
                      <div>• API response compression</div>
                      <div>• Database indexing</div>
                    </div>
                  </div>
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800 text-xs">
                    <div className="font-medium mb-1">Database</div>
                    <div className="text-muted-foreground space-y-0.5">
                      <div>• Connection pooling</div>
                      <div>• Read replicas</div>
                      <div>• Partitioning/sharding</div>
                      <div>• Query result caching</div>
                    </div>
                  </div>
                  <div className="p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800 text-xs">
                    <div className="font-medium mb-1">Infrastructure</div>
                    <div className="text-muted-foreground space-y-0.5">
                      <div>• CDN for static assets</div>
                      <div>• Load balancing</div>
                      <div>• Auto-scaling groups</div>
                      <div>• Edge computing</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Scalability Pattern */}
              <div className="text-sm">
                <div className="font-medium mb-2">Scalability Targets</div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="p-2 bg-muted/50 rounded text-center">
                    <div className="text-2xl font-bold text-green-600">10K+</div>
                    <div className="text-muted-foreground">Concurrent Users</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-center">
                    <div className="text-2xl font-bold text-green-600">&lt;2s</div>
                    <div className="text-muted-foreground">Page Load Time</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-center">
                    <div className="text-2xl font-bold text-green-600">99.9%</div>
                    <div className="text-muted-foreground">Uptime SLA</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
