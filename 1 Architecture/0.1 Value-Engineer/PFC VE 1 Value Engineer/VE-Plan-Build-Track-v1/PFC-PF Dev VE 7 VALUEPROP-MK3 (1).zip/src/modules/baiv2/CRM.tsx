import { Button } from "../../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Users, Target, TrendingUp, Mail, MessageSquare, Phone, CheckCircle2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface CRMProps {
  onBack?: () => void;
}

export function CRM({ onBack }: CRMProps) {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">CRM - Customer Relationship Management</h2>
            <p className="text-muted-foreground">
              Drive agentic targeting, lead conversion to sign-ups, and achieve Product-Market Fit
            </p>
          </div>
          {onBack && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                onBack();
                toast.success("Returned to PF Dashboard");
              }}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to PF Dashboard
            </Button>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {/* Lead Generation & Targeting */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Target className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Lead Generation</Badge>
                  <CardTitle>Agentic Lead Targeting</CardTitle>
                  <CardDescription className="mt-1">
                    AI-powered lead identification, segmentation, and targeting strategies
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Key Capabilities</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>AI-powered lead scoring</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Behavioral segmentation</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Intent signal detection</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Personalized outreach</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Conversion Optimization */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Conversion</Badge>
                  <CardTitle>Lead to Sign-Up Conversion</CardTitle>
                  <CardDescription className="mt-1">
                    Optimize conversion funnels and accelerate lead-to-customer journey
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Conversion Features</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>A/B testing & optimization</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Funnel analytics</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Automated nurturing</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Conversion tracking</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Engagement Channels */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">Engagement</Badge>
                  <CardTitle>Multi-Channel Engagement</CardTitle>
                  <CardDescription className="mt-1">
                    Orchestrate customer engagement across email, chat, phone, and social
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">Engagement Channels</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <Mail className="w-4 h-4" />
                    <span>Email campaigns</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <MessageSquare className="w-4 h-4" />
                    <span>Live chat</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <Phone className="w-4 h-4" />
                    <span>Phone outreach</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Product-Market Fit */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">PMF Achievement</Badge>
                  <CardTitle>Product-Market Fit Analytics</CardTitle>
                  <CardDescription className="mt-1">
                    Monitor and optimize metrics to achieve sustainable Product-Market Fit
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">PMF Indicators</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>NPS Score</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>CAC/LTV Ratio</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Retention Rate</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Growth Rate</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded">
          <p>
            <strong>Sign-up Feature:</strong> The CRM module enables agentic targeting and lead conversion workflows to systematically move prospects through the funnel towards sign-up, optimizing for Product-Market Fit through data-driven engagement strategies.
          </p>
        </div>
      </div>
    </div>
  );
}
