import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { PricingCard } from "./PricingCard";
import { PlatformDashboard } from "./PlatformDashboard";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Separator } from "../../components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { Label } from "../../components/ui/label";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Building2, Users, Briefcase, Award, LogOut, UserCog, CheckCircle2, Circle, Target, TrendingUp, Shield, Package, Sparkles, Settings, Layout, Layers, GitBranch, Database, Workflow, Code2, Network, ArrowLeft, FileText, Eye, DollarSign, Lightbulb, BarChart3, X, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { toast } from "sonner@2.0.3";
import type { PricingTier, Platform, DashboardMetric } from "./types";
import { AppBreadcrumb } from "../../components/AppBreadcrumb";
import { RequirementsDiscovery } from "./RequirementsDiscovery";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "../../components/ui/accordion";
import { ArchitectureDesign } from "./ArchitectureDesign";
import { TechStackConfig } from "./TechStackConfig";
import { AgentArchitect } from "./AgentArchitect";
import { DataArchitect } from "./DataArchitect";
import { ProductBAIV } from "./ProductBAIV";
import { DesignUIUX } from "./DesignUIUX";
import { CRM } from "./CRM";
import { ProductManager } from "./ProductManager";
import { SolutionArchitectAccordion } from "./SolutionArchitectAccordion";

const mockPricingTiers: PricingTier[] = [
  {
    id: "starter",
    name: "Starter",
    price: 29,
    description: "Perfect for small teams",
    features: [
      "Up to 10 users",
      "Basic analytics",
      "Email support",
      "1GB storage",
    ],
  },
  {
    id: "professional",
    name: "Professional",
    price: 99,
    description: "For growing businesses",
    features: [
      "Up to 50 users",
      "Advanced analytics",
      "Priority support",
      "10GB storage",
      "Custom integrations",
      "API access",
    ],
    recommended: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 299,
    description: "For large organizations",
    features: [
      "Unlimited users",
      "Enterprise analytics",
      "24/7 dedicated support",
      "Unlimited storage",
      "Custom integrations",
      "API access",
      "SLA guarantee",
      "White-label options",
    ],
  },
];

const mockPlatforms: Platform[] = [
  {
    id: "baiv",
    name: "BAIV Platform",
    description: "Business AI Visibility Platform",
    status: "active",
    metrics: {
      users: 1250,
      revenue: 45000,
      growth: 23,
    },
    products: [
      {
        id: "baiv-visibility",
        name: "AI Visibility",
        description: "AI-powered visibility and analytics for business intelligence",
        status: "active",
        category: "AI",
      },
      {
        id: "baiv-agency",
        name: "AIV Agency",
        description: "Agency-focused AI visibility solutions and tools",
        status: "active",
        category: "Agency",
      },
      {
        id: "baiv-enterprise",
        name: "AIV Enterprise",
        description: "Enterprise-grade AI visibility platform with advanced features",
        status: "active",
        category: "Enterprise",
      },
    ],
  },
  {
    id: "pf-core",
    name: "PF Core",
    description: "Platform Foundation & Core Services",
    status: "active",
    metrics: {
      users: 2100,
      revenue: 58000,
      growth: 28,
    },
    products: [
      {
        id: "pf-ve",
        name: "Value Engineering Suite",
        description: "Complete value engineering workflow and methodology",
        status: "active",
        category: "Core",
      },
      {
        id: "pf-sa",
        name: "Solution Architect Module",
        description: "Architecture design and implementation toolkit",
        status: "active",
        category: "Core",
      },
      {
        id: "pf-ai",
        name: "AI Assistant",
        description: "Intelligent guidance and recommendations",
        status: "beta",
        category: "AI",
      },
      {
        id: "pf-analytics",
        name: "Analytics Dashboard",
        description: "Real-time metrics and performance tracking",
        status: "active",
        category: "Analytics",
      },
      {
        id: "pf-auth",
        name: "Authentication & Authorization",
        description: "Secure identity and access management",
        status: "active",
        category: "Security",
      },
      {
        id: "pf-api",
        name: "API Gateway",
        description: "Unified API management and routing",
        status: "active",
        category: "Infrastructure",
      },
      {
        id: "pf-storage",
        name: "Data Storage",
        description: "Scalable storage solutions",
        status: "active",
        category: "Infrastructure",
      },
      {
        id: "pf-monitoring",
        name: "Platform Monitoring",
        description: "Real-time system health and performance monitoring",
        status: "active",
        category: "Operations",
      },
    ],
  },
  {
    id: "w4m",
    name: "W4M Platform",
    description: "Workflow Management System",
    status: "active",
    metrics: {
      users: 850,
      revenue: 32000,
      growth: 18,
    },
    products: [
      {
        id: "w4m-workflow",
        name: "Workflow Engine",
        description: "Process automation and orchestration",
        status: "active",
        category: "Core",
      },
      {
        id: "w4m-tasks",
        name: "Task Management",
        description: "Task tracking and assignment",
        status: "active",
        category: "Productivity",
      },
    ],
  },
];

const mockMetrics: DashboardMetric[] = [
  {
    label: "Total Users",
    value: "4,200",
    change: 22,
    trend: "up",
  },
  {
    label: "Revenue",
    value: "$135,000",
    change: 18,
    trend: "up",
  },
  {
    label: "Active Sessions",
    value: "2,847",
    change: 15,
    trend: "up",
  },
];

interface Baiv2AppProps {
  activeTab: "admin" | "agency" | "direct" | "affiliate";
  defaultTabView?: string;
  onLaunchValueProp?: () => void;
}

export function Baiv2App({ activeTab, defaultTabView = "dashboard", onLaunchValueProp }: Baiv2AppProps) {
  const [selectedTier, setSelectedTier] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState("admin@baiv2.com");
  const [currentView, setCurrentView] = useState(defaultTabView);
  const [saSubView, setSaSubView] = useState<string | null>(null); // "requirements", "architecture", "techstack", "design-uiux", "agent-architect", or "data-architect"
  const [veCurrentStep, setVeCurrentStep] = useState(1); // Value Engineer current step (1-7)
  const [rbacPerspective, setRbacPerspective] = useState<string>("customer"); // RBAC perspective tab state
  
  // VSOM Configuration State
  const [showVSOMDialog, setShowVSOMDialog] = useState(false);
  const [vsomConfig, setVsomConfig] = useState({
    // Vision
    vision: {
      statement: "Revolutionize AI visibility and marketing analytics for professional services",
      longTerm: "Become the leading AI-powered platform for marketing intelligence and advertising optimization",
      values: ["Innovation", "Transparency", "Customer Success", "Data-Driven Excellence"],
    },
    // Strategy (4 Balanced Scorecard Perspectives for BAIV)
    strategy: {
      financial: {
        perspective: "Financial Excellence",
        goals: [
          "Achieve 100% YoY revenue growth",
          "Maintain 70%+ gross margins",
          "Reduce CAC by 30% through AI optimization",
          "Expand MRR to $10M by 2026"
        ],
        initiatives: ["Pricing optimization", "Upsell automation", "Cost management AI"]
      },
      customer: {
        perspective: "Customer Success & Value",
        goals: [
          "Achieve 90%+ customer satisfaction (NPS 50+)",
          "Reduce time-to-value to <14 days",
          "Increase adoption rate to 85%+",
          "Build community of 10k+ active users"
        ],
        initiatives: ["AI-powered onboarding", "Customer success AI assistant", "Value tracking dashboard"]
      },
      internal: {
        perspective: "Internal Process & Operations",
        goals: [
          "Automate 80% of visibility reporting",
          "Deploy AI models in <48 hours",
          "Achieve 99.9% platform uptime",
          "Process 10M+ data points daily"
        ],
        initiatives: ["ML pipeline automation", "Real-time analytics engine", "Infrastructure scaling"]
      },
      learning: {
        perspective: "Learning & Growth",
        goals: [
          "Train team on latest AI/ML techniques",
          "Build proprietary AI visibility models",
          "Achieve ISO 27001 certification",
          "Develop 5+ AI patents"
        ],
        initiatives: ["Continuous learning program", "R&D investment", "Innovation labs"]
      }
    },
    // Objectives (OKRs)
    objectives: [
      {
        objective: "Dominate AI Visibility Market",
        keyResults: [
          "Capture 25% market share in professional services advertising",
          "Sign 100+ enterprise clients",
          "Launch in 5 new verticals"
        ],
        perspective: "Customer"
      },
      {
        objective: "Build Best-in-Class AI Platform",
        keyResults: [
          "Deploy 15+ AI models for visibility optimization",
          "Achieve 95%+ prediction accuracy",
          "Process data 10x faster than competitors"
        ],
        perspective: "Internal"
      },
      {
        objective: "Achieve Sustainable Growth",
        keyResults: [
          "Reach $50M ARR",
          "Maintain 120%+ NDR",
          "Achieve profitability by Q4 2025"
        ],
        perspective: "Financial"
      },
      {
        objective: "Cultivate Innovation Culture",
        keyResults: [
          "Launch 3 major AI innovations",
          "Publish 10+ research papers",
          "Win 2+ industry awards"
        ],
        perspective: "Learning"
      }
    ],
    // Metrics & KPIs
    metrics: {
      financial: [
        { name: "ARR", target: "$50M", current: "$12M", unit: "USD" },
        { name: "MRR Growth", target: "15%", current: "12%", unit: "%" },
        { name: "Gross Margin", target: "70%", current: "68%", unit: "%" },
        { name: "CAC Payback", target: "6 mo", current: "8 mo", unit: "months" },
        { name: "LTV:CAC", target: "5:1", current: "4:1", unit: "ratio" }
      ],
      customer: [
        { name: "NPS", target: "50", current: "42", unit: "score" },
        { name: "CSAT", target: "90%", current: "85%", unit: "%" },
        { name: "Retention", target: "95%", current: "92%", unit: "%" },
        { name: "Time to Value", target: "14 days", current: "21 days", unit: "days" },
        { name: "Active Users", target: "10k", current: "6.5k", unit: "users" }
      ],
      internal: [
        { name: "Platform Uptime", target: "99.9%", current: "99.7%", unit: "%" },
        { name: "API Latency", target: "<100ms", current: "145ms", unit: "ms" },
        { name: "Data Processing", target: "10M/day", current: "7M/day", unit: "points" },
        { name: "Model Accuracy", target: "95%", current: "92%", unit: "%" },
        { name: "Deployment Speed", target: "48h", current: "72h", unit: "hours" }
      ],
      learning: [
        { name: "Training Hours", target: "40h/qtr", current: "28h/qtr", unit: "hours" },
        { name: "AI Models Deployed", target: "15", current: "9", unit: "models" },
        { name: "Patents Filed", target: "5", current: "2", unit: "patents" },
        { name: "Research Papers", target: "10", current: "4", unit: "papers" },
        { name: "Certifications", target: "3", current: "1", unit: "certs" }
      ]
    }
  });

  // RBAC (Role-Based Access Control) Data
  const rbacPermissions = {
    customer: {
      title: "Customer Perspective",
      description: "Permissions for customer-facing metrics and features",
      icon: Users,
      color: "#00a4bf",
      capabilities: [
        {
          capability: "View Metrics Dashboard",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Export Customer Reports",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Customer Preferences",
          admin: true,
          client: true,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Access Historical Data",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Submit Feedback/Support Tickets",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "View Satisfaction Scores",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Configure Alerts/Notifications",
          admin: true,
          client: true,
          agency: false,
          affiliates: false,
        },
      ],
    },
    internal: {
      title: "Internal Process Perspective",
      description: "Permissions for internal operations and processes",
      icon: Briefcase,
      color: "#2196f3",
      capabilities: [
        {
          capability: "View Platform Operations Metrics",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Sales & Marketing KPIs",
          admin: true,
          client: false,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Access Development Tools",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Submit Bug Reports",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "View System Status",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Campaign Analytics",
          admin: true,
          client: false,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Access API Documentation",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
      ],
    },
    finance: {
      title: "Financial Perspective",
      description: "Permissions for financial data and billing",
      icon: DollarSign,
      color: "#4caf50",
      capabilities: [
        {
          capability: "View Full Financial Dashboard",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Own Billing Information",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Download Invoices",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Manage Payment Methods",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "View Revenue Metrics",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "Access Commission Reports",
          admin: true,
          client: false,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Modify Pricing/Plans",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
      ],
    },
    learning: {
      title: "Learning & Growth Perspective",
      description: "Permissions for training and development resources",
      icon: Lightbulb,
      color: "#ff9800",
      capabilities: [
        {
          capability: "Access Training Library",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Enroll in Courses",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "View Certification Progress",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
        {
          capability: "Access Advanced AI Training",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Create/Manage Training Content",
          admin: true,
          client: false,
          agency: false,
          affiliates: false,
        },
        {
          capability: "View Team Training Analytics",
          admin: true,
          client: true,
          agency: true,
          affiliates: false,
        },
        {
          capability: "Download Certifications",
          admin: true,
          client: true,
          agency: true,
          affiliates: true,
        },
      ],
    },
  };

  const handleSelectTier = (tierId: string) => {
    setSelectedTier(tierId);
    console.log("Selected tier:", tierId);
  };

  const handleSignOut = () => {
    toast.success("Signed out successfully");
    console.log("User signed out");
  };

  const handleChangeUser = () => {
    const users = [
      "admin@baiv2.com",
      "manager@baiv2.com",
      "developer@baiv2.com",
      "support@baiv2.com"
    ];
    const currentIndex = users.indexOf(currentUser);
    const nextUser = users[(currentIndex + 1) % users.length];
    setCurrentUser(nextUser);
    toast.success(`Switched to ${nextUser}`);
  };

  const getTabIcon = () => {
    switch (activeTab) {
      case "admin":
        return <Building2 className="w-6 h-6" />;
      case "agency":
        return <Briefcase className="w-6 h-6" />;
      case "direct":
        return <Users className="w-6 h-6" />;
      case "affiliate":
        return <Award className="w-6 h-6" />;
    }
  };

  const getTabTitle = () => {
    switch (activeTab) {
      case "admin":
        return "Admin";
      case "agency":
        return "Agency Client Portal";
      case "direct":
        return "Direct Client Portal";
      case "affiliate":
        return "Affiliate Portal";
    }
  };

  const getTabDescription = () => {
    switch (activeTab) {
      case "admin":
        return "Manage your BAIV2 platform, users, and system settings";
      case "agency":
        return "Agency client management and campaign oversight";
      case "direct":
        return "Direct client access to platform features and analytics";
      case "affiliate":
        return "Affiliate partner dashboard and commission tracking";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start gap-4">
            <div className="p-3 bg-primary/10 rounded-lg text-primary">
              {getTabIcon()}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <CardTitle className="text-2xl">{getTabTitle()}</CardTitle>
                <Badge variant="outline" className="ml-2">
                  BAIV2
                </Badge>
              </div>
              <CardDescription className="text-base">
                {getTabDescription()}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Breadcrumb Navigation */}
      <AppBreadcrumb
        className="mb-4"
        items={[
          {
            label: "Home",
            onClick: () => {
              setCurrentView("dashboard");
              toast.success("Returned to Home");
            },
          },
          {
            label: activeTab === "admin" ? "Admin" : activeTab === "agency" ? "Agency Client" : activeTab === "direct" ? "Direct Client" : "Affiliate",
            onClick: () => {
              setCurrentView("dashboard");
            },
          },
          ...(currentView !== "dashboard" ? [{
            label: currentView === "value-engineer" ? "Value Engineer" : currentView === "context-engineer" ? "Context Engineer" : currentView === "product-baiv" ? "Product BAIV" : currentView === "crm" ? "CRM" : currentView === "product-manager" ? "Product Manager" : currentView === "solution-architect" ? "Solution Architect" : "PF Dashboard",
            onClick: saSubView ? () => {
              setSaSubView(null);
            } : undefined,
            isCurrentPage: !saSubView,
          }] : []),
          ...(saSubView ? [{
            label: saSubView === "requirements" ? "Instance Requirements & Discovery" : saSubView === "architecture" ? "Architecture Design" : saSubView === "techstack" ? "Tech Stack and Config" : saSubView === "design-uiux" ? "Design UI UX" : saSubView === "agent-architect" ? "Agent Architect" : saSubView === "data-architect" ? "Data Architect" : "",
            isCurrentPage: true,
          }] : []),
        ]}
      />

      {/* Content based on active tab */}
      {activeTab === "admin" ? (
        <Tabs defaultValue={defaultTabView} className="w-full" onValueChange={setCurrentView}>
        <TabsList className="grid w-full grid-cols-7 max-w-7xl">
          <TabsTrigger value="dashboard" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">PF Dashboard</TabsTrigger>
          <TabsTrigger value="product-baiv" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">Product BAIV</TabsTrigger>
          <TabsTrigger value="crm" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">CRM</TabsTrigger>
          <TabsTrigger value="value-engineer" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">Value Engineer</TabsTrigger>
          <TabsTrigger value="context-engineer" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">Context Engineer</TabsTrigger>
          <TabsTrigger value="product-manager" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">Product Manager</TabsTrigger>
          <TabsTrigger value="solution-architect" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm">Solution Architect</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-6">
          <PlatformDashboard platforms={mockPlatforms} metrics={mockMetrics} />
        </TabsContent>

        <TabsContent value="value-engineer" className="mt-6">
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Value Engineer Process</h2>
                  <p className="text-muted-foreground">
                    Structured 7-step workflow for value engineering with ontology validation
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setCurrentView("dashboard");
                    toast.success("Returned to PF Dashboard");
                  }}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to PF Dashboard
                </Button>
              </div>
            </div>

            {/* VE Step Navigator */}
            <Card className="border-2">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Progress Indicator */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="default" className="bg-purple-600">
                        Step {veCurrentStep} of 7
                      </Badge>
                      <span className="text-sm text-muted-foreground">Value Engineer Process</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {Math.round((veCurrentStep / 7) * 100)}% Complete
                    </div>
                  </div>

                  {/* Step Progress Bar */}
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(veCurrentStep / 7) * 100}%` }}
                    />
                  </div>

                  {/* Step Buttons */}
                  <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
                    <Button
                      variant={veCurrentStep === 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(1);
                        toast.success("Step 1: RRR");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 100</span>
                        <span className="text-xs">RRR</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 2 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(2);
                        toast.success("Step 2: Business Framework");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 150</span>
                        <span className="text-xs">Bus. Framework</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 3 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(3);
                        toast.success("Step 3: VSOM Strategy");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 200</span>
                        <span className="text-xs">VSOM</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 4 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(4);
                        toast.success("Step 4: OKR");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 300</span>
                        <span className="text-xs">OKR</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 5 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(5);
                        toast.success("Step 5: Metrics");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 400</span>
                        <span className="text-xs">Metrics</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 6 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(6);
                        toast.success("Step 6: Value Proposition");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 700</span>
                        <span className="text-xs">ValueProp</span>
                      </div>
                    </Button>

                    <Button
                      variant={veCurrentStep === 7 ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setVeCurrentStep(7);
                        toast.success("Step 7: PMF & GTM");
                      }}
                      className="justify-start"
                    >
                      <div className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold">VE 800</span>
                        <span className="text-xs">PMF & GTM</span>
                      </div>
                    </Button>
                  </div>

                  {/* Navigation Arrows */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (veCurrentStep > 1) {
                          setVeCurrentStep(veCurrentStep - 1);
                          toast.success(`Moved to Step ${veCurrentStep - 1}`);
                        }
                      }}
                      disabled={veCurrentStep === 1}
                    >
                      <ChevronLeft className="w-4 h-4 mr-1" />
                      Previous
                    </Button>
                    <span className="text-sm font-medium">
                      {veCurrentStep === 1 && "Step 1: RRR - Roles, RACI & RBAC"}
                      {veCurrentStep === 2 && "Step 2: Business Framework"}
                      {veCurrentStep === 3 && "Step 3: VSOM - Value Strategy Operating Model"}
                      {veCurrentStep === 4 && "Step 4: OKR - Objectives & Key Results"}
                      {veCurrentStep === 5 && "Step 5: Metrics & Measurement"}
                      {veCurrentStep === 6 && "Step 6: Value Proposition Canvas"}
                      {veCurrentStep === 7 && "Step 7: PMF & GTM Alignment"}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (veCurrentStep < 7) {
                          setVeCurrentStep(veCurrentStep + 1);
                          toast.success(`Moved to Step ${veCurrentStep + 1}`);
                        }
                      }}
                      disabled={veCurrentStep === 7}
                    >
                      Next
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* VE Process Steps - Conditional Rendering */}
            <div className="space-y-4">
              {/* VE 100 - RRR */}
              {veCurrentStep === 1 && (
              <Card className="border-l-4 border-l-purple-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                        <Shield className="w-6 h-6 text-purple-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 100</Badge>
                        <CardTitle>RRR - Roles, RACI & RBAC</CardTitle>
                        <CardDescription className="mt-1">
                          Define roles, responsibilities, and access control for value engineering
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Business FRs */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        Business Functional Requirements
                      </div>
                      <div className="space-y-1.5 text-sm text-muted-foreground pl-6">
                        <li>Define all stakeholder roles and permissions</li>
                        <li>Establish RACI matrix for value engineering activities</li>
                        <li>Configure role-based access control policies</li>
                        <li>Map organizational hierarchy and reporting lines</li>
                      </div>
                    </div>

                    {/* Applicable Agents */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-600" />
                        Applicable Agents
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-purple-50 dark:bg-purple-950/20 rounded border border-purple-200 dark:border-purple-800">
                          <CheckCircle2 className="w-4 h-4 text-purple-600" />
                          <span>Role Definition Agent</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-purple-50 dark:bg-purple-950/20 rounded border border-purple-200 dark:border-purple-800">
                          <CheckCircle2 className="w-4 h-4 text-purple-600" />
                          <span>RACI Generator Agent</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-purple-50 dark:bg-purple-950/20 rounded border border-purple-200 dark:border-purple-800">
                          <CheckCircle2 className="w-4 h-4 text-purple-600" />
                          <span>Access Control Agent</span>
                        </div>
                      </div>
                    </div>

                    {/* Applicable Ontologies */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4 text-green-600" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Organization Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Role Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>RBAC Framework</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-gray-50 dark:bg-gray-900/20 rounded border border-gray-200 dark:border-gray-700">
                          <Circle className="w-4 h-4 text-gray-400" />
                          <span>Process Ontology</span>
                        </div>
                      </div>
                    </div>

                    {/* Applicable Schema */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Database className="w-4 h-4 text-amber-600" />
                        Applicable Schema
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800">
                          <CheckCircle2 className="w-4 h-4 text-amber-600" />
                          <span>Role Schema</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800">
                          <CheckCircle2 className="w-4 h-4 text-amber-600" />
                          <span>Permission Schema</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800">
                          <CheckCircle2 className="w-4 h-4 text-amber-600" />
                          <span>Responsibility Schema</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 150 - Business Frameworks */}
              {veCurrentStep === 2 && (
              <Card className="border-l-4 border-l-teal-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-teal-500/10 flex items-center justify-center">
                        <Briefcase className="w-6 h-6 text-teal-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 150</Badge>
                        <CardTitle>Business Frameworks</CardTitle>
                        <CardDescription className="mt-1">
                          Strategic business frameworks for value engineering
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2">Available Frameworks</div>
                      <ul className="space-y-1.5 text-sm text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>BSC - Balanced Scorecard</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Business Model Canvas</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Customer Journey Map</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Lean Canvas</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Strategy Canvas</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>SWOT Analysis</span>
                        </li>
                      </ul>
                    </div>
                    <Separator />
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Framework Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Business Model Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Strategy Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Canvas Framework</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 200 - VSOM */}
              {veCurrentStep === 3 && (
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                        <Target className="w-6 h-6 text-blue-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 200</Badge>
                        <CardTitle>VSOM - Value Strategy Operating Model</CardTitle>
                        <CardDescription className="mt-1">
                          Define Vision, Strategy, Objectives & Metrics mapped to 4 Balanced Scorecard Perspectives
                        </CardDescription>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setShowVSOMDialog(true)}
                    >
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Vision Statement */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        Vision Statement
                      </div>
                      <div className="p-3 bg-muted rounded-lg border">
                        <p className="text-xs">
                          {vsomConfig.vision.statement}
                        </p>
                      </div>
                    </div>

                    {/* 4 Balanced Scorecard Perspectives for BAIV */}
                    <div className="text-sm">
                      <div className="font-medium mb-3 flex items-center gap-2">
                        <Lightbulb className="w-4 h-4" />
                        Strategy: 4 Perspectives (Balanced Scorecard)
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {/* Financial Perspective */}
                        <div className="p-3 bg-muted rounded-lg border">
                          <div className="flex items-center gap-2 mb-2">
                            <DollarSign className="w-4 h-4" />
                            <span className="text-xs font-semibold">
                              Financial Excellence
                            </span>
                          </div>
                          <ul className="space-y-1">
                            {vsomConfig.strategy.financial.goals.slice(0, 2).map((goal, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-1">
                                <Circle className="w-2 h-2 mt-1 flex-shrink-0" />
                                <span>{goal}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Customer Perspective */}
                        <div className="p-3 bg-muted rounded-lg border">
                          <div className="flex items-center gap-2 mb-2">
                            <Users className="w-4 h-4" />
                            <span className="text-xs font-semibold">
                              Customer Success & Value
                            </span>
                          </div>
                          <ul className="space-y-1">
                            {vsomConfig.strategy.customer.goals.slice(0, 2).map((goal, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-1">
                                <Circle className="w-2 h-2 mt-1 flex-shrink-0" />
                                <span>{goal}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Internal Process Perspective */}
                        <div className="p-3 bg-muted rounded-lg border">
                          <div className="flex items-center gap-2 mb-2">
                            <Settings className="w-4 h-4" />
                            <span className="text-xs font-semibold">
                              Internal Process & Operations
                            </span>
                          </div>
                          <ul className="space-y-1">
                            {vsomConfig.strategy.internal.goals.slice(0, 2).map((goal, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-1">
                                <Circle className="w-2 h-2 mt-1 flex-shrink-0" />
                                <span>{goal}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {/* Learning & Growth Perspective */}
                        <div className="p-3 bg-muted rounded-lg border">
                          <div className="flex items-center gap-2 mb-2">
                            <Lightbulb className="w-4 h-4" />
                            <span className="text-xs font-semibold">
                              Learning & Growth
                            </span>
                          </div>
                          <ul className="space-y-1">
                            {vsomConfig.strategy.learning.goals.slice(0, 2).map((goal, idx) => (
                              <li key={idx} className="text-xs flex items-start gap-1">
                                <Circle className="w-2 h-2 mt-1 flex-shrink-0" />
                                <span>{goal}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Key Objectives (OKRs) */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Key Objectives ({vsomConfig.objectives.length} OKRs)
                      </div>
                      <div className="grid grid-cols-1 gap-2">
                        {vsomConfig.objectives.slice(0, 2).map((obj, idx) => (
                          <div key={idx} className="p-2 bg-muted rounded border">
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-xs font-medium">
                                {obj.objective}
                              </p>
                              <Badge variant="outline" className="text-xs">
                                {obj.perspective}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Metrics Overview */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <BarChart3 className="w-4 h-4" />
                        Metrics & KPIs (20 Total Metrics)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>5 Financial</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>5 Customer</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>5 Internal</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>5 Learning</span>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    {/* Business Context for BAIV */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Briefcase className="w-4 h-4" />
                        BAIV Business Context
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Professional Services</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Advertising & Marketing</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>AI Visibility Platform</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Analytics SaaS</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>B2B Enterprise</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-muted rounded border">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>MarTech Solutions</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded">
                      <p>
                        <strong>VSOM Framework:</strong> Maps organizational Vision to actionable Strategy using 4 Balanced Scorecard perspectives (Financial, Customer, Internal, Learning & Growth), defines measurable Objectives (OKRs), and tracks performance through comprehensive Metrics aligned to each perspective.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 300 - OKR */}
              {veCurrentStep === 4 && (
              <Card className="border-l-4 border-l-indigo-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-indigo-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 300</Badge>
                        <CardTitle>OKR - Objectives & Key Results</CardTitle>
                        <CardDescription className="mt-1">
                          Set and track objectives and key results for strategic alignment
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Objective Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>KPI Framework</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Performance Ontology</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 400 - Metrics */}
              {veCurrentStep === 5 && (
              <Card className="border-l-4 border-l-green-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 400</Badge>
                        <CardTitle>Metrics & Measurement</CardTitle>
                        <CardDescription className="mt-1">
                          Define metrics, KPIs, and measurement frameworks for value tracking
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Metrics Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Measurement Framework</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Analytics Ontology</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 500 - TBC - HIDDEN (not part of 7-step process) */}
              {false && (
              <Card className="border-l-4 border-l-gray-400">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-gray-400/10 flex items-center justify-center">
                        <Package className="w-6 h-6 text-gray-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 500</Badge>
                        <CardTitle>TBC - To Be Configured</CardTitle>
                        <CardDescription className="mt-1">
                          Reserved for future value engineering workflow step
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-gray-50 dark:bg-gray-900/20 rounded border border-gray-200 dark:border-gray-700">
                          <Circle className="w-4 h-4 text-gray-400" />
                          <span>Pending Configuration</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 600 - Value Frameworks - HIDDEN (not part of 7-step process) */}
              {false && (
              <Card className="border-l-4 border-l-orange-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center">
                        <Award className="w-6 h-6 text-orange-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 600</Badge>
                        <CardTitle>Value Frameworks</CardTitle>
                        <CardDescription className="mt-1">
                          Business model canvas, lean canvas, and strategy frameworks
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Business Model Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Canvas Framework</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Strategy Ontology</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 700 - ValueProp Wizard */}
              {veCurrentStep === 6 && (
              <Card className="border-l-4 border-l-[#00a4bf]">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-[#00a4bf]/10 flex items-center justify-center">
                        <Users className="w-6 h-6 text-[#00a4bf]" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 700</Badge>
                        <CardTitle>ValueProp Wizard</CardTitle>
                        <CardDescription className="mt-1">
                          7-step wizard to define value propositions using the Value Proposition Canvas
                        </CardDescription>
                      </div>
                    </div>
                    <Button 
                      size="sm"
                      onClick={() => {
                        onLaunchValueProp?.();
                        toast.success("Launching Value Proposition Wizard");
                      }}
                    >
                      Launch Wizard
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Applicable Ontologies (OAA Approved)
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Customer Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Value Proposition Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Product/Service Ontology</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Pain/Gain Framework</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}

              {/* VE 800 - PM & GTM Alignment */}
              {veCurrentStep === 7 && (
              <Card className="border-l-4 border-l-emerald-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <Target className="w-6 h-6 text-emerald-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">VE 800</Badge>
                        <CardTitle>PM & GTM Alignment</CardTitle>
                        <CardDescription className="mt-1">
                          Align Product Management and Go-to-Market strategies to optimize value delivery and achieve product-market fit
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Product-Market Fit Assessment */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Target className="w-4 h-4 text-emerald-600" />
                        Product-Market Fit Assessment
                      </div>
                      <div className="grid gap-2">
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Market validation metrics and customer satisfaction indicators</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Product adoption rates, retention curves, and engagement patterns</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Customer feedback loops and voice-of-customer analysis</span>
                        </div>
                      </div>
                    </div>

                    {/* GTM Strategy Alignment */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-blue-600" />
                        GTM Strategy Alignment
                      </div>
                      <div className="grid gap-2">
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Messaging & positioning framework aligned with product value props</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Sales enablement materials, playbooks, and competitive battlecards</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Marketing campaign strategies and channel optimization</span>
                        </div>
                      </div>
                    </div>

                    {/* Cross-Functional Collaboration */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Users className="w-4 h-4 text-purple-600" />
                        Cross-Functional Collaboration
                      </div>
                      <div className="grid gap-2">
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>PM-Sales-Marketing alignment meetings and shared OKRs</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Customer success integration and feedback mechanisms</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Launch readiness checklists and go-live coordination</span>
                        </div>
                      </div>
                    </div>

                    {/* Value Delivery Optimization */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <Award className="w-4 h-4 text-amber-600" />
                        Value Delivery Optimization
                      </div>
                      <div className="grid gap-2">
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Customer onboarding optimization and time-to-value acceleration</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Feature adoption tracking and usage analytics</span>
                        </div>
                        <div className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded border">
                          <Circle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span>Customer health scoring and expansion opportunity identification</span>
                        </div>
                      </div>
                    </div>

                    {/* PMF Metrics & KPIs */}
                    <div className="text-sm">
                      <div className="font-medium mb-2 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        PMF Metrics & KPIs
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>NPS & CSAT Scores</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Retention Rates</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Win Rates</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Sales Cycle Length</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>CAC:LTV Ratio</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span>Revenue Growth</span>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="text-xs text-muted-foreground">
                      <p className="mb-2">
                        <strong>Alignment Framework:</strong> This module ensures Product Management and Go-to-Market teams work in harmony to deliver maximum customer value and achieve sustainable product-market fit.
                      </p>
                      <p>
                        Configure PM-GTM alignment processes, define shared metrics, establish feedback loops, and optimize value delivery across the customer lifecycle.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="context-engineer" className="mt-6">
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Context Engineer Process</h2>
                  <p className="text-muted-foreground">
                    Define organizational context, maturity models, and sector-specific customization
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setCurrentView("dashboard");
                    toast.success("Returned to PF Dashboard");
                  }}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to PF Dashboard
                </Button>
              </div>
            </div>
            
            {/* CE Process Steps - Placeholders */}
            <div className="space-y-4">
              {/* CE 100 - Sector Context */}
              <Card className="border-l-4 border-l-cyan-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                        <Target className="w-6 h-6 text-cyan-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">CE 100</Badge>
                        <CardTitle>Sector Context</CardTitle>
                        <CardDescription className="mt-1">
                          Define industry sector and market context
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
              </Card>

              {/* CE 200 - Organizational Maturity */}
              <Card className="border-l-4 border-l-teal-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-teal-500/10 flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-teal-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">CE 200</Badge>
                        <CardTitle>Organizational Maturity</CardTitle>
                        <CardDescription className="mt-1">
                          Assess and define maturity level across dimensions
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
              </Card>

              {/* CE 300 - Cultural Context */}
              <Card className="border-l-4 border-l-indigo-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                        <Users className="w-6 h-6 text-indigo-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">CE 300</Badge>
                        <CardTitle>Cultural Context</CardTitle>
                        <CardDescription className="mt-1">
                          Define organizational culture and values
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
              </Card>

              {/* CE 400 - Regulatory Environment */}
              <Card className="border-l-4 border-l-orange-500">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center">
                        <Shield className="w-6 h-6 text-orange-500" />
                      </div>
                      <div>
                        <Badge variant="outline" className="mb-2">CE 400</Badge>
                        <CardTitle>Regulatory Environment</CardTitle>
                        <CardDescription className="mt-1">
                          Map compliance requirements and constraints
                        </CardDescription>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" disabled>
                      Configure
                    </Button>
                  </div>
                </CardHeader>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="product-baiv" className="mt-6">
          <ProductBAIV />
        </TabsContent>

        <TabsContent value="crm" className="mt-6">
          <CRM onBack={() => setCurrentView("dashboard")} />
        </TabsContent>

        <TabsContent value="product-manager" className="mt-6">
          <ProductManager onBack={() => setCurrentView("dashboard")} />
        </TabsContent>

        <TabsContent value="solution-architect" className="mt-6">
          {saSubView === "requirements" ? (
            <RequirementsDiscovery onBack={() => setSaSubView(null)} />
          ) : saSubView === "architecture" ? (
            <ArchitectureDesign onBack={() => setSaSubView(null)} />
          ) : saSubView === "techstack" ? (
            <TechStackConfig onBack={() => setSaSubView(null)} />
          ) : saSubView === "design-uiux" ? (
            <DesignUIUX onBack={() => setSaSubView(null)} />
          ) : saSubView === "agent-architect" ? (
            <AgentArchitect onBack={() => setSaSubView(null)} />
          ) : saSubView === "data-architect" ? (
            <DataArchitect onBack={() => setSaSubView(null)} />
          ) : (
          <SolutionArchitectAccordion
            rbacPerspective={rbacPerspective}
            setRbacPerspective={setRbacPerspective}
            rbacPermissions={rbacPermissions}
            setSaSubView={setSaSubView}
            onBackToDashboard={() => {
              setCurrentView("dashboard");
              toast.success("Returned to PF Dashboard");
            }}
          />
          )}
        </TabsContent>

      </Tabs>
      ) : activeTab === "agency" ? (
        <Card>
          <CardHeader>
            <CardTitle>Agency Client Settings & Functions</CardTitle>
            <CardDescription>Manage your agency clients and campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Client Management */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Client Management</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <CardTitle className="text-base">Active Clients</CardTitle>
                      <CardDescription>Manage your client portfolio</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm">Acme Corporation</span>
                          <Badge>Active</Badge>
                        </div>
                        <div className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm">TechStart Inc</span>
                          <Badge>Active</Badge>
                        </div>
                        <div className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm">Global Ventures</span>
                          <Badge variant="secondary">Pending</Badge>
                        </div>
                      </div>
                      <Button className="w-full mt-4" variant="outline">
                        <Users className="w-4 h-4 mr-2" />
                        View All Clients
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-green-500">
                    <CardHeader>
                      <CardTitle className="text-base">Campaign Overview</CardTitle>
                      <CardDescription>Track campaign performance</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Active Campaigns</span>
                          <span className="text-2xl font-bold">12</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Total Value</span>
                          <span className="text-2xl font-bold">$145K</span>
                        </div>
                        <Separator />
                        <Button className="w-full" variant="outline">
                          <TrendingUp className="w-4 h-4 mr-2" />
                          View Analytics
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Key Functions */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Key Functions</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Briefcase className="w-6 h-6" />
                    <span>Create Campaign</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Users className="w-6 h-6" />
                    <span>Onboard Client</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Settings className="w-6 h-6" />
                    <span>Agency Settings</span>
                  </Button>
                </div>
              </div>

              {/* Recent Activity */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Recent Activity</h3>
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>New client "Acme Corporation" onboarded</span>
                        <span className="text-muted-foreground ml-auto">2h ago</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>Campaign "Q4 Value Prop" approved</span>
                        <span className="text-muted-foreground ml-auto">5h ago</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <Circle className="w-4 h-4 text-muted-foreground" />
                        <span>Proposal submitted to "Global Ventures"</span>
                        <span className="text-muted-foreground ml-auto">1d ago</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : activeTab === "direct" ? (
        <Card>
          <CardHeader>
            <CardTitle>Direct Client Settings & Functions</CardTitle>
            <CardDescription>Manage your direct client subscriptions and resources</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Account Overview */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Account Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-l-4 border-l-green-500">
                    <CardHeader>
                      <CardTitle className="text-base">Subscription</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Plan</span>
                          <Badge variant="default">Professional</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Status</span>
                          <Badge className="bg-green-600">Active</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Renewal</span>
                          <span className="text-sm">Jan 15, 2026</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <CardTitle className="text-base">Usage</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Users</span>
                          <span className="text-sm font-semibold">18 / 50</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Storage</span>
                          <span className="text-sm font-semibold">3.2 / 10 GB</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">API Calls</span>
                          <span className="text-sm font-semibold">12.5K / 50K</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-green-500">
                    <CardHeader>
                      <CardTitle className="text-base">Performance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Projects</span>
                          <span className="text-2xl font-bold">7</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Completed</span>
                          <span className="text-sm font-semibold text-green-600">92%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Quick Actions */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Quick Actions</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Package className="w-6 h-6" />
                    <span>New Project</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Users className="w-6 h-6" />
                    <span>Manage Team</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <TrendingUp className="w-6 h-6" />
                    <span>View Reports</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Settings className="w-6 h-6" />
                    <span>Settings</span>
                  </Button>
                </div>
              </div>

              {/* Available Features */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Available Features</h3>
                <Card>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>Advanced Analytics</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>Priority Support</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>Custom Integrations</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>API Access</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>Team Collaboration</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span>White-label Options</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : activeTab === "affiliate" ? (
        <Card>
          <CardHeader>
            <CardTitle>Affiliate Partner Dashboard</CardTitle>
            <CardDescription>Track your referrals and commission earnings</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Commission Overview */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Commission Overview</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card className="border-l-4 border-l-green-500">
                    <CardHeader>
                      <CardTitle className="text-base">Total Earnings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-green-600">$8,742</div>
                      <p className="text-xs text-muted-foreground mt-1">All time</p>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <CardTitle className="text-base">This Month</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-blue-600">$1,245</div>
                      <p className="text-xs text-muted-foreground mt-1">+18% from last month</p>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-purple-500">
                    <CardHeader>
                      <CardTitle className="text-base">Referrals</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-purple-600">42</div>
                      <p className="text-xs text-muted-foreground mt-1">Total referrals</p>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-l-orange-500">
                    <CardHeader>
                      <CardTitle className="text-base">Conversion Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-orange-600">28%</div>
                      <p className="text-xs text-muted-foreground mt-1">12 converted</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Referral Stats */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Referral Statistics</h3>
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Active Referrals</p>
                          <p className="text-xs text-muted-foreground">Currently using the platform</p>
                        </div>
                        <div className="text-2xl font-bold">12</div>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Pending Referrals</p>
                          <p className="text-xs text-muted-foreground">Awaiting conversion</p>
                        </div>
                        <div className="text-2xl font-bold">18</div>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Inactive Referrals</p>
                          <p className="text-xs text-muted-foreground">Trial expired</p>
                        </div>
                        <div className="text-2xl font-bold">12</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Affiliate Tools */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Affiliate Tools</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Award className="w-6 h-6" />
                    <span>Get Referral Link</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <Package className="w-6 h-6" />
                    <span>Marketing Materials</span>
                  </Button>
                  <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                    <TrendingUp className="w-6 h-6" />
                    <span>Performance Report</span>
                  </Button>
                </div>
              </div>

              {/* Recent Commission Activity */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Recent Commission Activity</h3>
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-green-600"></div>
                          <span>Acme Corp - Professional Plan</span>
                        </div>
                        <span className="font-semibold text-green-600">+$299</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-green-600"></div>
                          <span>TechStart Inc - Starter Plan</span>
                        </div>
                        <span className="font-semibold text-green-600">+$87</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-green-600"></div>
                          <span>Global Ventures - Enterprise Plan</span>
                        </div>
                        <span className="font-semibold text-green-600">+$899</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* User and Sign Out Buttons */}
      <div className="flex items-center justify-between mt-6">
        <div className="flex items-center">
          <UserCog className="w-4 h-4 mr-2" />
          <span className="text-sm text-muted-foreground">{currentUser}</span>
        </div>
        <div className="flex items-center">
          <Button
            variant="ghost"
            className="text-sm text-muted-foreground"
            onClick={handleChangeUser}
          >
            Change User
          </Button>
          <Button
            variant="ghost"
            className="text-sm text-muted-foreground"
            onClick={handleSignOut}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* VSOM Configuration Dialog */}
      <Dialog open={showVSOMDialog} onOpenChange={setShowVSOMDialog}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-500" />
              VSOM Configuration - Value Strategy Operating Model
            </DialogTitle>
            <DialogDescription>
              Configure Vision, Strategy (4 Perspectives), Objectives, and Metrics for BAIV AI Visibility Platform
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="vision" className="mt-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="vision">Vision</TabsTrigger>
              <TabsTrigger value="strategy">Strategy</TabsTrigger>
              <TabsTrigger value="objectives">Objectives</TabsTrigger>
              <TabsTrigger value="metrics">Metrics</TabsTrigger>
            </TabsList>

            {/* Vision Tab */}
            <TabsContent value="vision" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Vision Statement</CardTitle>
                  <CardDescription>Define the overarching vision for the platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={vsomConfig.vision.statement}
                    onChange={(e) => setVsomConfig({ ...vsomConfig, vision: { ...vsomConfig.vision, statement: e.target.value }})}
                    placeholder="Enter vision statement..."
                    rows={4}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Mission</CardTitle>
                  <CardDescription>Core purpose and mission</CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={vsomConfig.vision.mission}
                    onChange={(e) => setVsomConfig({ ...vsomConfig, vision: { ...vsomConfig.vision, mission: e.target.value }})}
                    placeholder="Enter mission statement..."
                    rows={3}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Core Values</CardTitle>
                  <CardDescription>Fundamental values and principles</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {vsomConfig.vision.values.map((value, idx) => (
                    <Input
                      key={idx}
                      value={value}
                      onChange={(e) => {
                        const newValues = [...vsomConfig.vision.values];
                        newValues[idx] = e.target.value;
                        setVsomConfig({ ...vsomConfig, vision: { ...vsomConfig.vision, values: newValues }});
                      }}
                      placeholder={`Core Value ${idx + 1}`}
                    />
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Strategy Tab - 4 Balanced Scorecard Perspectives */}
            <TabsContent value="strategy" className="space-y-4 mt-4">
              <div className="space-y-6">
                {/* Financial Perspective */}
                <Card className="border-l-4 border-l-green-500">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <DollarSign className="w-5 h-5 text-green-600" />
                      Financial Excellence Perspective
                    </CardTitle>
                    <CardDescription>
                      Revenue growth, profitability, and financial sustainability goals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label>Strategic Goals</Label>
                      {vsomConfig.strategy.financial.goals.map((goal, idx) => (
                        <div key={idx} className="flex gap-2 mt-2">
                          <Input
                            value={goal}
                            onChange={(e) => {
                              const newGoals = [...vsomConfig.strategy.financial.goals];
                              newGoals[idx] = e.target.value;
                              setVsomConfig({
                                ...vsomConfig,
                                strategy: {
                                  ...vsomConfig.strategy,
                                  financial: { ...vsomConfig.strategy.financial, goals: newGoals }
                                }
                              });
                            }}
                            className="text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Customer Perspective */}
                <Card className="border-l-4 border-l-blue-500">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Users className="w-5 h-5 text-blue-600" />
                      Customer Success & Value Perspective
                    </CardTitle>
                    <CardDescription>
                      Customer satisfaction, retention, and value delivery goals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label>Strategic Goals</Label>
                      {vsomConfig.strategy.customer.goals.map((goal, idx) => (
                        <div key={idx} className="flex gap-2 mt-2">
                          <Input
                            value={goal}
                            onChange={(e) => {
                              const newGoals = [...vsomConfig.strategy.customer.goals];
                              newGoals[idx] = e.target.value;
                              setVsomConfig({
                                ...vsomConfig,
                                strategy: {
                                  ...vsomConfig.strategy,
                                  customer: { ...vsomConfig.strategy.customer, goals: newGoals }
                                }
                              });
                            }}
                            className="text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Internal Process Perspective */}
                <Card className="border-l-4 border-l-purple-500">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Briefcase className="w-5 h-5 text-purple-600" />
                      Internal Process & Operations Perspective
                    </CardTitle>
                    <CardDescription>
                      Operational efficiency, process optimization, and quality improvement goals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label>Strategic Goals</Label>
                      {vsomConfig.strategy.internal.goals.map((goal, idx) => (
                        <div key={idx} className="flex gap-2 mt-2">
                          <Input
                            value={goal}
                            onChange={(e) => {
                              const newGoals = [...vsomConfig.strategy.internal.goals];
                              newGoals[idx] = e.target.value;
                              setVsomConfig({
                                ...vsomConfig,
                                strategy: {
                                  ...vsomConfig.strategy,
                                  internal: { ...vsomConfig.strategy.internal, goals: newGoals }
                                }
                              });
                            }}
                            className="text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Learning & Growth Perspective */}
                <Card className="border-l-4 border-l-indigo-500">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Lightbulb className="w-5 h-5 text-indigo-600" />
                      Learning & Growth Perspective
                    </CardTitle>
                    <CardDescription>
                      Innovation, talent development, and organizational learning goals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label>Strategic Goals</Label>
                      {vsomConfig.strategy.learning.goals.map((goal, idx) => (
                        <div key={idx} className="flex gap-2 mt-2">
                          <Input
                            value={goal}
                            onChange={(e) => {
                              const newGoals = [...vsomConfig.strategy.learning.goals];
                              newGoals[idx] = e.target.value;
                              setVsomConfig({
                                ...vsomConfig,
                                strategy: {
                                  ...vsomConfig.strategy,
                                  learning: { ...vsomConfig.strategy.learning, goals: newGoals }
                                }
                              });
                            }}
                            className="text-sm"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Objectives Tab (OKRs) */}
            <TabsContent value="objectives" className="space-y-4 mt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Objectives & Key Results (OKRs)</Label>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setVsomConfig({
                        ...vsomConfig,
                        objectives: [
                          ...vsomConfig.objectives,
                          {
                            objective: "New Objective",
                            keyResults: ["Key Result 1", "Key Result 2"],
                            perspective: "Financial"
                          }
                        ]
                      });
                    }}
                  >
                    Add OKR
                  </Button>
                </div>

                {vsomConfig.objectives.map((okr, idx) => (
                  <Card key={idx}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <Input
                            value={okr.objective}
                            onChange={(e) => {
                              const newObjectives = [...vsomConfig.objectives];
                              newObjectives[idx].objective = e.target.value;
                              setVsomConfig({ ...vsomConfig, objectives: newObjectives });
                            }}
                            placeholder="Objective"
                            className="mb-2"
                          />
                          <div className="flex gap-2">
                            <Label className="text-xs">Perspective:</Label>
                            <select
                              value={okr.perspective}
                              onChange={(e) => {
                                const newObjectives = [...vsomConfig.objectives];
                                newObjectives[idx].perspective = e.target.value;
                                setVsomConfig({ ...vsomConfig, objectives: newObjectives });
                              }}
                              className="text-xs border rounded px-2 py-1"
                            >
                              <option value="Financial">Financial</option>
                              <option value="Customer">Customer</option>
                              <option value="Internal">Internal Process</option>
                              <option value="Learning">Learning & Growth</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Label className="text-xs">Key Results</Label>
                      <div className="space-y-2 mt-2">
                        {okr.keyResults.map((kr, krIdx) => (
                          <Input
                            key={krIdx}
                            value={kr}
                            onChange={(e) => {
                              const newObjectives = [...vsomConfig.objectives];
                              newObjectives[idx].keyResults[krIdx] = e.target.value;
                              setVsomConfig({ ...vsomConfig, objectives: newObjectives });
                            }}
                            placeholder={`Key Result ${krIdx + 1}`}
                            className="text-sm"
                          />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Metrics Tab */}
            <TabsContent value="metrics" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Performance Metrics & KPIs</CardTitle>
                  <CardDescription>
                    Define key performance indicators across all perspectives
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Configure metrics to measure progress toward your strategic objectives
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default Baiv2App;