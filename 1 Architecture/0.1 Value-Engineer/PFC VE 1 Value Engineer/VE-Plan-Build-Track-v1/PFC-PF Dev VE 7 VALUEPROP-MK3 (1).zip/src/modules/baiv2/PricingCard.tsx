import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Check } from "lucide-react";
import type { PricingTier } from "./types";

interface PricingCardProps {
  tier: PricingTier;
  onSelect?: (tierId: string) => void;
}

export function PricingCard({ tier, onSelect }: PricingCardProps) {
  return (
    <Card className={tier.recommended ? "border-primary shadow-lg" : ""}>
      <CardHeader>
        {tier.recommended && (
          <Badge className="w-fit mb-2">Recommended</Badge>
        )}
        <CardTitle>{tier.name}</CardTitle>
        <CardDescription>{tier.description}</CardDescription>
        <div className="mt-4">
          <span className="text-4xl font-bold">${tier.price}</span>
          <span className="text-muted-foreground">/month</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <ul className="space-y-2">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
        <Button 
          className="w-full" 
          variant={tier.recommended ? "default" : "outline"}
          onClick={() => onSelect?.(tier.id)}
        >
          Select Plan
        </Button>
      </CardContent>
    </Card>
  );
}
