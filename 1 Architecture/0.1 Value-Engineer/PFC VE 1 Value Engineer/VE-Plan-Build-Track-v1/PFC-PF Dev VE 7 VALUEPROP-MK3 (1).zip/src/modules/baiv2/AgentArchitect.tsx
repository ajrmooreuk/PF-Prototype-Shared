import { ArrowLeft, Bot, Workflow, MessageSquare, Zap, BarChart3, Rocket, Brain, GitBranch } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { toast } from "sonner@2.0.3";

interface AgentArchitectProps {
  onBack: () => void;
}

export function AgentArchitect({ onBack }: AgentArchitectProps) {
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold mb-2">Agent Architect Process</h2>
            <p className="text-muted-foreground">
              Design and configure AI agents for value engineering workflows
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        </div>
      </div>

      {/* Agent Architect Process Steps */}
      <div className="space-y-4">
        {/* AA 100 - Agent Definition */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Bot className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 100</Badge>
                  <CardTitle>Agent Definition & Design</CardTitle>
                  <CardDescription className="mt-1">
                    Define AI agent personas, roles, and capabilities
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define agent types, personas, and capability frameworks</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AA 200 - Agent Workflows */}
        <Card className="border-l-4 border-l-indigo-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-indigo-500/10 flex items-center justify-center">
                  <Workflow className="w-6 h-6 text-indigo-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 200</Badge>
                  <CardTitle>Agent Workflows & Orchestration</CardTitle>
                  <CardDescription className="mt-1">
                    Design agent interaction patterns and workflow automation
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define agent orchestration, triggers, and workflow sequences</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AA 300 - Agent Intelligence */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Brain className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 300</Badge>
                  <CardTitle>Agent Intelligence & Learning</CardTitle>
                  <CardDescription className="mt-1">
                    Configure AI models, training data, and learning mechanisms
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define ML models, training datasets, and continuous learning</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AA 400 - Agent Communication */}
        <Card className="border-l-4 border-l-cyan-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-cyan-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 400</Badge>
                  <CardTitle>Agent Communication Protocols</CardTitle>
                  <CardDescription className="mt-1">
                    Define agent-to-agent and agent-to-user communication patterns
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define communication protocols, message formats, and handoff rules</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AA 500 - Agent Performance */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 500</Badge>
                  <CardTitle>Agent Performance & Optimization</CardTitle>
                  <CardDescription className="mt-1">
                    Monitor and optimize agent performance metrics
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define KPIs, monitoring dashboards, and optimization strategies</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AA 600 - Agent Deployment */}
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <GitBranch className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">AA 600</Badge>
                  <CardTitle>Agent Deployment & Management</CardTitle>
                  <CardDescription className="mt-1">
                    Deploy, version control, and manage agent lifecycles
                  </CardDescription>
                </div>
              </div>
              <Button size="sm" variant="outline" disabled>
                Configure
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>Awaiting configuration - Define deployment pipelines, versioning, and rollback procedures</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}