import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Separator } from "../../components/ui/separator";
import { 
  ArrowLeft, 
  FileText, 
  Layers, 
  Network, 
  Database, 
  Shield,
  Users,
  CheckCircle2,
  Circle,
  GitBranch,
  Target,
  Workflow
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface RequirementsDiscoveryProps {
  onBack?: () => void;
}

export function RequirementsDiscovery({ onBack }: RequirementsDiscoveryProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline">SA 100</Badge>
            <Badge className="bg-violet-500">Requirements & Discovery</Badge>
          </div>
          <h2 className="text-2xl font-semibold mb-2">Requirements & Discovery Workflow</h2>
          <p className="text-muted-foreground">
            Convert Value Proposition to Product Requirements and discover technical capabilities for client ICPs
          </p>
        </div>
        {onBack && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onBack();
              toast.success("Returned to Solution Architect");
            }}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Solution Architect
          </Button>
        )}
      </div>

      {/* Sub-Step Workflow */}
      <div className="space-y-4">
        {/* SA 100.1 - Value Prop to PRD Conversion */}
        <Card className="border-l-4 border-l-violet-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-violet-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.1</Badge>
                  <CardTitle className="text-lg">Value Proposition → PRD Conversion</CardTitle>
                  <CardDescription className="mt-1">
                    Transform value propositions into structured Product Requirements Document
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Conversion Process */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Workflow className="w-4 h-4 text-violet-600" />
                  Conversion Process
                </div>
                <div className="space-y-2 pl-6">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Extract Customer Jobs</div>
                      <div className="text-xs text-muted-foreground">Identify functional, social, and emotional jobs from Value Prop Canvas</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Map Pain Relievers to Requirements</div>
                      <div className="text-xs text-muted-foreground">Convert pain points into functional requirements</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Transform Gain Creators to Features</div>
                      <div className="text-xs text-muted-foreground">Define product features from value gains</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Specify Products & Services</div>
                      <div className="text-xs text-muted-foreground">Detail product capabilities and service offerings</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* PRD Components */}
              <div className="text-sm">
                <div className="font-medium mb-2">PRD Document Structure</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">1. Product Vision</div>
                    <div className="text-muted-foreground">From Value Proposition</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">2. Target ICPs</div>
                    <div className="text-muted-foreground">Customer Segments</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">3. Product Goals</div>
                    <div className="text-muted-foreground">Business Objectives</div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">4. Feature List</div>
                    <div className="text-muted-foreground">From Gain Creators</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 100.2 - Epics, Features, Stories */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Layers className="w-5 h-5 text-purple-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.2</Badge>
                  <CardTitle className="text-lg">Epics → Features → Stories Breakdown</CardTitle>
                  <CardDescription className="mt-1">
                    Decompose requirements into Epics, Features, User Stories
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Hierarchy */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-purple-600" />
                  Requirements Hierarchy
                </div>
                <div className="space-y-3 pl-6">
                  {/* Epics */}
                  <div className="border-l-2 border-purple-500 pl-4">
                    <div className="font-medium text-purple-600">Epics (Strategic Initiatives)</div>
                    <div className="text-xs text-muted-foreground mb-2">Large body of work aligned with business goals</div>
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-xs p-2 bg-purple-50 dark:bg-purple-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Epic 1: BAIV Value Engineering Platform</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs p-2 bg-purple-50 dark:bg-purple-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Epic 2: AI-Powered Requirements Analysis</span>
                      </div>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="border-l-2 border-indigo-500 pl-4">
                    <div className="font-medium text-indigo-600">Features (Product Capabilities)</div>
                    <div className="text-xs text-muted-foreground mb-2">Specific functionality within an Epic</div>
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-xs p-2 bg-indigo-50 dark:bg-indigo-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Feature 1.1: Value Proposition Wizard</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs p-2 bg-indigo-50 dark:bg-indigo-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Feature 1.2: ICP Segmentation Tool</span>
                      </div>
                    </div>
                  </div>

                  {/* Stories */}
                  <div className="border-l-2 border-blue-500 pl-4">
                    <div className="font-medium text-blue-600">User Stories (Deliverables)</div>
                    <div className="text-xs text-muted-foreground mb-2">Small, implementable units of work</div>
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-xs p-2 bg-blue-50 dark:bg-blue-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Story 1.1.1: As a user, I can create a new value proposition</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs p-2 bg-blue-50 dark:bg-blue-950/20 rounded">
                        <Circle className="w-3 h-3" />
                        <span>Story 1.1.2: As a user, I can save draft value propositions</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 100.3 - PBS & WBS */}
        <Card className="border-l-4 border-l-fuchsia-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-fuchsia-500/10 flex items-center justify-center">
                  <Network className="w-5 h-5 text-fuchsia-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.3</Badge>
                  <CardTitle className="text-lg">PBS & WBS Structures</CardTitle>
                  <CardDescription className="mt-1">
                    Product Breakdown Structure and Work Breakdown Structure
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* PBS */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Network className="w-4 h-4 text-fuchsia-600" />
                  Product Breakdown Structure (PBS)
                </div>
                <div className="p-3 bg-muted/30 rounded-lg space-y-2 text-xs">
                  <div className="font-medium">BAIV Platform (Root)</div>
                  <div className="pl-4 space-y-1.5">
                    <div>├─ Value Engineering Module</div>
                    <div className="pl-4">│  ├─ VP Wizard Component</div>
                    <div className="pl-4">│  ├─ VE Process Workflow</div>
                    <div className="pl-4">│  └─ Metrics Dashboard</div>
                    <div>├─ Solution Architect Module</div>
                    <div className="pl-4">│  ├─ Requirements Management</div>
                    <div className="pl-4">│  └─ Architecture Design Tools</div>
                    <div>└─ Context Engineer Module</div>
                    <div className="pl-4">   └─ ICP Configuration</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* WBS */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Workflow className="w-4 h-4 text-fuchsia-600" />
                  Work Breakdown Structure (WBS)
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">1.0 Platform Foundation</div>
                    <div className="text-muted-foreground pl-2">
                      <div>1.1 Infrastructure Setup</div>
                      <div>1.2 Authentication System</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">2.0 VE Module</div>
                    <div className="text-muted-foreground pl-2">
                      <div>2.1 VP Wizard</div>
                      <div>2.2 Process Steps</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">3.0 SA Module</div>
                    <div className="text-muted-foreground pl-2">
                      <div>3.1 Requirements Tool</div>
                      <div>3.2 Design Templates</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">4.0 Integration</div>
                    <div className="text-muted-foreground pl-2">
                      <div>4.1 API Development</div>
                      <div>4.2 Database Design</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 100.4 - FRs & Non-FRs */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.4</Badge>
                  <CardTitle className="text-lg">Functional & Non-Functional Requirements</CardTitle>
                  <CardDescription className="mt-1">
                    Define FRs and NFRs for BAIV platform and client ICPs
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Functional Requirements */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  Functional Requirements (FRs)
                </div>
                <div className="space-y-1.5 pl-6 text-xs">
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                    <div>
                      <span className="font-medium">FR-001:</span> System shall allow users to create value propositions via 8-step wizard
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                    <div>
                      <span className="font-medium">FR-002:</span> System shall support multiple customer segment definitions per instance
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                    <div>
                      <span className="font-medium">FR-003:</span> System shall convert VP data into PRD format
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                    <div>
                      <span className="font-medium">FR-004:</span> System shall provide ICP optimization recommendations
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Non-Functional Requirements */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Target className="w-4 h-4 text-orange-600" />
                  Non-Functional Requirements (NFRs)
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-orange-50 dark:bg-orange-950/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="font-medium text-xs">Performance</div>
                    <div className="text-xs text-muted-foreground">
                      <div>• Page load &lt; 2 seconds</div>
                      <div>• API response &lt; 500ms</div>
                    </div>
                  </div>
                  <div className="p-2 bg-orange-50 dark:bg-orange-950/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="font-medium text-xs">Security</div>
                    <div className="text-xs text-muted-foreground">
                      <div>• RBAC enforcement</div>
                      <div>• Data encryption at rest</div>
                    </div>
                  </div>
                  <div className="p-2 bg-orange-50 dark:bg-orange-950/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="font-medium text-xs">Scalability</div>
                    <div className="text-xs text-muted-foreground">
                      <div>• Support 10,000+ users</div>
                      <div>• Multi-tenant architecture</div>
                    </div>
                  </div>
                  <div className="p-2 bg-orange-50 dark:bg-orange-950/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="font-medium text-xs">Usability</div>
                    <div className="text-xs text-muted-foreground">
                      <div>• WCAG AA compliance</div>
                      <div>• Mobile responsive</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 100.5 - RBAC & Roles */}
        <Card className="border-l-4 border-l-emerald-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.5</Badge>
                  <CardTitle className="text-lg">RBAC, Roles & RACI Matrix</CardTitle>
                  <CardDescription className="mt-1">
                    Define role-based access control and responsibility assignment
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Roles */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  Platform Roles
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs text-center">
                    <div className="font-medium">Admin</div>
                    <div className="text-muted-foreground">Full Access</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs text-center">
                    <div className="font-medium">Client</div>
                    <div className="text-muted-foreground">Limited Access</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs text-center">
                    <div className="font-medium">Agency</div>
                    <div className="text-muted-foreground">Partner Access</div>
                  </div>
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 rounded border border-emerald-200 dark:border-emerald-800 text-xs text-center">
                    <div className="font-medium">Affiliate</div>
                    <div className="text-muted-foreground">View Only</div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* RACI Matrix */}
              <div className="text-sm">
                <div className="font-medium mb-2">RACI Matrix (Sample: Requirements Process)</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2 bg-muted/50">Activity</th>
                        <th className="text-center p-2 bg-muted/50">Admin</th>
                        <th className="text-center p-2 bg-muted/50">Client</th>
                        <th className="text-center p-2 bg-muted/50">Agency</th>
                        <th className="text-center p-2 bg-muted/50">Affiliate</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="p-2">Create VP</td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">R</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">A</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">C</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">I</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Convert to PRD</td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">A</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">C</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">R</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">I</Badge></td>
                      </tr>
                      <tr className="border-b">
                        <td className="p-2">Define Requirements</td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">A</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">R</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">R</Badge></td>
                        <td className="text-center p-2"><Badge variant="outline" className="text-xs">I</Badge></td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="mt-2 text-xs text-muted-foreground">
                    <span className="font-medium">R</span>=Responsible | <span className="font-medium">A</span>=Accountable | <span className="font-medium">C</span>=Consulted | <span className="font-medium">I</span>=Informed
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SA 100.6 - Technical Discovery */}
        <Card className="border-l-4 border-l-cyan-500">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <Database className="w-5 h-5 text-cyan-500" />
                </div>
                <div>
                  <Badge variant="outline" className="mb-2">SA 100.6</Badge>
                  <CardTitle className="text-lg">Technical Discovery & Integration</CardTitle>
                  <CardDescription className="mt-1">
                    Ontology, Database, API integrations and ICP optimization
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Ontology Integration */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Network className="w-4 h-4 text-cyan-600" />
                  Ontology Integration
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span>Product Ontology</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span>Customer Ontology</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span>Requirements Ontology</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs p-2 bg-gray-50 dark:bg-gray-900/20 rounded border border-gray-200 dark:border-gray-700">
                    <Circle className="w-4 h-4 text-gray-400" />
                    <span>Integration Ontology</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Database Schema */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-600" />
                  Database Schema Discovery
                </div>
                <div className="space-y-1.5 text-xs pl-6">
                  <div>• Organizations → Products → Value Propositions</div>
                  <div>• Customer Segments → ICPs → Personas</div>
                  <div>• Requirements → Epics → Features → Stories</div>
                  <div>• Users → Roles → Permissions (RBAC)</div>
                </div>
              </div>

              <Separator />

              {/* API Integration */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Network className="w-4 h-4 text-cyan-600" />
                  API Integration Points
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">Internal APIs</div>
                    <div className="text-muted-foreground">
                      <div>• VP Management API</div>
                      <div>• Requirements API</div>
                    </div>
                  </div>
                  <div className="p-2 bg-muted/50 rounded text-xs">
                    <div className="font-medium">External APIs</div>
                    <div className="text-muted-foreground">
                      <div>• AI Analysis API</div>
                      <div>• CRM Integration API</div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* ICP Optimization */}
              <div className="text-sm">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Target className="w-4 h-4 text-cyan-600" />
                  ICP Product Capability Optimization
                </div>
                <div className="space-y-2">
                  <div className="p-2 bg-cyan-50 dark:bg-cyan-950/20 rounded border border-cyan-200 dark:border-cyan-800">
                    <div className="font-medium text-xs mb-1">BAIV ICP: SaaS Companies (50-500 employees)</div>
                    <div className="text-xs text-muted-foreground space-y-0.5">
                      <div>✓ Optimize: Multi-tenant architecture for scalability</div>
                      <div>✓ Optimize: Advanced analytics for data-driven decisions</div>
                      <div>✓ Optimize: API-first design for integration flexibility</div>
                      <div>✓ Optimize: Role-based dashboards for different stakeholders</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
