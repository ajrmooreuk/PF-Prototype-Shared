export default {
p32ddfd00: "M16.6667 5L7.5 14.1667L3.33333 10",
}
